# Extreme-flow search lab

This repository is a reproducible mathematical research program for periodic
three-dimensional incompressible Navier--Stokes.  Its present target is
deliberately narrower than the global regularity problem:

> Search for smooth, divergence-free periodic initial data whose evolution
> sustains superquadratic enstrophy production for as long as possible.

The motivation is the observed gap between two facts:

1. Instantaneous optimizers can saturate the cubic upper bound on enstrophy
   production.
2. In all published finite-time searches found so far, that extreme production
   is rapidly depleted and no singularity is observed.

We therefore optimize persistence itself, rather than only an endpoint norm.
Every numerical claim must pass dealiasing, time-step, resolution, and
invariant checks before it is treated as evidence.  The present convergence
results use untouched replays with the same spectral implementation at new
grids and time steps; an independent solver reimplementation has not yet been
completed.

## Mathematical setting

On the periodic torus, the velocity field satisfies

\[
\partial_t u + (u\cdot\nabla)u + \nabla p = \nu\Delta u,
\qquad \nabla\cdot u=0.
\]

With vorticity \(\omega=\nabla\times u\), normalized enstrophy and its rate are

\[
E(t)=\frac12\langle |\omega|^2\rangle,
\qquad
R(t)=\frac{dE}{dt}
=\langle\omega\cdot S\omega\rangle
-\nu\langle|\nabla\omega|^2\rangle,
\]

where \(S=(\nabla u+\nabla u^T)/2\).  Published energy estimates imply that a
Navier-Stokes blow-up trajectory would require sufficiently strong growth to be
sustained, not merely attained at one instant.

## Current narrow program

1. Represent the 16 independent Fourier pairs with `0 < |k|^2 <= 4` by a
   grid-independent, enstrophy-orthonormal point on `S^63`.
2. Optimize the worst critical-depletion margin simultaneously on `N=16` and
   `N=20`, with state resolution independent of control bandwidth.
3. Enforce full-trajectory velocity, enstrophy, palinstrophy, CFL, and
   monotonicity gates, then replay untouched candidates on `N=24,32,48`.
4. Resolve the observed depletion exponent with two exact mechanism ledgers:
   the classical Betchov factorization and Miller's strain--Laplacian
   orthogonality factorization.
5. Turn finite-dimensional claims into Arb certificates while keeping them
   sharply separated from numerical trajectory evidence.

The implemented multiresolution objective has one necessary restriction beyond
the bare logarithmic formula: it searches only controls satisfying

\[
q_{0.1}(0)\ge q_{\mathrm{P3}}
=0.013828980388103783\ldots .
\]

Without a positive initial bottleneck, maximizing
`log(zeta(t_lambda)/zeta(0))` is ill posed: an infeasible control can drive
`zeta(0)` to zero and manufacture an arbitrarily large score.  On the feasible
subset the reported gamma values are the original, unclipped log ratios.  A
negative outcome is evidence from eight nonconvex starts inside this restricted
64-dimensional subset; it neither excludes the rest of the subset nor says
anything about all low-mode controls.  The bundled theorem certifies P3 as an
exact feasible anchor at `nu=.01`, `E(0)=100`, and `delta=.1`; choosing its
value as the search floor is a design decision, not a theorem that this floor
is unique or optimal.  Other CLI choices are truth-labeled as user-specified
constraints.

The numerical trajectory gates are checked at every stored RK4 time sample.
They are not interval enclosures between samples or at all internal RK stages;
the untouched half-step replays are the separate time-discretization check.

The live status and failed branches are recorded in `RESEARCH_LEDGER.md`.
Axisymmetric Euler and larger control bandwidths are explicitly deferred until
this program is exhausted.

## Certified finite-dimensional results

Four computer-assisted statements are archived under `artifacts/proofs/`:

- Exact rational Fourier algebra and separate 256- and 512-bit runs of the
  same Arb checker
  give `q_0.1(0)=0.01382898038810378379...` and
  `q_0.1'(0)=0.08011446806814873618... > 0` for P3. A separate full-Fourier
  Taylor/Wiener tube certifies `q_0.1'(t) >= 1/50` and hence
  `q_0.1(t) >= q_0.1(0)+t/50` throughout `0 <= t <= 1/800`. No Galerkin tail
  is discarded in this short-time certificate.
- In the active-mode phase chart `(2,0,0),(0,2,0),(0,0,1)`, a 68-variable
  Krawczyk inclusion and bordered-Hessian inertia `(4,64,0)` prove a strict
  local maximizer of initial enstrophy production modulo translations in the
  fixed 64-real-dimensional class. This is neither a global optimum nor a
  Navier--Stokes trajectory theorem.
- A symmetry-defined six-amplitude static ansatz has the exact cubic formula
  `A=64acd+32aef-64bdf`. Exact Sturm reduction plus 256/512-bit Arb comparison
  proves its interior critical point is the global maximizer of `A-2nuP` at
  `E=100` within this ansatz, with value `449.7183372304457156...`. It is not
  a global result in the full 64-variable class and says nothing dynamical.
  Exact symmetry and interval inclusion identify this same point with the
  preceding full-space strict local maximizer.
- A separate two-amplitude symmetry-fixed plane has the exact formulas
  `A=24a^2b`, `E=3a^2+48b^2`, and `P=3a^2+96b^2`. Its stationary branch is
  `b=(sqrt(E+nu^2)-nu)/12`, with an explicit optimized rate. Exact Fourier
  algebra verifies the full 64-coordinate KKT identity. A cancellation-exact
  low-parameter interval cover joined to a direct high-parameter cover proves
  that this branch is a strict local maximum modulo translations in the
  stated 64-control class for every `E>0, nu>0`. This is still local,
  cutoff-dependent, and finite dimensional; it is not a full-class global
  maximum or a statement about the Navier--Stokes PDE.

The originally proposed `e1,e2,e3` phase chart is retained as a documented
failed proof route: its first two selected amplitudes vanish at the optimizer,
leaving two translation null directions.

## Current strongest finite-horizon construction

The saved V3 datum is an explicit 32-mode (including conjugates) trigonometric
polynomial with initial enstrophy 100 and viscosity `.01`.  In untouched
forward replays it first reaches enstrophy 200 at approximately

- `t=.20500` on N=20,
- `t=.20450` on N=32,
- `t=.20425` on N=48.

Through the N=48 crossing, the computed lower envelope is

\[
\min_t \frac{E'(t)}{E(t)^{2.1}}=0.0138289804,
\]

the endpoint palinstrophy-tail fraction is below 2%, and the rate-flatness is
about `.922`.  This is a convergence-tested **numerical construction**, not a
proof of blow-up and not a claim of global optimality.

The explicit continuous Fourier coefficients are in
`artifacts/candidates/persistent_v3_low_modes.json`.  The full audit trail,
including rejected underresolved V1 and the smoother V2 branch, is in the
research ledger.

A second explicit candidate,
`artifacts/candidates/depletion_v3_low_modes.json`, was optimized against the
borderline depletion variable.  Its apparent near-critical coarse-grid scaling
was falsified by refinement and converged to `chi ~ E^(-0.305)` through a 2x
enstrophy crossing.  This regular-side negative result is summarized in
`FINDINGS.md`.

## Reproduce the checks

Create a Python 3.12 environment and install the project, including the
proof checker, in editable mode:

```powershell
python -m venv .venv
.venv\Scripts\python.exe -m pip install -e ".[dev,proof]"
.venv\Scripts\python.exe -m pytest
```

The following N10 command is a legacy reproduction of the historical coarse
branch.  It is not part of the current optimizer or evidentiary campaign.  It
can be replayed untouched with the same spectral implementation on a finer
state grid:

```powershell
.venv\Scripts\python.exe scripts\run_search.py --mode persistent --n 10 `
  --enstrophy 100 --dt .002 --steps 100 --initial-max-mode 2 `
  --iterations 160 --seeds 2 --target-amplification 2 `
  --tail-threshold .1 --tail-weight .1 --output artifacts\raw\search.npz

.venv\Scripts\python.exe scripts\refine_trajectory.py `
  artifacts\raw\search.npz artifacts\raw\search_n32.npz `
  --n 32 --dt .0005 --steps 400
```

Raw trajectory archives are intentionally ignored by Git because they are
large and machine-generated.  Candidate coefficients, figures, source, tests,
proof notes, and the ledger are retained.

Run the fixed N16/N20 critical-depletion campaign and its validation replays:

The default D3, D2, and P3 starts are tracked grid-independent controls under
`artifacts/candidates/`; this command does not depend on an ignored raw seed.
Each fixed-temperature Adam stage also ends early after 20 consecutive rejected
full line searches (recorded in the archive as a numerical plateau control,
not a stationarity certificate).  Pass `--stage-rejection-patience 0` only to
disable that bounded-runtime safeguard for a diagnostic replay.

```powershell
.venv\Scripts\python.exe scripts\run_multires_search.py
```

Rebuild the exact certificates (the proof dependency is already included by
the installation command above):

```powershell
.venv\Scripts\python.exe scripts\certify_p3_onset.py
.venv\Scripts\python.exe scripts\certify_p3_trajectory.py
.venv\Scripts\python.exe scripts\optimize_static_rate.py --adaptive-active-chart `
  --output artifacts\proofs\static_adaptive_kkt_candidate.json
.venv\Scripts\python.exe scripts\certify_static_adaptive.py
```

Use `scripts/analyze_mechanisms.py` on an archived trajectory to regenerate
the Betchov--Miller endpoint ledger.
