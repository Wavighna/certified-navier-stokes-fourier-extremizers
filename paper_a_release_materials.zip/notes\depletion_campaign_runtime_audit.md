# Plateau campaign runtime audit

Observed 2026-08-12 (America/New_York), during the bounded N16/N20
multi-resolution depletion campaign launched with `--endpoint-penalty 100`,
`--max-backtracks 9`, and `--stage-rejection-patience 20`.

The three completed promoted joint starts had negative reported minimum scores:

- P3: `-0.2407206407`;
- D3-perturb-1: `-0.4235140995`;
- D2: `-0.4366443569`.

The fourth promoted start, D3, printed its first joint-iteration line with
zero accepted step and then continued consuming CPU without a new log line or
checkpoint for more than ten minutes. The process remained responsive, had no
stderr output, and was not memory-starved. This is **runtime diagnostic
evidence only**: it does not establish convergence, failure of the objective,
or a mathematical negative result.

The last pre-D3 checkpoint was copied verbatim to
`artifacts/raw/depletion_multires_plateau_pre_d3_stall_checkpoint.npz` before
any future intervention. The live run was intentionally not interrupted at
the time of this record. Any post hoc use of its output must distinguish the
three completed joint starts from the incomplete D3/trust/validation stages.
