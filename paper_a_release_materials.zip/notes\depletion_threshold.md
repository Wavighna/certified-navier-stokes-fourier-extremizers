# A borderline stretching-efficiency criterion

Truth label: **PROVED conditional criterion**.  This does not prove the
unconditional estimate assumed below.

Work on a periodic box and write spatial averages as angle brackets.  For a
smooth, mean-zero incompressible Navier--Stokes solution define

\[
K=\frac12\langle |u|^2\rangle,\qquad
E=\frac12\langle |\omega|^2\rangle,\qquad
P=\frac12\langle |\nabla\omega|^2\rangle,
\]

\[
A=\langle\omega\cdot S\omega\rangle,\qquad
\chi_+=\frac{\max(A,0)}{E^{3/4}P^{3/4}}.
\]

The exact energy and enstrophy identities are

\[
K'=-2\nu E,\qquad E'=A-2\nu P.
\]

## Proposition

If, along a smooth solution, either

\[
\chi_+(t)\le C E(t)^{-1/4}
\]

or, more generally,

\[
\int_0^{T_*} [\chi_+(t)E(t)^{1/4}]^4E(t)\,dt<\infty,
\]

then enstrophy remains bounded up to `T_*`.  In particular, an a-priori bound
of the first form, with a finite `C` allowed to depend on the initial data and
viscosity, would imply global regularity for that smooth periodic datum.

## Proof

For fixed `E` and `chi_+`, maximize the right side of

\[
E'\le \chi_+ E^{3/4}P^{3/4}-2\nu P
\]

over `P >= 0`.  Its maximum occurs at

\[
P_*^{1/4}=\frac{3\chi_+E^{3/4}}{8\nu}
\]

and gives the exact algebraic estimate

\[
E'\le\frac{27}{2048\nu^3}\chi_+^4E^3.
\]

Set `zeta=chi_+ E^(1/4)`.  Wherever `E>0`,

\[
(\log E)'\le\frac{27}{2048\nu^3}\zeta^4E.
\]

The integral criterion therefore bounds `log E`.  Under the pointwise
assumption `zeta <= C`, use the energy identity

\[
\int_0^t E(s)\,ds=\frac{K(0)-K(t)}{2\nu}\le\frac{K(0)}{2\nu}
\]

to obtain the explicit estimate

\[
E(t)\le E(0)\exp\!\left(
\frac{27C^4K(0)}{4096\nu^4}
\right).
\]

If `E(0)=0`, the solution is spatially constant and the zero-mean condition
makes it identically zero.  This completes the conditional argument.

There cannot be one scale-independent numerical constant `C` valid for all
initial data: replacing a field `v` with `Mv` leaves `chi` unchanged but
multiplies `E^(1/4)` by `M^(1/2)`.  The target is therefore a dynamical estimate
with explicit initial-invariant/Reynolds-number dependence, or the weighted
integral criterion.  Contrapositively, finite-time blow-up forces

\[
\int_0^{T_*}\chi_+^4E^2\,dt
=\int_0^{T_*}\zeta^4E\,dt=\infty.
\]

## Computational consequence

The dimensionless-looking quantity that directly tests the borderline is

\[
\zeta(t)=\chi_+(t)E(t)^{1/4}.
\]

The search should try to keep `zeta` large and nondecreasing through prescribed
enstrophy amplifications, while independently refining the state grid at a
fixed initial control bandwidth.  A universal ceiling would suggest a route to
a depletion theorem; systematic growth of the ceiling with initial enstrophy
would falsify the simplest pointwise conjecture and indicate which additional
geometric variable is missing.

Because `P` weights two more derivatives than kinetic energy, the relevant
resolution gate is the palinstrophy-tail fraction, not the velocity-energy tail
fraction used in the first prototype run.
