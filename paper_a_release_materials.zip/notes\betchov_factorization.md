# Separating strain concentration from strain topology

Truth label: **PROVED identity; NUMERICAL mechanism observation**.

For a periodic incompressible velocity field, Betchov's identity and the
tracelessness of the strain tensor give

\[
A=\langle\omega\cdot S\omega\rangle
=-\frac43\langle\operatorname{tr}S^3\rangle
=-4\langle\det S\rangle,
\qquad \langle|S|^2\rangle=E.
\]

For every traceless symmetric three-by-three matrix,

\[
|\det S|\le\frac{|S|^3}{3\sqrt6}.
\]

Define a concentration factor and a signed topology factor by

\[
I_3=\frac{\langle|S|^3\rangle}{E^{3/2}},\qquad
\Theta=-\frac{3\sqrt6\langle\det S\rangle}
{\langle|S|^3\rangle},\qquad |\Theta|\le1.
\]

The normalized production splits exactly as

\[
\frac{A}{E^{3/2}}=\frac{4}{3\sqrt6}\Theta I_3.
\]

This tells us whether growth comes mostly from stronger `L3` strain
concentration (`I3`) or from arranging the strain eigenvalues in a more
stretching-favorable topology (`Theta`).

For the N=32 replay of the first persistence candidate, from `t=0` to `t=0.2`,

\[
\Theta: 0.3511\to0.6235,\qquad
I_3: 1.1646\to1.4151,
\]

while `A/E^(3/2)` rises from `0.2226` to `0.4803`.  The larger relative change
is topological/eigenvalue-shape improvement.  The Betchov relative residual in
the spectral calculation is below `3e-13`.

In the strain eigenframe `lambda_1 <= lambda_2 <= lambda_3`, write

\[
A_i=\langle\lambda_i(\omega\cdot e_i)^2\rangle,
\qquad A=A_1+A_2+A_3.
\]

The candidate's vorticity-energy alignment fractions shift from approximately

\[
(0.181,0.545,0.274)\to(0.106,0.681,0.213).
\]

Thus its sustained production is associated with increasing intermediate-
eigenvector alignment, not simply ever-stronger alignment with the extensive
eigenvector.  This is a mechanism hypothesis to test across independent
optimizers and initial enstrophies, not yet a general conclusion.

## Orthogonal spectral factorization

Truth label: **PROVED prior identities; EXACT diagnostic synthesis; NUMERICAL
endpoint observation**.

Miller's identity for periodic divergence-free fields is

\[
\langle-\Delta S,\omega\otimes\omega\rangle=0.
\]

See Evan Miller, *On the interaction of strain and vorticity for solutions of
the Navier--Stokes equation*, Pure and Applied Analysis 8 (2026), 247--270,
[arXiv:2407.02691](https://arxiv.org/abs/2407.02691).  The identity and its
regularity consequences are Miller's results.  The multiplicative ledger below
is retained here as a diagnostic organization of that identity, not as a new
cancellation theorem.

Set

\[
Q=\langle|\Delta S|^2\rangle,\qquad
d=1-\frac{P^2}{EQ},\qquad
R=S-\frac{P}{Q}(-\Delta S).
\]

Since `E=<|S|^2>` and `P=<S,-Delta S>`, this is the orthogonal projection
residual:

\[
\langle R,-\Delta S\rangle=0,
\qquad \langle|R|^2\rangle=Ed.
\]

Miller's cancellation also gives
`<R,omega tensor omega>=<S,omega tensor omega>=A`.  Therefore, with

\[
H=\frac{\langle R,\omega\otimes\omega\rangle}
{\sqrt{Ed}\,\|\omega\|_4^2},\qquad
J_4=\frac{\|\omega\|_4^2}{2E^{1/4}P^{3/4}},
\]

the second signed stretching factorization is exactly

\[
\chi=\frac{A}{E^{3/4}P^{3/4}}=2H J_4\sqrt d.
\]

For endpoint exponents
`a_X=log(X_1/X_0)/log(E_1/E_0)`, when all logged factors are positive, the
two independent ledgers are

\[
\beta=\frac34-a_\Theta-a_{I_3}-\frac34a_K+\frac34a_\rho,
\qquad
\beta=-a_H-a_{J_4}-\frac12a_d.
\]

The N=48 D3 replay at `T=.208` gives

\[
\beta=0.3143076647975669.
\]

Direct evaluation and both factor ledgers agree within `5e-16`; the largest
of the eight normalized Betchov, Miller, strain, and factorization identity
residuals at the two endpoints is `9.3e-16`.  This verifies the implementation
and resolves the finite-horizon mechanism budget.  It does not turn the
observed exponent into an a-priori estimate or a regularity theorem.

This archived D3 budget checks positivity of `A`, `Theta`, `H`, and `chi` only
at the initial and final endpoints.  The factorization identities are exact,
but their trajectory values are floating-point diagnostics, and no pathwise
logarithmic-budget claim is made without supplying and checking intermediate
mechanism snapshots.
