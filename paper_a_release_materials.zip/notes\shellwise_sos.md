# Exact shell-(1,1,2) stretching bound

This note records deliberately small exact components of the open inviscid
global-inequality program. It is not a proof of the sharp full-cubic bound.

Let `A112` be the part of the exact stretching cubic in the canonical 16-pair
Fourier class whose triad waves have squared lengths `(1,1,2)`, and let `E1`
and `E2` be the enstrophies in the corresponding shells. The certified
statement is

\[
A_{112}^2 \leq \frac{4}{3}E_1^2E_2.
\]

The same symmetry-adapted exact method proves for the `(2,2,4)` component

\[
 A_{224}^2 \leq E_2^2E_4.
\]

Write the shell-one coordinates as `y`, the shell-two coordinates as `z`, and
expand `A112=sum_j M_j(y) z_j`. Weighted Cauchy reduces the assertion to

\[
 q(y)=\frac43 E_1(y)^2-2\sum_j\frac{M_j(y)^2}{d_j}\geq0,
\]

where the positive rational `d_j` are the shell-two enstrophy weights. The
checker represents this quartic as `m(y)^T G m(y)` on the 78 degree-two
monomials in `y`. It verifies all 90 quartic coefficients exactly and proves
`G` positive semidefinite by rational Schur elimination: 40 positive pivots
and a 38-dimensional zero remainder.

Run

```powershell
.venv\Scripts\python.exe scripts\certify_shell112_sos.py
```

to regenerate `artifacts/proofs/shell112_sos_certificate.json`.

Run

```powershell
.venv\Scripts\python.exe scripts\certify_shell224_sos.py
```

to regenerate `artifacts/proofs/shell224_sos_certificate.json`. The second
Gram matrix is 300-by-300, with 106 positive rational Schur pivots and a
194-dimensional zero remainder.

For the mixed `(1,2,3)` component, the bilinear Gram construction proves the
valid but deliberately nonsharp estimate

\[
 A_{123}^2\leq 16E_1E_2E_3.
\]

Its 288-by-288 rational Gram matrix is positive definite (288 positive exact
Schur pivots). The smaller candidate constants `16/3`, `6`, and `8` were
infeasible in this symmetry-adapted bilinear Gram cone. That is an obstruction
to this proof architecture, not a disproof of a sharper analytic inequality.

The certificate does not establish that `2/sqrt(3)` is sharp. More
importantly, bounding the four shell patterns separately loses the
cross-component phase alignment needed for the conjectural sharp full bound
`A^2 <= (128/621) E^3`. This is therefore a structural building block and a
negative design result for naive scalar-envelope proofs, not a global theorem.

## Current fourth-block lead

The remaining `(3,3,4)` component is numerically feasible in a dense SDP at
the candidate coefficient

\[
 A_{334}^2\leq\frac2{27}E_3^2E_4.
\]

The numerical residual is about `7.3e-13`, but the output is not an exact
certificate. The canonical shell-three polarizations mix under cube rotations,
so the signed-permutation orbit method used above cannot be applied directly.
The next valid step is either a rational Gram reconstruction with an exact PSD
test or a representation-adapted coordinate change. Until then this is a lead,
not a paper claim.
