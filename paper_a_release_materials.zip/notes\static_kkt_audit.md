# Static low-mode KKT audit

## Truth label

This is a **double-precision deterministic multistart audit**, not an interval
proof.  The exact rational cubic polynomial and its 68-variable KKT interface
are implemented in `src/extreme_flows/certify.py`.

## Requested phase chart

The proposed theorem fixes translations with the imaginary part of the first
integer-polarization amplitude at `e1`, `e2`, and `e3`.  At a phase-fixed
point, the Jacobian of these constraints with respect to translation is

\[
\operatorname{diag}(\operatorname{Re}z_{e_1},
                    \operatorname{Re}z_{e_2},
                    \operatorname{Re}z_{e_3}).
\]

Thus all three selected amplitudes must remain nonzero before a nonsingular
68-dimensional KKT certificate can exist in this chart.

## Deterministic eight-start result

On 2026-08-10, the exact 512-entry sparse cubic tensor was converted to double
precision and optimized on the exactly normalized `E=100` sphere.  Each start
used Riemannian normalization, L-BFGS, and an analytic-Jacobian Newton polish.
The starts were P3, D3, three deterministic Gaussian tangent perturbations of
P3, and three of D3.  The perturbation generator was NumPy `default_rng` with
seed `20260810`; two perturbations in each family had amplitude `0.2` and one
had amplitude `0.8`.

All eight starts converged to the same stationary value within
`3e-13`:

- `R = 449.7183372304456`;
- maximum absolute KKT residual at most `2.85e-14`;
- selected phase amplitudes approximately `(0, 0, 3.62591054043819)`;
- requested phase-chart rank `1`, not `3`;
- double-precision bordered inertia `(4 positive, 62 negative, 2 zero)`.

The two zero modes agree with the two translations left unfixed after the
`e1` and `e2` selected coefficients collapse.  Consequently, an interval
Krawczyk inclusion for the requested 68-dimensional system cannot close around
this point: its center Jacobian is singular.  This is a concrete mathematical
blocker, not merely missing compute.

An adaptive chart using three linearly independent active modes could remove
the translations locally, but that is a different KKT system and must not be
silently substituted for the theorem requested in the plan.  For the original
`e1/e2/e3` system, neither a strict local maximum nor the planned `(4,64,0)`
interval inertia is claimed.

## Separately certified adaptive chart

A follow-up certificate uses the active waves `(2,0,0)`, `(0,2,0)`, and
`(0,0,1)`, whose wave matrix has determinant `4`.  Its selected real
amplitudes are enclosed away from zero, so it is a valid local translation
slice.  Independent 256- and 512-bit Arb runs both establish:

- a strict 68-dimensional Krawczyk inclusion (largest box used relative radius
  `2^-30`, maximum image/box radius ratio below `9.55e-6`);
- a nonsingular dyadic midpoint preconditioner and weighted infinity contraction
  bound below `9.55e-6`, which together upgrade the inclusion to existence and
  uniqueness of the exact KKT root in the box;
- an invertible dyadic congruence;
- 4 positive and 64 negative signed Gershgorin clusters, with none unresolved;
- a minimum signed cluster margin greater than `0.27209`.

Bordered nonsingularity also certifies that the four-constraint Jacobian has
full row rank: otherwise a nonzero multiplier in `ker(C^T)` would create a null
vector `(0,mu)` of the bordered matrix.

Therefore the adaptive-chart KKT root is a strict local maximum modulo
translations in the fixed 64-real-dimensional low-mode class.  This remains a
local finite-dimensional result, not a global optimum or trajectory theorem.
The proof payload is `artifacts/proofs/static_adaptive_arb_certificate.json`.
