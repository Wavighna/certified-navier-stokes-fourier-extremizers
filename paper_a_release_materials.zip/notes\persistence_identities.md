# Exact identities for the persistence objective

Truth label: **PROVED elementary identities**.

Let `E(t)>0` and, for `delta >= 0`, define

\[
q_\delta(t)=\frac{E'(t)}{E(t)^{2+\delta}}.
\]

Then every differentiable trajectory satisfies

\[
\int_0^T q_\delta(t)\,dt
=\frac{E(0)^{-1-\delta}-E(T)^{-1-\delta}}{1+\delta}.
\]

For `delta>0`, it also satisfies

\[
\int_0^T q_\delta(t)E(t)\,dt
=\frac{E(0)^{-\delta}-E(T)^{-\delta}}{\delta};
\]

at `delta=0`, the right side is `log(E(T)/E(0))`.

Consequently, fixing the horizon and endpoint amplification fixes both the
time integral and the enstrophy-weighted integral of the rate being optimized.
The nontrivial optimization problem is therefore to flatten the rate: push its
minimum toward either endpoint-determined mean.  Define

\[
F_t=\frac{\min_{[0,T]}q_\delta}
{T^{-1}\int_0^Tq_\delta\,dt}\le1
\]

when the denominator is positive, and analogously

\[
F_E=\frac{\min_{[0,T]}q_\delta}
{(\int_0^T E\,dt)^{-1}\int_0^Tq_\delta E\,dt}\le1.
\]

Equality means `q_delta` is constant almost everywhere under the corresponding
positive measure; this is the self-similar scalar ODE

\[
E'=cE^{2+\delta}.
\]

If `q_delta >= m>0` persists indefinitely, this comparison equation forces
blow-up no later than

\[
T_{\rm forced}=\frac{E(0)^{-1-\delta}}{(1+\delta)m}.
\]

For the current fixed-bandwidth candidate, evaluated from the beginning rather
than after the optimizer's two-step skip, the N=32 replay gives approximately

\[
m=0.0137652,\quad F_t=0.7686,\quad F_E=0.7631,
\quad T_{\rm forced}=0.41670.
\]

The resolved computation currently reaches only `T=0.2`.  Its concrete test is
therefore whether a better-resolved optimizer can extend the lower envelope
toward `0.4167`, or whether geometric/spectral depletion necessarily collapses
it first.

## Mechanism coordinates

The following exact dimensionless decomposition separates stretching
efficiency from spectral broadening:

\[
z=\frac{2\nu P}{E^2},\qquad
\rho=\frac{KP}{E^2}\ge1,\qquad
\sigma=\frac{A}{2\nu P},\qquad
\zeta=\chi_+E^{1/4}.
\]

When `A>=0`, so that the positive-part definition of `zeta` agrees with the
signed stretching efficiency, then

\[
q_0=z(\sigma-1)
=\frac{\zeta z^{3/4}}{(2\nu)^{3/4}}-z,
\qquad z=\frac{2\nu\rho}{K}.
\]

For a sign-global identity replace `zeta` by the signed quantity
`chi E^(1/4)`.  The regularity criterion still uses the positive part because
negative stretching cannot drive enstrophy blow-up.  The current candidate has
`A>0` throughout the analyzed interval.

In the current candidate, `zeta` decreases substantially while `rho` and `z`
increase.  The trajectory maintains positive `q_delta` by generating smaller
scales, not by defeating normalized stretching depletion.  Future objectives
must record and adversarially optimize these coordinates separately.
