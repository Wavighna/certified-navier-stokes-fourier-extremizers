# Conservative novelty audit (updated 2026-08-12)

This is a negative primary-literature search, not proof of priority.

## Targeted formula and symmetry audit (2026-08-12)

In addition to the topical search described below, we queried public scholarly
search indexes for the exact algebraic signatures `A=24a^2b`,
`3a^2+48b^2`, `two-amplitude enstrophy Navier--Stokes Fourier`, and
`symmetry-reduced enstrophy production Navier--Stokes Fourier`. No result
located by those queries described the two-amplitude fixed space, its
closed-form constrained branch, or the branch-crossover theorem in this
repository. The searches did return the established unrestricted optimization
literature and unrelated symmetry-reduction work. This is useful *negative
screening only*: formula notation varies, public search indexes are
incomplete, and it neither establishes novelty nor licenses an exclusive
priority claim. A pre-submission MathSciNet/zbMATH/Web of Science search by a
human author remains mandatory.

## Physical-field comparison (2026-08-12)

The explicit representative of the competing plane,

\[
u_{a,b}=(-2a\cos y-8b\sin y\cos z,\
          2a\cos z+8b\cos x\sin z,\
          2a\cos x-8b\sin x\cos y),
\]

was also queried verbatim and through its three $b$-component trigonometric
factors in public scholarly search. No direct antecedent was returned. The
standard Taylor--Green velocity field appearing in the search results has a
different three-component pattern (in its common form, a zero velocity
component), so this field must not be called a Taylor--Green vortex. The
unit-parameter ABC flow has the cyclic one-variable form
$(\sin z+\cos y,\sin x+\cos z,\sin y+\cos x)$; the $a$-part has a related
cyclic trigonometric appearance but is not that Beltrami field, and the
two-shell $b$-part changes the class altogether. Accordingly the manuscript
uses only ``explicit real-space representative'' and makes no named-flow or
exclusive-priority assertion. This is again negative screening, not a
database-grade priority result.

## Defensible conclusions

1. **Realized depletion criterion.** Retaining

   \[
   \chi_+=A_+/(E^{3/4}P^{3/4}),\qquad
   \zeta=\chi_+E^{1/4}
   \]

   in the sharp production--dissipation envelope yields the scale-critical
   sufficient continuation condition

   \[
   \int\chi_+^4E^2\,dt=\int\zeta^4E\,dt<\infty.
   \]

   This explicit diagnostic/criterion was not located.  The mechanism is not
   fundamentally new: cubic enstrophy envelopes, nonlinear depletion, and
   time-integrated continuation criteria are classical.  The constant
   `27/2048` is only the sharp scalar Young optimization under this project's
   normalization.

2. **Fixed-amplification max--min persistence.** The primary literature
   searched contains instantaneous, terminal-enstrophy, and LPS-integral
   optimization, but not

   \[
   \max\min_t E'/E^{2+\delta}
   \]

   at prescribed endpoint amplification, nor its normalized flatness score.
   The endpoint integral identities are elementary chain rules; the likely new
   part is the objective/diagnostic design.

3. **Betchov-factorized search.** The Betchov identity and Lund--Rogers strain
   topology parameter are classical.  No primary source was located that uses
   the resulting topology--concentration factors as separate extreme-flow
   optimization directions.  This is a likely new organization of classical
   variables, not a new identity.

4. **Certified symmetry-reduced static extremizer.** Lu--Doering and
   Ayala--Protas formulate and solve the unrestricted fixed-enstrophy
   instantaneous-production problem numerically; Ayala--Protas also identify
   a small-enstrophy Taylor--Green local branch analytically.  In the sources
   inspected, we did not locate an exact six-amplitude symmetry-fixed Fourier
   reduction of the finite-enstrophy problem, the cubic
   `64acd+32aef-64bdf`, a Sturm/interval proof of its global constrained
   maximizer, or an interval identification of that root with a full low-mode
   local maximizer.  This is the strongest candidate for an original theorem
   in the project.  It still needs a pre-submission database and citation
   audit; a failed direct search is not evidence of exclusive priority.

   The initial six-amplitude branch is *not* full-class global: at
   $\eta=10^4$ a distinct Krawczyk-certified full-space local maximum has
   rate $417.844001666\ldots$, exceeding the ansatz value
   $411.566601975\ldots$. This is an additional rigorous local-branch result,
   not a global optimization theorem. It strengthens the paper by making its
   scope falsifiable and exact rather than relying on deceptive multistart
   evidence.

   The branch is now structurally reduced further: two combined lattice
   symmetries have an exact two-dimensional common fixed space, on which the
   full Fourier functional is
   $A=24a^2b$, $E=3a^2+48b^2$, $P=3a^2+96b^2$. This yields the closed-form
   branch $b=(\sqrt{E+\nu^2}-\nu)/12$. No direct antecedent for this specific
   symmetry class, formula, or its interval identification with a full KKT
   root was located in the scoped search. This remains a priority hypothesis,
   not a claim of exclusive novelty.

   The result is now stronger than the original isolated-point certificate:
   a cancellation-exact 188-interval low-parameter cover joined to the
   238-interval direct high-parameter cover proves that this exact competing
   branch is a strict local maximum modulo translations throughout the stated
   64-coordinate class for every $E,\nu>0$. This is a theorem in the project,
   not merely a robustness sweep. Its possible novelty still rests on the
   specific finite Fourier class, exact branch, and proof mechanism; it must
   not be described as a result about the unrestricted PDE variational
   problem.

   Two further nearby works must be discussed in any submission.  Miller
   studies a *modified* Fourier-restricted Euler/hypodissipative
   Navier--Stokes model whose projection is changed and proves blow-up in a
   different, dyadic symmetry class; it is not a static extremum theorem for
   the true Navier--Stokes nonlinearity.  Kiriukhin's 2026 unreviewed preprint
   studies octahedral orbit-level stretching in cubic Fourier--Galerkin
   Navier--Stokes.  Its stated object is an orbit-transfer matrix and
   ensemble-level spectral-radius bound on a box truncation.  By contrast, the
   present result fixes actual velocity fields under three *combined spatial
   isometry/translation* symmetries, uses the radial 16-pair cutoff
   (0<|k|^2\le4), and solves a fixed-enstrophy maximum of the exact static
   rate.  These differences are substantive, but its priority and methods
   require a line-by-line comparison before submission. The present result
   does not use the $O_h$ orbit-transfer matrix, a cubic max-norm cutoff, an
   ensemble, or a continuum continuation criterion; conversely, that preprint
   does not appear to solve the fixed-enstrophy static 64-variable KKT problem
   by interval certification. This is a distinction, not a priority proof.

Publication-safe overall wording:

> To our knowledge, these particular normalized diagnostics and optimization
> formulations have not previously been used in the extreme-enstrophy
> Navier--Stokes literature searched.

For the static result, use the still more limited formulation:

> We give an exact symmetry-reduced, computer-assisted characterization of a
> finite-enstrophy production extremizer in a prescribed 16-pair Fourier
> class, including an explicit branch that is a rigorously certified
> full-space local maximum for every $E,\nu>0$. We do not claim an
> unconstrained global extremum of the Navier--Stokes variational problem.

## Closest primary sources

- Lu & Doering, sharp cubic enstrophy-growth envelope and fixed-enstrophy
  maximization: [Indiana Univ. Math. J. 57 (2008)](https://doi.org/10.1512/iumj.2008.57.3716).
- Ayala & Protas, instantaneous extreme enstrophy growth and depletion:
  [JFM 2017](https://doi.org/10.1017/jfm.2017.136),
  [arXiv](https://arxiv.org/abs/1605.05742).
- Evan Miller, Fourier-restricted (modified-projection) Euler and
  hypodissipative Navier--Stokes models: [arXiv:2307.03434](https://arxiv.org/abs/2307.03434).
- Oleg Kiriukhin, unreviewed orbit-level Fourier--Galerkin stretching
  preprint: [arXiv:2603.23293](https://arxiv.org/abs/2603.23293).
- Kang, Yun & Protas, terminal-enstrophy optimization and the need for sustained
  superquadratic growth: [JFM 2020](https://doi.org/10.1017/jfm.2020.204),
  [arXiv](https://arxiv.org/abs/1909.00041).
- Ramírez & Protas, LPS optimization: [arXiv:2604.13338](https://arxiv.org/abs/2604.13338).
- Yoneda, Goto & Tsuruhashi, spectrally local normalized-production criterion:
  [arXiv:2105.12459](https://arxiv.org/abs/2105.12459).
- Betchov's homogeneity identity:
  [JFM 1956](https://doi.org/10.1017/S0022112056000317).
- Carbone & Wilczek, modern exact homogeneity constraints:
  [JFM 2022](https://doi.org/10.1017/jfm.2022.461),
  [arXiv](https://arxiv.org/abs/2112.12820).
- Lund & Rogers strain-state topology parameter:
  [Physics of Fluids 1994](https://doi.org/10.1063/1.868440).
- Miller, strain-only identities/determinant structure:
  [ARMA 2020](https://doi.org/10.1007/s00205-019-01419-z),
  [arXiv](https://arxiv.org/abs/1710.05569).
- Buaria, Bodenschatz & Pumir, intense-vorticity alignment/depletion:
  [Phys. Rev. Fluids 2020](https://doi.org/10.1103/PhysRevFluids.5.104602).

The audit did not establish that nobody has independently formulated these
quantities, only that no direct match was found in the searched primary
literature.
