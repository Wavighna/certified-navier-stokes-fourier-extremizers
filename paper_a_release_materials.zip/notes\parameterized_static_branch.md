# Parameterized interior branch of the six-amplitude static ansatz

Let the target enstrophy be `E0>0`, the viscosity be `nu>0`, and use the
six-amplitude static formula in `reduced_static_ansatz.md`. On the fully
interior KKT branch, eliminate

`b=-df/(lambda+8nu)`, `c=2ad/[3(lambda+6nu)]`, and
`e=af/[3(lambda+6nu)]`.

Set `eta=E0/nu^2` and `mu=lambda/nu`. The enstrophy equation reduces exactly
to

```
F_eta(mu) = 69 mu^4 + 1696 mu^3 + (14936-32 eta) mu^2
          + (54656-512 eta) mu + (68368-2048 eta) = 0.
```

Equivalently, before scaling, the multiplier quartic is

```
69 lambda^4 + 1696 nu lambda^3 + (14936 nu^2-32 E0) lambda^2
+ (54656 nu^3-512 E0 nu) lambda + 68368 nu^4-2048 E0 nu^2 = 0.
```

For `eta>1867/4`, the descending coefficient signs are `(+,+,-,-,-)`. Thus
Descartes' rule and the sign at zero give exactly one positive root. Moreover,

```
F_eta(sqrt(28)) <= -833440 - 273664 sqrt(7) < 0,
```

so that root exceeds `sqrt(28)`. The exact square formulas are

```
a^2 = nu^2 * 3(mu+6)(3mu^2+48mu+156) / [32(mu+8)]
d^2 = nu^2 * (5mu^2+48mu+100) / 64
f^2 = nu^2 * (mu^2-28) / 16.
```

They are consequently positive. This is an exact **interior-branch theorem**,
not a parameter-uniform global-maximality theorem. At `nu=.01`, `E0=100`, the
lambda polynomial is the exact quartic used in the Arb global ansatz
certificate, after multiplication by `6,250,000`.

## Parameter-uniform ansatz-globality

The three one-monomial face branches can also be parameterized exactly. On
each, eliminate its positive multiplier from simultaneous equality of `eta`
and the dimensionless rate with the interior branch. The nontrivial resultant
is a degree-eight polynomial in `mu` with strictly positive integer
coefficients for each face. It has no positive root, so no face rate can cross
the interior rate above the threshold. The independently Arb-certified
ordering at `eta=10^6` fixes the sign on the connected high-eta regime.

Thus for **every** `eta>1867/4`, the interior branch is the global maximum of
the static rate inside the six-amplitude ansatz. This does not prove globality
in the full 64-control class. The exact resultant lists and source hashes are
in `artifacts/proofs/parameterized_static_global.json`.
