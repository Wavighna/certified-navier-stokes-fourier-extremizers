# Six-branch full-space stability program

This note records the next theorem target after the certified inviscid
endpoint and the exact two-branch coexistence theorem. It is deliberately
separate from the proved claims in Paper A.

## Numerical atlas

The exact six-amplitude KKT branch exists in the high-parameter regime

\[
\eta=E/\nu^2>1867/4.
\]

The full 64-coordinate constrained Hessian was evaluated from the exact cubic
tensor at 25 logarithmically spaced values from \(1867/4+10^{-3}\) to
\(10^{10}\), at fixed \(E=100\). At each sample it has 60 negative
nontranslation eigenvalues and three translation zeros. The largest sampled
nontranslation eigenvalue is \(-0.631300525\ldots\), at the sample nearest
the lower branch threshold. The record is
`artifacts/raw/six_branch_full_hessian_atlas.json`.

This is **numerical evidence**, not a continuation theorem: it does not rule
out a zero crossing between samples.

## Exact symmetry data

The six-amplitude fixed space is defined by the three generators in
`STATIC_ANSATZ_GENERATORS`. Exact finite-group enumeration gives:

- group order 16;
- 10 conjugacy classes, with class sizes
  \(1,1,1,1,2,2,2,2,2,2\);
- orders only \(1,2,4\), with counts \(1,7,8\);
- center size 4;
- derived subgroup order 2 and abelianization order 8.

Consequently the group has eight one-dimensional complex characters; the
remaining sum of squared irreducible dimensions is 8, hence there are two
two-dimensional irreducibles. Any exact symmetry-adapted generalized-Hessian
calculation can therefore be organized into scalar and two-by-two character
blocks, with multiplicities in the 64-coordinate representation. This is the
six-branch analogue of the already completed $A_4\times C_2$ block proof for
the competing branch.

The exact real-control decomposition has now been generated and checked in
`artifacts/proofs/six_branch_symmetry_representation.json`:

\[
64=(5+5+5+5+6+4+4+6)+24.
\]

The first eight summands are the real linear-character isotypic sectors. On
the final 24-dimensional real component, a central order-four group element
has characteristic polynomial \((t^2+1)^{12}\). Thus it is a complex-type
two-dimensional sector of multiplicity 12, and any symmetric Hessian that
commutes with the group reduces there to a 12-dimensional Hermitian
multiplicity block. This is exact representation structure, not yet a
parameter-uniform Hessian-sign certificate.

## Rigorous target

Prove, for every \(\eta>1867/4\), that the high-\(\eta\) six-amplitude KKT
branch is a strict local maximum of \(A-2\nu P\) at fixed enstrophy in the
full 64-coordinate class, modulo translations. The expected generalized
Hessian inertia is

\[
(4^+,64^-,0)
\]

for the bordered matrix, equivalently 60 negative constrained directions and
three translation zeros.

The viable route is:

1. derive exact characteristic factors of \(D_E^{-1}[\nabla^2\mathcal R-
   \lambda\nabla^2E]\) on the ten irreducible symmetry sectors;
2. use the branch quartic and the amplitude recovery relations to remove all
   radicals from each factor;
3. use Sturm/root isolation to exclude nontranslation zero crossings on
   \(\eta>1867/4\);
4. certify one sample inertia and isolate the three translation directions.

No full-space global statement follows from this local-stability theorem.
