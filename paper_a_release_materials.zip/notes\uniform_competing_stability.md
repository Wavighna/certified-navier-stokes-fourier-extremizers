# Uniform stability of the competing branch

## Proved result

At unit enstrophy write s = 12 b. The exact branch is

    a = sqrt(3 - s^2) / 3
    nu = (1 - s^2) / (2 s)
    eta = 4 s^2 / (1 - s^2)^2.

The last map is increasing on (0, 1). The script
scripts/certify_competing_high_eta_uniform.py covers

    9049/10000 <= s <= 1

by 238 rational intervals. On every interval it forms the exact-coefficient
bordered Hessian in the active translation chart and proves inertia
(4+, 64-, 0) by an Arb congruence/Gershgorin enclosure. Both the 256-bit and
512-bit covers close, with no failures.

Scaling u = sqrt(E) v and nu = sqrt(E) nu_tilde reduces the general
fixed-enstrophy problem to this unit-enstrophy calculation and preserves the
local constrained inertia. This is a local theorem in the stated Fourier
class, not a full-space global theorem or a PDE statement.

## Cancellation-exact low-parameter cover

The direct bordered matrix contains apparent 1/s terms. On the weak
|k|^2 = 1 shell, however, P=E and the leading diagonal terms cancel. Let D(s)
scale precisely these weak control coordinates by 1/s. For s>0, the form

    N(s) = s D(s)^T B(s) D(s)

is congruent to the ordinary bordered Hessian B(s) and has identical inertia.
Writing the tensor contraction as a T_a + b T_b, exact Fourier algebra gives
T_a = 0 on weak-shell pairs. This cancels every inverse power before interval
evaluation and extends N continuously to s = 0.

The script certifies N on 188 intervals covering 0 <= s <= 47/50. The direct
238-interval cover begins at 9049/10000 and ends at 1; the covers overlap.
Thus every 0 < s < 1, equivalently every positive eta, is covered at both
256 and 512 bits.

## Result

The combined certificate proves that the exact competing branch is a strict
local maximum modulo translations in the full 64-control class for every
E, nu > 0. It remains a local, cutoff-dependent statement; it is not a
full-space global extremum or a PDE regularity theorem.
