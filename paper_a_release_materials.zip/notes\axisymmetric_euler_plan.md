# Axisymmetric Euler-with-swirl: implementation specification

This is the next high-resolution track after the periodic 3D calibration.  It
uses the exact axisymmetric Euler equations on a two-dimensional meridional
grid, but it keeps wall-cylinder and boundaryless claims strictly separate.

## State equations

Define

\[
u_1=u^\theta/r,\qquad \omega_1=\omega^\theta/r,
\qquad \psi_1=\psi^\theta/r.
\]

Then

\[
D_tu_1=2u_1\psi_{1,z},\qquad
D_t\omega_1=\partial_z(u_1^2),
\]

\[
-(\partial_{rr}+3r^{-1}\partial_r+\partial_{zz})\psi_1=\omega_1,
\]

\[
u^r=-r\psi_{1,z},\qquad u^z=2\psi_1+r\psi_{1,r}.
\]

The physical vorticity is

\[
\omega^r=-ru_{1,z},\qquad \omega^\theta=r\omega_1,
\qquad \omega^z=2u_1+ru_{1,r}.
\]

Angular momentum `Gamma=r^2 u1` obeys the exact transport equation
`D_t Gamma=0`.

Smooth Cartesian fields make `u1`, `omega1`, and `psi1` even in `r`; all odd
radial derivatives vanish at the axis.  The elliptic radial operator has the
axis limit

\[
(\partial_{rr}+3r^{-1}\partial_r)\psi_1\to4\psi_{1,rr}.
\]

Never numerically divide physical swirl or vorticity by `r` at the axis.

## Keep two geometries separate

### Wall-cylinder calibration

Use `0<=r<=R`, periodic `z`, and impose only

\[
\psi_1(R,z)=0
\]

for an impermeable Euler free-slip wall with zero mean axial flux.  Do not also
impose `psi_r=0`, a vorticity condition, or `u1=0`; those overconstrain Euler.
This geometry is appropriate for reproducing Luo--Hou/Hou cylinder results,
not for a boundaryless claim.

### Whole-space proxy

Use compactly supported radial vorticity, a long `z` period, and an exact
transparent radial condition.  For axial Fourier wavenumber `k`, outside the
vorticity support,

\[
\psi_k''+3r^{-1}\psi_k'-k^2\psi_k=0.
\]

At `r=R`, impose

\[
\psi_k'+\left(|k|K_0(|k|R)/K_1(|k|R)+2/R\right)\psi_k=0
\]

for `k!=0`, and `psi_0'+2 psi_0/R=0`.  Precompute the Bessel ratio with scaled
functions.  This exactly removes the radial wall for compactly supported
vorticity on `R^2 x T_L`.  Sweep both `R` and `L`; a single large cylinder is
not evidence for `R^3`.

## Discretization

- FFT and strict dealiasing or 3/2 padding in `z`.
- Weighted finite elements/finite volumes in `r` for
  `r^-3 d_r(r^3 d_r)`; this is a five-dimensional radial Laplacian.
- Batched symmetric-positive-definite tridiagonal elliptic solves for each
  axial Fourier mode.
- Even-parity axis ghosts for the differentiable search backend.
- RK4, float64, fixed conservative timestep during optimization.
- A separate conservative FV/WENO or SBP split-form forward solver for final
  verification.

The elliptic adjoint reuses the same symmetric solve.  Implement it as a custom
VJP and verify with centered directional finite differences.  Use checkpointed
reverse AD at `128^2`--`256^2`; `1024^2` and `2048^2` are forward-validation
grids only.

## Search controls and objective

Expand initial controls in low axial modes and polynomials in `r^2`, not `r`.
For the whole-space track, multiply by one fixed smooth compact envelope.  Hold
the control bandwidth and envelope fixed as the PDE grid is refined.

Fix both initial energy and enstrophy to remove Euler amplitude and length
scalings.  Continue finite-p BKM proxies `p=4,8,16,32` and optimize

\[
\operatorname{softmin}_{t\in[T_0,T]}\chi_p(t)
+\beta\log(W_p(T)/W_p(0)),
\]

or impose a hard/augmented amplification constraint.  Here

\[
W_p=(V_*^{-1}\int|\omega|^p)^{1/p},\qquad
\chi_p=\frac{V_*^{-1}\int |\omega|^{p-2}\omega\cdot S\omega}
{W_p^{p+1}},
\]

so exactly `dW_p/dt=chi_p W_p^2`.  Compute this using the full physical
vorticity, never only `omega1`.

## Calibration tests

1. Manufactured elliptic mode:
   `psi1=(1-r^2) cos(kz)`,
   `omega1=[8+k^2(1-r^2)] cos(kz)`.
2. Weighted elliptic energy identity with weight `r^3`.
3. Every `z`-independent `psi1=f(r), u1=g(r)` is stationary.
4. With initially zero `omega1,psi1`, verify
   `omega1_t=d_z(u1^2)` and `u1_t=0` at `t=0`.
5. With `u1=0`, verify all distributional Casimirs of advected `omega1`.
6. Time reversal to the scheme's convergence order.
7. Conservation of kinetic energy and several Casimirs of `Gamma`.
8. Reproduce published cylinder seeds only after tests 1--7 pass.

## Resolution ladder and stopping rules

- `64^2`: signs, axis limits, manufactured solutions, invariants.
- `128^2`: multistart `p=4` search.
- `256^2`: `p=8,16` and adjoint refinement.
- `512^2`: best candidates only, `p=16,32`.
- `1024^2`, selectively `2048^2`: independent forward validation.

Stop before interpreting growth if there are fewer than 16--24 points across
the smallest physical width, radial/axial tails rise, filter loss matters, or
`N` and `2N` trajectories separate.  If a candidate survives the ladder, the
next step is moving-mesh/dynamic-rescaling forward validation, not a larger
uniform-grid optimizer.

Primary calibration sources: [Luo--Hou](https://arxiv.org/abs/1310.0497) and
[Hou's cylinder candidate](https://users.cms.caltech.edu/~hou/papers/FoCM-Euler-2022.pdf).
