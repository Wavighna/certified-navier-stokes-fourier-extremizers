# Six-amplitude static low-mode ansatz

The numerical 64-real-variable KKT representative used to seed the rigorously
certified static local root lies, to displayed tolerance, in an explicit
six-amplitude linear coordinate subspace.  Write its coordinates as
`(a,b,c,d,e,f)` through `extreme_flows.reduced_static.embed_reduced_static`.
Exact rational Fourier algebra gives

\[
\begin{aligned}
A &=64acd+32aef-64bdf,\\
E &=2a^2+32b^2+48c^2+8d^2+48e^2+4f^2,\\
P &=2a^2+128b^2+144c^2+16d^2+144e^2+8f^2.
\end{aligned}
\]

The formula is verified against the full exact 64-variable Fourier polynomial
on rational test amplitudes; the reduced rate gradient is also independently
checked against the full Fourier gradient.

## Symmetry origin

This is not an accidental sparsity pattern.  Three explicit signed-coordinate
plus quarter-period translation symmetries preserve the static functional.
Exact rational row reduction of their fixed-point equations gives dimension
six, and the embedding columns above span that common fixed space.  See
`extreme_flows.static_symmetry`.

## Certified global static result

Sign choices make all three cubic monomials nonnegative while preserving `E`
and `P`. A positive maximizer is then either fully interior or lies on exactly
one one-monomial face. A two-monomial boundary point is not maximal: its missing
variable has a strictly positive first directional derivative, whereas the
enstrophy correction is quadratic. Zero-monomial faces have `R<=0`.

The fully interior KKT equations reduce to one multiplier quartic,

\[
431250000\lambda^4+106000000\lambda^3-19990665000\lambda^2
-3199658400\lambda-127995727=0.
\]

Exact Sturm bisection proves that it has one positive root. Each of the three
one-monomial faces has an exact quadratic with one positive root. Arb interval
comparison at 256 and 512 bits proves

\[
R_{\rm interior}=449.7183372304457156\ldots
>440.4464444459444436\ldots,
\ 379.5699205912177118\ldots,
\ 310.2725089587218379\ldots .
\]

Therefore the interior point is the **global maximizer of `R=A-2nuP` at
`E=100` within this exact six-amplitude static ansatz**. The artifact is
`artifacts/proofs/reduced_static_global_arb_certificate.json`.

## Identification with the full low-mode extremizer

The finite group used above preserves both `R` and `E`.  Therefore the
finite-group averaging argument for symmetric criticality promotes a
restricted constrained critical point to a constrained critical point in the
full 64-real-coordinate problem.  Independently, the full problem has a
68-variable (64 controls plus four multipliers) Krawczyk box with a unique
root and certified bordered inertia `(4+,64-,0)`.

At both 256 and 512 bits, the interval point constructed from the unique
positive root of the reduced multiplier quartic lies strictly inside that full
Krawczyk box (the largest center-distance/radius ratio is below `9e-21`).
Thus the global symmetry-ansatz maximizer is **the same point** as the
independently certified strict full-space local maximizer modulo translations.
The reproducible connection certificate is
`artifacts/proofs/static_symmetry_connection_certificate.json`.

At `eta=10000`, the ansatz branch has a rigorously certified competing
full-space local maximum. In the scaled convention `nu=1/10`, `E=100`, its
rate is `417.844001666...`, strictly exceeding the ansatz value
`411.566601975...`. Two independent Arb Krawczyk/inertia runs certify it as a
strict local maximum modulo translations in a regular phase chart; see
`artifacts/proofs/high_branch_eta10000_arb_certificate.json`. This proves the
ansatz-global branch is not a full-space global maximum at that parameter.

The numerical continuation producing its seed is archived in
`artifacts/raw/full_static_high_branch_3000_10000.json`. Earlier random-restart
experiments that returned only the ansatz orbit are now treated solely as a
warning that isolated basins can defeat naïve multistart searches.

This is static and symmetry-reduced. It does not establish a global optimum in
the full 64-control class, invariance under Navier--Stokes evolution, or any
regularity result.
