# Research findings: persistent extreme 3D Navier--Stokes growth

Date: 2026-08-10

## Result in one paragraph

The program did not solve Navier--Stokes or Euler regularity.  It did produce
two explicit 32-mode periodic Navier--Stokes initial conditions and verify their
finite-horizon behavior through untouched, same-implementation `20^3`, `32^3`,
and `48^3` forward replays.  The strongest production-persistence datum
doubles enstrophy at
approximately `t=.20425` while maintaining

\[
E'/E^{2.1}\ge0.0138289804
\]

with N=48 palinstrophy-tail below 2%.  A second datum was optimized to resist
normalized stretching depletion and approaches, but remains on the regular
side of, the analytically critical law `chi ~ E^(-1/4)`.  Every apparent
subcritical crossing on the coarse grid disappeared under refinement.  A
factor-64 initial-enstrophy sweep of the same geometry stabilized near
`chi ~ E^(-0.30)`.

## Proved analytical reductions

Under the project's volume-average normalization,

\[
K'= -2\nu E,\qquad E'=A-2\nu P,
\]

and with

\[
\chi_+=\frac{A_+}{E^{3/4}P^{3/4}},
\]

exact scalar optimization over `P` gives

\[
E'\le\frac{27}{2048\nu^3}\chi_+^4E^3.
\]

Thus

\[
\int_0^{T_*}\chi_+^4E^2dt<\infty
\]

prevents enstrophy blow-up.  Equivalently, if

\[
\zeta=\chi_+E^{1/4}
\]

is bounded by any finite a-priori constant along a trajectory, the energy
identity supplies an explicit global enstrophy bound.  This is a conditional
criterion, not proof that such a bound always holds.

For

\[
q_\delta=E'/E^{2+\delta},
\]

the exact endpoint identity

\[
\int_0^Tq_\delta dt
=\frac{E(0)^{-1-\delta}-E(T)^{-1-\delta}}{1+\delta}
\]

shows that, at fixed horizon and amplification, the real optimization problem
is rate flatness: push the minimum toward its endpoint-determined mean.

Detailed checked arguments are in `notes/depletion_threshold.md` and
`notes/persistence_identities.md`.

## Computer-assisted finite-dimensional results

Literal-decimal rational exactification of P3, followed by exact sparse
Fourier differentiation and separate 256- and 512-bit runs of the same Arb
checker, certifies

\[
q_{0.1}(0)=0.01382898038810378379\ldots,
\qquad
q'_{0.1}(0)=0.08011446806814873618\ldots>0.
\]

Thus P3 begins at a strict one-sided bottleneck on some non-explicit right
neighborhood.  A separate degree-three full-Fourier Taylor approximation,
complete residual calculation, and moving analytic-Wiener error tube improves
this to the explicit full-PDE statement

\[
q'_{0.1}(t)\ge\frac1{50},\qquad
q_{0.1}(t)\ge q_{0.1}(0)+\frac{t}{50},
\qquad 0\le t\le\frac1{800}=0.00125.
\]

The decisive Arb lower endpoint for `q'` is `.03028347`, above `.02`.  This is
a short local trajectory theorem for one datum, not a long-time regularity
statement.

For the separate static problem, the exact 64-variable low-mode polynomial has
a strict local maximizer of `A-2 nu P` at `E=100`, modulo translations.  In the
regular active-mode phase chart `(2,0,0),(0,2,0),(0,0,1)`, Arb certifies a
68-dimensional Krawczyk inclusion and bordered-Hessian inertia `(4,64,0)`.
The value is `R=449.718337230445...`.  This is local and finite-dimensional;
global optimality is not claimed.  The originally proposed `e1,e2,e3` chart is
singular at this solution and is recorded as a rejected proof route.

The strongest static theorem is a distinct exact two-amplitude symmetry
branch.  In the same 16-pair class it satisfies

\[
A=24a^2b,\qquad E=3a^2+48b^2,\qquad P=3a^2+96b^2,
\]

and has the closed stationary formula

\[
b=(\sqrt{E+\nu^2}-\nu)/12.
\]

Exact Fourier algebra proves it is a 64-coordinate KKT branch.  A
cancellation-exact low-parameter interval cover and a direct high-parameter
cover, each at 256 and 512 bits, certify it as a strict local maximum modulo
translations for every `E,nu>0` in the fixed 64-coordinate class.  This is a
new finite-dimensional theorem candidate, not a global optimizer or a
Navier--Stokes regularity result.

## Numerical construction P3: production persistence

The continuous datum is the trigonometric polynomial in
`artifacts/candidates/persistent_v3_low_modes.json`.

At its first 2x crossing:

| state grid | crossing time | enstrophy | production | flatness | palinstrophy tail |
|---:|---:|---:|---:|---:|---:|
| 20 | .20500 | 200.6075 | 969.0566 | .92375 | 8.399% |
| 32 | .20450 | 200.3489 | 971.8239 | .92263 | 5.627% |
| 48 | .20425 | 200.1320 | 970.9438 | .92246 | 1.934% |

The lower envelope `0.0138289804` is identical to displayed precision across
the three grids.  N=32 to N=48 changes crossing time by one N=48 step and
production by about `.09%`.  The comparison ODE would force blow-up by
`.414779` if the same lower envelope persisted indefinitely; the verified
calculation reaches only `.20425`, so no extrapolation is justified.

## Numerical construction D3: near-critical depletion

The continuous datum is in
`artifacts/candidates/depletion_v3_low_modes.json`.

At the first 2x crossing, its fitted law converges as follows:

| state grid | crossing time | fitted beta in `chi~E^-beta` | zeta ratio | palinstrophy tail |
|---:|---:|---:|---:|---:|
| 20 | .20700 | .28697 | .97461 | 5.337% |
| 32 | .20650 | .30066 | .96546 | 2.302% |
| 48 | .20650 | .30526 | .96238 | .711% |

On the coarse grid, the same optimization appeared to give `beta=.25977`,
nearly critical.  Refinement moved it decisively upward.  This rejects that
specific apparent crossing, not the existence of all possible subcritical
data.

At N=32, rescaling this fixed geometry through
`E(0)=25,100,400,1600` gives fitted exponents
`.29927,.30066,.30004,.29679`.  The near-invariance suggests a coherent
amplitude-scaled branch and supplies a precise conjecture to attack:

> Under fixed low-mode control and optimized finite 2x amplification, the
> depletion exponent approaches a regular-side envelope near `.30`, rather
> than crossing the critical `.25` threshold.

This conjecture is deliberately limited to the observed search family until
larger control spaces and independent optimizer families are tested.

## Mechanism

Betchov's classical identity yields

\[
\frac{A}{E^{3/2}}
=\frac{4}{3\sqrt6}\Theta I_3,
\]

separating strain topology `Theta` from normalized strain concentration `I3`.
Both optimized families improve topology and align roughly 80--84% of
vorticity energy with the intermediate strain eigenvector.  The difference is
spectral broadening: the production branch accepts stronger `zeta` depletion,
whereas the depletion branch balances topology/concentration growth against
palinstrophy generation and hugs the quarter-power boundary.

This factorization is classical in ingredients; using it as separate
optimization coordinates appears absent from the primary literature searched.

## Reliability and limits

- Solver identities pass to around `1e-12`; the automated identity, lifting,
  optimizer-interface, mechanism, and certificate suites pass independently.
- Time-step halving error is negligible relative to state-grid error.
- Vorticity maxima are evaluated with 3x zero-padding to avoid collocation
  under-sampling.
- The initial control bandwidth is held fixed while the forward grid changes.
- Velocity-energy, enstrophy, and palinstrophy tails are all hard gates;
  palinstrophy is the most stringent derivative-field resolution diagnostic.
- The candidate search is nonconvex.  P3 plateaued for one Adam continuation,
  but neither datum is certified globally optimal.
- The current N16/N20 campaign uses a 20-consecutive-rejection exit for each
  fixed-temperature Adam stage.  This is a transparent finite-runtime plateau
  rule, not a stationarity/KKT conclusion; the exact epigraph trust solve and
  validation gates remain separate.
- The trajectories are numerical, not interval-certified solutions.
- No result here resolves smooth Navier--Stokes or boundaryless Euler blow-up.

## Novelty statement

The strongest defensible wording after a primary-source audit is:

> To our knowledge, the realized `chi/zeta` diagnostic, fixed-amplification
> max--min flatness objective, and Betchov-factorized optimization coordinates
> have not previously been used together in the extreme-enstrophy
> Navier--Stokes literature searched.

The underlying enstrophy balances, Betchov identity, and chain-rule endpoint
identities are classical or elementary.  See `notes/novelty_audit.md` for the
closest sources and exact caveats.

## Next high-leverage experiment

Complete the fixed-bandwidth joint N16/N20 critical-beta campaign before
opening another equation or control family.  The exact objective maximizes the
worst `gamma=1/4-beta` over amplification levels `1.1,...,2.0`, with
full-trajectory resolution constraints and untouched N24/N32/N48 replays.
Here `beta` is the cumulative log-slope from the initial state to a first
enstrophy crossing, not a pointwise exponent.  Thus positive gamma at every
listed level would mean `zeta` exceeds its initial value at those ten crossings;
it would not prove monotonicity between crossings or a local power law.
The corrected v3 campaign is restricted to the certified initial-bottleneck
subset `q_0.1(0) >= q_P3`; this is what makes the logarithmic objective bounded,
but its eight nonconvex starts cannot exclude either the rest of that subset or
controls outside it.  P3 is a rigorously feasible anchor; using its value as
the floor is a search-design choice.  Constraints
called "full trajectory" here are evaluated at every stored time sample, not
continuously between samples.
Only an N48 lower error margin strictly above zero would count as numerical
anti-depletion.  Axisymmetric Euler and larger bandwidths remain out of scope
until this falsification gate is complete.
