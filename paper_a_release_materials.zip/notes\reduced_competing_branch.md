# Exact two-amplitude competing static branch

The higher full-space local maximum certified at `eta=10000` lies on the
following exact two-amplitude symmetry-fixed space of the canonical
64-control basis. It is the common fixed space of

\[
(Q,m)=\left(\operatorname{diag}(-1,1,1),(0,2,0)\right),
\quad
\left(
\begin{pmatrix}0&-1&0\\0&0&1\\-1&0&0\end{pmatrix},(0,0,0)
\right),
\]

where the translation is $\pi m/2$. Exact rational row reduction gives fixed
space dimension two. The three controls at indices `(0,13,40)` equal `a`; the
six controls at `(11,19,31,39,47,55)` equal `(-b,-b,-b,-b,b,-b)`; all others
vanish.

Independent exact rational Fourier convolution gives

\[
A=24a^2b,\qquad E=3a^2+48b^2,\qquad P=3a^2+96b^2.
\]

This is an exact identity on the displayed plane, not an interpolation of the
numerical KKT root. With `E` fixed and `a,b` sign-gauged nonnegative, eliminate
`a` to obtain

\[
R(b)=8Eb-384b^3-2\nu E-96\nu b^2,
\qquad 0\le b\le\sqrt{E/48}.
\]

The derivative is strictly decreasing,

\[
R'(b)=8E-1152b^2-192\nu b,
\]

and is positive at zero and negative at the other endpoint. Thus this plane
has the unique global maximizer

\[
b_*=\frac{\sqrt{E+\nu^2}-\nu}{12},
\qquad a_*^2=\frac{E-48b_*^2}{3}.
\]

For `nu=1/10`, `E=100`, this gives
`b*=0.825041665625052...` and
`R=417.844001666639...`. The independent full 64-variable Arb certificate
in `artifacts/proofs/high_branch_eta10000_arb_certificate.json` proves that
the point is a strict local maximum modulo translations. Stronger still, on
substitution of this plane in the *full* 64-coordinate KKT equations at this
parameter point, all 64 stationarity remainders vanish modulo

\[
3a^2+48b^2-100=0,
\qquad 144b^2+(12/5)b-100=0,
\]

with Lagrange multiplier `lambda=8b-2nu` and zero phase multipliers. More
generally, the symbolic reduction of all 64 KKT equations vanishes modulo

\[
3a^2+48b^2-E=0,
\qquad 144b^2+24\nu b-E=0,
\]

for arbitrary positive `E,nu`. Thus this is a parameter-uniform full-KKT
branch. The strict full-space local-maximum theorem now holds for every
positive `E/nu^2` by the joined low- and high-parameter interval covers
described below. The exact algebraic reduction is archived in
`artifacts/proofs/reduced_competing_formula.json`.

As an interval-validated robustness sweep (not itself an all-parameter proof), the
same bordered-inertia/Krawczyk test closes independently at
`eta=100,400,2500,10000,40000`, each at both 256 and 512 bits. See
`artifacts/proofs/competing_branch_stability_sweep.json`.

The high-parameter portion of the stronger result is recorded in
`artifacts/proofs/competing_high_eta_uniform.json`.  At unit enstrophy, set
`s=12b`; then

\[
a=\sqrt{3-s^2}/3,\qquad \nu=(1-s^2)/(2s),\qquad
\eta=4s^2/(1-s^2)^2.
\]

The last map is increasing on $(0,1)$. A direct cover of
`9049/10000 <= s <= 1` by 238 rational intervals certifies bordered inertia
`(4+,64-,0)` at both 256 and 512 bits. The complementary interval
`0 <= s <= 47/50` is covered by 188 cancellation-exact rescaled interval
checks, recorded in `artifacts/proofs/competing_all_eta_uniform.json`; the
two covers overlap. Hence the competing branch is a strict full-64-control
local maximum modulo translations for every positive `E/nu^2`. This remains a
local, cutoff-dependent statement; it is not a global extremum theorem.

## Exact crossing with the six-amplitude branch

The two symmetry-reduced branch rates have exactly one crossover on the
high-`eta` six-amplitude branch:

\[
\eta_\times=27992.671985287174015090\ldots.
\]

Eliminating the competing coordinate from equal rate and equal `eta` gives a
degree-12 polynomial in the six-branch multiplier. Its leading coefficient is
positive and every remaining coefficient negative, so Descartes' rule gives a
unique positive possible crossing. The six-branch `eta(mu)` has strictly
positive derivative. A two-variable Arb Krawczyk enclosure proves the crossing
exists, and interval comparison shows the competing branch wins at `eta=10000`
while the six-amplitude branch wins at `eta=40000`. The proof object is
`artifacts/proofs/symmetry_branch_crossover.json`.

This theorem compares only these two stationary symmetry branches. It makes no
claim that either branch is a global optimizer in the full 64-control problem.

The elementary ansatz-globality does **not** establish a global maximum in the
full class.
