"""Focused algebra checks for the uniform six-branch certificate.

The full 2,048-box, two-precision run is intentionally performed by the
paper verifier.  These tests keep the inexpensive exact formula and endpoint
inertia checks close to the implementation.
"""

from itertools import permutations

from flint import arb, ctx

from extreme_flows.certify import _arb_fraction, _certify_symmetric_inertia_arb
from scripts.certify_six_high_eta_uniform import _bordered_hessian, _branch_arb_controls, _model


def test_compact_six_branch_formula_satisfies_full_kkt_equations_at_samples() -> None:
    old_precision = ctx.prec
    try:
        ctx.prec = 256
        model = _model()
        for parameter in ("0", "0.3", "1"):
            controls, viscosity, multiplier = _branch_arb_controls(arb(parameter))
            hessian = [[arb(0) for _ in range(64)] for _ in range(64)]
            for indices, coefficient in model.third_derivative_terms.items():
                for i, j, k in set(permutations(indices)):
                    hessian[i][j] += _arb_fraction(coefficient) * controls[k]
            stationarity = [
                sum((hessian[i][j] * controls[j] for j in range(64)), arb(0)) / 2
                - 2 * viscosity * _arb_fraction(model.palinstrophy_diagonal_exact[i]) * controls[i]
                - multiplier * _arb_fraction(model.enstrophy_diagonal_exact[i]) * controls[i]
                for i in range(64)
            ]
            enstrophy = sum(
                (
                    _arb_fraction(model.enstrophy_diagonal_exact[i]) * controls[i] ** 2
                    for i in range(64)
                ),
                arb(0),
            ) / 2
            assert max(float(value.abs_upper()) for value in stationarity) < 1.0e-60
            assert float((enstrophy - 100).abs_upper()) < 1.0e-60
    finally:
        ctx.prec = old_precision


def test_compact_cover_endpoints_have_certified_bordered_inertia() -> None:
    old_precision = ctx.prec
    try:
        ctx.prec = 256
        for parameter in ("0", "1"):
            inertia = _certify_symmetric_inertia_arb(_bordered_hessian(arb(parameter)))
            assert inertia["verified"]
            assert (inertia["positive"], inertia["negative"], inertia["zero_or_unresolved"]) == (
                4,
                64,
                0,
            )
    finally:
        ctx.prec = old_precision
