# Public priority-search log

Date: 2026-08-12 (America/New_York).

This is a reproducible **screening record**, not evidence that no prior work
exists and not a priority claim. It supports the deliberately limited wording
in the manuscript: the paper characterizes specified symmetry-fixed subspaces
of one finite 16-pair Fourier class. It does not claim the first study of
fixed-enstrophy enstrophy production, Fourier--Galerkin Navier--Stokes, or
symmetry reduction.

## Object screened

The central explicit field is

\[
u_{a,b}=(-2a\cos y-8b\sin y\cos z,\
          2a\cos z+8b\cos x\sin z,\
          2a\cos x-8b\sin x\cos y),
\]

with exact restricted identities

\[
A=24a^2b,\qquad E=3a^2+48b^2,\qquad P=3a^2+96b^2.
\]

The associated claim is only a closed-form stationary branch and a
computer-assisted strict local maximum in the stated 64-real-coordinate
class, modulo translations.

## Public searches and outcome

The following exact or near-exact queries were run against public web/scholarly
indexes on the stated date:

- `"-2 a cos y" "-8 b sin y cos z"`
- `"sin y cos z" "cos x sin z" "sin x cos y" Navier-Stokes`
- `"sin y cos z" "cos x sin z" "sin x cos y" Taylor-Green`
- `"A=24a^2b" Navier-Stokes`
- `"3a^2+48b^2" enstrophy`
- `"two-amplitude enstrophy Navier-Stokes Fourier"`
- `"symmetry-reduced enstrophy production Navier-Stokes Fourier"`
- `"fixed enstrophy" Fourier Navier-Stokes maximization`
- `"enstrophy production" "computer-assisted proof" Navier-Stokes`
- `"instantaneous enstrophy production" "Galerkin" Navier-Stokes`
- `"enstrophy production" "interval arithmetic" Navier-Stokes`
- `"maximum enstrophy production" Fourier Navier-Stokes`

No returned result described this exact two-amplitude fixed space, the three
polynomial identities above, its closed-form constrained branch, or the
certified crossover with the six-amplitude branch. This is only negative
screening: notation, indexing, and terminology vary, and public search is
not exhaustive.

## Nearby and excluded material

- The standard Taylor--Green field has a distinct component pattern, commonly
  including a zero velocity component; it is not used as a name for the
  displayed field. A representative reference is the Taylor--Green example
  in the spectral-method literature.
- The cyclic one-variable ABC field
  $(\sin z+\cos y,\sin x+\cos z,\sin y+\cos x)$ is a distinct Beltrami
  family. The $a$ part resembles it only superficially; the full field is
  nonhelical and has a second shell.
- Lu--Doering and Ayala--Protas are direct prior art for the broad
  fixed-enstrophy instantaneous-production problem, but their published
  formulations are not the present finite exact branch certificate:
  [Lu--Doering 2008](https://doi.org/10.1512/iumj.2008.57.3716) and
  [Ayala--Protas 2017](https://doi.org/10.1017/jfm.2017.136).
- A full-text public copy of Lu--Doering was also screened on this date.  It
  explicitly formulates the rate variational problem in Fourier coefficients
  and uses numerical constrained-gradient optimization.  That makes it
  essential prior art for both the objective and a Fourier computational
  treatment.  The screened text did not exhibit the present 16-pair exact
  branch, a rational Krawczyk inclusion, or an all-parameter certified
  Hessian-inertia theorem.  This is a comparison of stated methods and must
  be rechecked against the publisher copy before submission.
- Miller's arXiv v5 HTML full text was also screened on this date. It defines
  a distinct Fourier-restricted **model equation** by replacing the
  Helmholtz projection with a dyadic constraint-space projection, including
  one selected polarization per retained frequency, and proves blowup for
  that model. It is nearby symmetry/Fourier prior art but the screened
  formulation is not the true-projection 16-pair static KKT problem here:
  [arXiv:2307.03434](https://arxiv.org/abs/2307.03434).
- Kiriukhin's 2026 preprint studies octahedral orbit-level transfer in a
  cubic Fourier--Galerkin truncation. Its arXiv v1 HTML full text was
  screened on this date through the framework, main-results, and
  orbit-dynamics sections: it develops orbit-transfer matrices, triad
  incidence, ensemble/spectral bounds, and an orbit-level continuation
  criterion. The screen did not identify a fixed-enstrophy static KKT problem,
  the displayed two-amplitude formula, or an interval-certified local branch.
  This limited reading must still be checked line by line before submission:
  [arXiv:2603.23293](https://arxiv.org/abs/2603.23293).
- A second Kiriukhin 2026 preprint, located in the follow-up search on the
  same date, likewise treats an $O_h$-reduced Fourier--Galerkin system. Its
  stated object is an orbit-level transfer matrix, orbit--triad incidence,
  and deterministic row-sum estimates, rather than a fixed-enstrophy static
  KKT problem. Its abstract did not state the displayed two-amplitude fixed
  space, exact formula, or a local-extremizer certificate. It is nevertheless
  direct nearby prior art and is cited in the manuscript:
  [arXiv:2604.12188](https://arxiv.org/abs/2604.12188).

## Additional terminology screen (2026-08-12)

A second public-index screen used terminology that does not presuppose the
displayed coordinates:

- `"instantaneous enstrophy production" Fourier Galerkin symmetry Navier-Stokes extremizer`;
- `"fixed enstrophy" Fourier KKT Navier-Stokes`;
- `"enstrophy production" "interval arithmetic" Navier-Stokes Fourier`;
- `"enstrophy maximization" "Fourier truncation" Navier-Stokes`.

The returns reinforced the known numerical extreme-flow literature and related
turbulence diagnostics, but did not identify a paper stating the same
true-Helmholtz-projected 16-pair static KKT problem, the explicit
two-amplitude formula, or an interval-certified all-parameter local branch.
This remains a negative web screen only. In particular, it does not search
subscription databases, citation networks, non-English terminology, or every
reference list, and it must not be converted into an exclusive-priority claim.

## Mandatory follow-up before submission

An author or independent reviewer with access must repeat the search in
MathSciNet, zbMATH Open, and Web of Science/Scopus using both formulas and
conceptual variants (``instantaneous enstrophy production'', ``finite Fourier
truncation'', ``Palais symmetric criticality'', ``interval KKT'', and
``two-shell nonhelical''). Record database, date, query, each close hit, and
the concrete reason it differs. If a direct antecedent is found, revise the
priority language and cite it; the finite certified result may still be
publishable, but its novelty must be recast accurately.
