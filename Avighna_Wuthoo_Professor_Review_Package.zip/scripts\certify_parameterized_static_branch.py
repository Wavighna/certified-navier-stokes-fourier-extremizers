"""Emit the exact high-eta interior-branch theorem manifest."""

from __future__ import annotations

from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

from extreme_flows.reduced_static_parameterized import (
    UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD,
    dimensionless_interior_quartic,
    high_eta_interior_branch_theorem,
)


ROOT = Path(__file__).resolve().parents[1]


def _record(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "size_bytes": len(data),
        "sha256": sha256(data).hexdigest(),
    }


def build_certificate() -> dict[str, object]:
    """Build a source-bound manifest for the all-high-eta elementary proof."""

    threshold = UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD
    witness = high_eta_interior_branch_theorem(threshold + Fraction(1, 1_000))
    if not witness["threshold_met"] or witness["descartes_positive_root_count"] != 1:
        raise AssertionError("high-eta branch proof conditions did not close")
    return {
        "schema_version": 1,
        "truth_label": "proved_elementary_parameterized_interior_branch",
        "dimensionless_variables": {"eta": "E0/nu^2", "mu": "lambda/nu"},
        "quartic_low_to_high": [
            "68368-2048*eta",
            "54656-512*eta",
            "14936-32*eta",
            "1696",
            "69",
        ],
        "threshold": str(threshold),
        "proof": {
            "descending_sign_pattern_above_threshold": [1, 1, -1, -1, -1],
            "positive_root": "Descartes gives at most one; F(0)<0 and F(+infinity)>0 give existence",
            "admissibility": "F_eta(sqrt(28)) <= -833440-273664*sqrt(7)<0, hence mu>sqrt(28)",
            "conclusion": "a2,d2,f2 are positive on the unique positive interior branch",
        },
        "current_normalization_witness": {
            "eta": "1000000",
            "formula_low_to_high": [
                str(value) for value in dimensionless_interior_quartic(Fraction(1_000_000))
            ],
        },
        "claims": {
            "unique_admissible_positive_interior_kkt_branch_for_eta_gt_1867_over_4": True,
            "parameter_uniform_global_maximum": False,
            "full_64d_global_maximum": False,
            "navier_stokes_trajectory_or_regularity_statement": False,
        },
        "checker_source": {
            "script": _record(Path(__file__).resolve()),
            "parameterized_reduction": _record(
                ROOT / "src" / "extreme_flows" / "reduced_static_parameterized.py"
            ),
            "reduced_formula": _record(
                ROOT / "src" / "extreme_flows" / "reduced_static.py"
            ),
        },
    }


def main() -> None:
    output = ROOT / "artifacts" / "proofs" / "parameterized_static_branch.json"
    payload = build_certificate()
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output.relative_to(ROOT)}")
    print(payload["truth_label"])


if __name__ == "__main__":
    main()
