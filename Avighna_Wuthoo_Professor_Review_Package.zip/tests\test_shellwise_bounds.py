from extreme_flows.shellwise_bounds import (
    shell112_sos_certificate,
    shell123_sos_certificate,
    shell224_sos_certificate,
    shell334_sos_certificate,
)


def test_shell112_exact_sos_certificate_closes() -> None:
    payload = shell112_sos_certificate()
    assert payload["claims"]["shell112_bound_proved"]
    assert not payload["claims"]["shell112_constant_sharp_proved"]
    assert not payload["claims"]["full_64d_inviscid_globality_proved"]
    assert payload["proof"]["degree_two_monomial_basis_size"] == 78
    assert payload["proof"]["positive_schur_pivot_count"] == 40
    assert payload["proof"]["zero_schur_remainder_dimension"] == 38


def test_shell224_exact_sos_certificate_closes() -> None:
    payload = shell224_sos_certificate()
    assert payload["claims"]["shell224_bound_proved"]
    assert not payload["claims"]["shell224_constant_sharp_proved"]
    assert not payload["claims"]["full_64d_inviscid_globality_proved"]
    assert payload["proof"]["degree_two_monomial_basis_size"] == 300
    assert payload["proof"]["positive_schur_pivot_count"] == 106
    assert payload["proof"]["zero_schur_remainder_dimension"] == 194


def test_shell123_exact_nonsharp_sos_certificate_closes() -> None:
    payload = shell123_sos_certificate()
    assert payload["claims"]["shell123_bound_proved"]
    assert not payload["claims"]["shell123_constant_sharp_proved"]
    assert not payload["claims"]["full_64d_inviscid_globality_proved"]
    assert payload["proof"]["bilinear_monomial_basis_size"] == 288
    assert payload["proof"]["positive_schur_pivot_count"] == 288
    assert payload["proof"]["zero_schur_remainder_dimension"] == 0


def test_shell334_exact_sos_certificate_closes() -> None:
    payload = shell334_sos_certificate()
    assert payload["claims"]["shell334_bound_proved"]
    assert payload["proof"]["nonzero_upper_triangular_gram_entries"] == 208
    assert payload["proof"]["positive_schur_pivot_count"] == 3
    assert payload["proof"]["zero_schur_remainder_dimension"] == 133
