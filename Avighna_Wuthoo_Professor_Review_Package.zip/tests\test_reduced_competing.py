from fractions import Fraction

import pytest

from extreme_flows.reduced_competing import (
    exact_energy_helicity_coefficients_from_full_polynomial,
    exact_energy_helicity_match_full_polynomial,
    exact_shell_support,
    exact_formula_coefficients_from_full_polynomial,
    exact_formula_coefficients_match_full_polynomial,
    exact_formula_matches_full_polynomial,
    optimizer_formula,
    optimized_rate_formula,
)
from scripts.certify_reduced_competing import exact_optimized_rate_reduction


def test_exact_two_amplitude_formula_matches_full_fourier_polynomial() -> None:
    assert exact_formula_coefficients_match_full_polynomial(Fraction(1, 10))
    assert exact_formula_coefficients_from_full_polynomial(Fraction(1, 10)) == {
        "enstrophy": (Fraction(3), Fraction(0), Fraction(48)),
        "palinstrophy": (Fraction(3), Fraction(0), Fraction(96)),
        "stretching": (Fraction(0), Fraction(24), Fraction(0), Fraction(0)),
    }
    assert exact_formula_matches_full_polynomial(
        ((Fraction(1), Fraction(1)), (Fraction(2), Fraction(1)), (Fraction(1), Fraction(3))),
        Fraction(1, 10),
    )


def test_exact_competing_plane_has_zero_helicity_and_explicit_energy() -> None:
    assert exact_energy_helicity_match_full_polynomial()
    assert exact_energy_helicity_coefficients_from_full_polynomial() == {
        "kinetic_energy": (Fraction(3), Fraction(0), Fraction(24)),
        "helicity": (Fraction(0), Fraction(0), Fraction(0)),
    }
    assert exact_shell_support() == {"a": (1,), "b": (2,)}


def test_formula_matches_certified_eta_10000_branch() -> None:
    result = optimizer_formula(100.0, 0.1)
    assert result["b"] == pytest.approx(0.825041665625052, abs=2e-14)
    assert result["rate"] == pytest.approx(417.844001666639, abs=3e-10)
    assert optimized_rate_formula(100.0, 0.1) == pytest.approx(result["rate"], abs=3e-10)


def test_closed_rate_formula_has_exact_dimensionless_sign_threshold() -> None:
    eta_threshold = (33.0 + 15.0 * 5.0**0.5) / 2.0
    assert optimized_rate_formula(eta_threshold * 0.1**2, 0.1) == pytest.approx(0.0, abs=1e-13)
    assert optimized_rate_formula(0.99 * eta_threshold * 0.1**2, 0.1) < 0.0
    assert optimized_rate_formula(1.01 * eta_threshold * 0.1**2, 0.1) > 0.0
    proof = exact_optimized_rate_reduction()
    assert proof["substitution_remainder"] == "0"
    assert proof["factor_after_y_equals_sqrt_eta_plus_1"] == "(y - 1)*(y**2 - 5*y - 5)"
    assert proof["threshold_proved"]
