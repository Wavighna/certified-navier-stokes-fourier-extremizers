# Publication strategy and claim separation

## Paper A: static certified extremizer

**Working title:** *Certified coexistence of symmetry-reduced local maximizers
in a periodic three-dimensional Navier--Stokes Fourier class.*

This is the current submission candidate.  Its central, self-contained claims
are:

1. exact six-amplitude symmetry-fixed formula for (A,E,P) in a prescribed
   16-pair Fourier class;
2. computer-assisted global maximum of (A-2\nu P) at (E=100) inside that
   six-amplitude class;
3. finite-group symmetric-criticality identification with a separately
   certified strict local maximum modulo translations in the full 64-coordinate
   class;
4. an exact competing two-amplitude full-KKT branch which is rigorously a
   strict local maximum modulo translations in the full class for every
   $E,\nu>0$, by exact symmetry-block/Sturm continuation with a separate
   Arb interval cross-check;
5. at $\eta=10^4$, that competing branch is strictly higher than the
   six-amplitude branch, proving that ansatz-globality must not be promoted to
   full-space globality.
6. a separate uniform full-space local-maximality theorem for the
   high-$\eta$ six-amplitude branch, throughout $\eta>1867/4$.

The short P3 trajectory certificate may be cited as reproducible program
context, but it is not needed for this paper's main theorems.  This prevents a
referee from treating a finite-horizon dynamical computation as evidence for a
static theorem, or vice versa.

### Required before actual submission

- The bundled `scripts/verify_paper_a.py` rebuilds the exact symbolic
  continuation proof and the separate 256/512-bit all-parameter Arb
  cross-check, then writes `paper_a_verification.json`.
- Independent researcher audit of the Arb/Krawczyk implementation and the
  exact face-exhaustion argument.
- Complete literature and priority comparison with Lu--Doering, Ayala--Protas,
  Miller's modified Fourier-restricted model, and both Kiriukhin 2026
  orbit-level preprints.
- Convert the Markdown draft into the chosen journal's LaTeX format, complete
  references, and include a public reproducibility archive with a one-command
  verifier.
- For the SIADS route, prepare the review PDF with SIAM's review macros or
  line numbering, and submit the manuscript PDF, cover letter, and
  supplementary-materials index together on the first submission. The code
  archive is material referees must be able to inspect, not a post-acceptance
  add-on.
- Do **not** state full 64-dimensional globality. The certified competing
  branch already rules out that statement for the ansatz branch at $\eta=10^4$.

### Journal fit and first submission route

**Recommended first venue: SIAM Journal on Applied Dynamical Systems (SIADS).**
The paper is a computer-assisted finite-dimensional variational/dynamical
systems result, and SIADS explicitly publishes mathematical analysis and
modeling of dynamical systems and has published computer-assisted proofs.
The finite Fourier truncation, exact KKT branch, and interval certification
fit this identity more directly than a broad fluid-mechanics claim.

**Second venue: Journal of Computational Dynamics.** This is a plausible
alternative if the paper is reframed around validated computational methods
for a finite Fourier dynamical model rather than its fluid-mechanics context.

**Stretch venue: Journal of Fluid Mechanics.** JFM covers theoretical and
computational fluid mechanics, but this paper would need a stronger
fluid-mechanical interpretation, clear figures, and a compelling explanation
of why these branches matter beyond the finite optimization problem. It should
not be the first target until that exposition exists.

For SIADS, prepare a PDF and cover letter, a one-paragraph abstract under 250
words with minimal formulae, keywords and MSC codes, and a supplementary
materials index for the reproducibility archive. Use the SIAM review macros
or add line numbering. Authors must personally confirm current submission,
authorship, disclosure, and AI-use policy compliance before submission.

The current SIADS instructions (checked 2026-08-12) require a manuscript PDF
and cover letter at submission, request line numbering when SIAM review macros
are not used, and require a supplementary-materials index with any archive at
first submission. They give a general 40-page/10-MB manuscript guideline.
These are packaging requirements, not evidence for any mathematical claim.

Official journal pages consulted on 2026-08-12:

- SIADS scope: https://epubs.siam.org/journal/siads/about
- SIADS author instructions: https://epubs.siam.org/journal/siads/instructions-for-authors
- Journal of Computational Dynamics scope: https://www.aimsciences.org/jcd
- Journal of Fluid Mechanics scope: https://www.cambridge.org/core/journals/journal-of-fluid-mechanics/information/about-this-journal

## Paper B: multiresolution depletion/persistence search

**Working title:** *Resolution-independent search for persistent enstrophy
production in periodic 3D Navier--Stokes.*

This separate paper requires the N16/N20 joint run, trust-constrained
refinement, and N24/N32/N48 untouched validation to complete.  Its claims must
remain numerical and can be positive or negative.  A negative result is still
publishable only if it is carefully framed as evidence from a specified,
nonconvex, low-mode class—not an exclusion theorem for Navier--Stokes.

The P3 short-time trajectory certificate and the Betchov/Miller mechanism
ledgers are natural material for Paper B.

## Why the split is scientifically safer

The static theorem concerns a finite-dimensional variational polynomial and
is already independently checkable with interval arithmetic.  The persistence
question concerns time-evolved PDE numerics, resolution gates, and a nonconvex
optimization landscape.  Each can be judged on its own evidence.  Combining
them prematurely would make the stronger theorem paper depend on the slower,
more fragile numerical campaign.
