"""Validated short-time trajectory certificate for the exactified P3 datum.

The checker in this module is deliberately independent of JAX and of the
pseudospectral solver.  It constructs the degree-three *full Fourier* Taylor
polynomial

    v(t) = a_0 + a_1 t + a_2 t^2 + a_3 t^3

directly with Arb balls.  The leading residual coefficient is convolved in
full.  Every higher residual coefficient (including every spatial mode that
would be produced by the convolution) is enclosed by a Wiener-algebra bound.
An a-posteriori estimate in a moving analytic Wiener norm then encloses the
true periodic Navier--Stokes solution, without a Galerkin-tail assumption.

Finally, elementary derivative-Wiener inequalities enclose E, E', and E'' on
the whole time interval and hence q'(t), where q=E'/E^(21/10).  This is a
small, intentionally conservative certificate.  It is not a long-time
regularity argument.
"""

from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction
from hashlib import sha256
import importlib.metadata
from math import comb
from pathlib import Path
from typing import Mapping, Sequence

from .certify import (
    ExactDatum,
    Wave,
    _validated_proof_precisions,
    load_exactified_candidate,
    wave_square,
)


VISCOSITY = Fraction(1, 100)
TARGET_ENSTROPHY = Fraction(100)
DELTA = Fraction(1, 10)
TAYLOR_DEGREE = 3
ANALYTIC_RADIUS = Fraction(3, 10)
DEFAULT_TRIAL_TIMES = (
    Fraction(1, 100),
    Fraction(1, 200),
    Fraction(1, 400),
    Fraction(1, 800),
    Fraction(1, 1600),
)
CERTIFIED_SLOPE = Fraction(1, 50)


def _arb_fraction(value: Fraction):
    from flint import arb

    return arb(value.numerator) / arb(value.denominator)


def _zero_vector():
    from flint import acb

    return (acb(0), acb(0), acb(0))


BallVector = tuple[object, object, object]
BallField = dict[Wave, BallVector]


def _field_add(*fields: Mapping[Wave, BallVector]) -> BallField:
    keys: set[Wave] = set()
    for field in fields:
        keys.update(field)
    result: BallField = {}
    for k in keys:
        value = _zero_vector()
        for field in fields:
            term = field.get(k)
            if term is not None:
                value = tuple(value[j] + term[j] for j in range(3))
        result[k] = value
    return result


def _field_scale(field: Mapping[Wave, BallVector], scalar) -> BallField:
    return {k: tuple(scalar * value[j] for j in range(3)) for k, value in field.items()}


def _viscous(field: Mapping[Wave, BallVector], viscosity) -> BallField:
    return {
        k: tuple(-viscosity * wave_square(k) * value[j] for j in range(3))
        for k, value in field.items()
    }


def _bilinear(left: Mapping[Wave, BallVector], right: Mapping[Wave, BallVector]) -> BallField:
    """Return -P[(left . grad)right], with every generated mode retained."""

    from flint import acb, arb

    minus_i = acb(0, -1)
    accumulated: BallField = {}
    for p, left_p in left.items():
        for q, right_q in right.items():
            k = (p[0] + q[0], p[1] + q[1], p[2] + q[2])
            if k == (0, 0, 0):
                continue
            directional = sum((q[j] * left_p[j] for j in range(3)), acb(0))
            contribution = tuple(minus_i * directional * right_q[j] for j in range(3))
            previous = accumulated.get(k, _zero_vector())
            accumulated[k] = tuple(previous[j] + contribution[j] for j in range(3))

    projected: BallField = {}
    for k, value in accumulated.items():
        k2 = wave_square(k)
        dot = sum((k[j] * value[j] for j in range(3)), acb(0))
        projected[k] = tuple(
            value[j] - (arb(k[j]) / arb(k2)) * dot for j in range(3)
        )
    return projected


def _scaled_initial_field(datum: ExactDatum) -> BallField:
    from flint import acb

    raw_enstrophy = Fraction(0)
    for k, value in datum.field.items():
        for component in value:
            raw_enstrophy += Fraction(1, 2) * wave_square(k) * (
                component.real * component.real + component.imag * component.imag
            )
    alpha = _arb_fraction(TARGET_ENSTROPHY / raw_enstrophy).sqrt()
    result: BallField = {}
    for k, value in datum.field.items():
        result[k] = tuple(
            acb(
                alpha * _arb_fraction(component.real),
                alpha * _arb_fraction(component.imag),
            )
            for component in value
        )
    return result


def _vector_modulus(value: BallVector):
    from flint import arb

    # ``abs(acb)`` is mathematically nonnegative, but a coefficient created by
    # exact cancellation can be a tiny zero-centred ball.  Squaring that ball
    # naively lets roundoff cross zero and makes ``sqrt`` indeterminate.  Arb's
    # abs_upper operation supplies an outward upper endpoint, which is exactly
    # what a norm majorant needs.
    component_bounds = [abs(value[j]).abs_upper() for j in range(3)]
    return sum((bound * bound for bound in component_bounds), arb(0)).sqrt()


def _field_norm(field: Mapping[Wave, BallVector], derivative: int = 0, radius=None):
    """Enclose sum exp(radius |k|) |k|^derivative |field_k|_2."""

    from flint import arb

    total = arb(0)
    for k, value in field.items():
        modulus = arb(wave_square(k)).sqrt()
        weight = modulus**derivative
        if radius is not None:
            weight *= (radius * modulus).exp()
        total += weight * _vector_modulus(value)
    return total


def _weighted_inner(left: Mapping[Wave, BallVector], right: Mapping[Wave, BallVector]):
    """Enclose Re sum |k|^2 conjugate(left_k).right_k."""

    from flint import acb

    total = acb(0)
    for k in left.keys() & right.keys():
        total += wave_square(k) * sum(
            (left[k][j].conjugate() * right[k][j] for j in range(3)), acb(0)
        )
    return total.real


@dataclass(frozen=True)
class TaylorData:
    coefficients: tuple[BallField, ...]
    residual_cubic: BallField
    energy_coefficients: tuple[object, ...]


def _build_taylor(datum: ExactDatum) -> TaylorData:
    """Build a_0,...,a_3 and the complete t^3 residual coefficient."""

    viscosity = _arb_fraction(VISCOSITY)
    coefficients: list[BallField] = [_scaled_initial_field(datum)]
    bilinear_cache: dict[tuple[int, int], BallField] = {}
    for n in range(TAYLOR_DEGREE):
        rhs = _viscous(coefficients[n], viscosity)
        for i in range(n + 1):
            key = (i, n - i)
            bilinear_cache[key] = _bilinear(coefficients[i], coefficients[n - i])
            rhs = _field_add(rhs, bilinear_cache[key])
        coefficients.append(_field_scale(rhs, _arb_fraction(Fraction(1, n + 1))))

    # r=v_t-F(v).  The coefficients below t^3 vanish by the defining
    # recurrence.  At t^3 the complete convolution is still inexpensive and
    # materially sharpens the certificate.
    residual_cubic = _field_scale(_viscous(coefficients[3], viscosity), -1)
    for i in range(4):
        key = (i, 3 - i)
        if key not in bilinear_cache:
            bilinear_cache[key] = _bilinear(coefficients[i], coefficients[3 - i])
        residual_cubic = _field_add(
            residual_cubic, _field_scale(bilinear_cache[key], -1)
        )

    energy_coefficients: list[object] = []
    for n in range(2 * TAYLOR_DEGREE + 1):
        coefficient = 0
        for i in range(max(0, n - TAYLOR_DEGREE), min(TAYLOR_DEGREE, n) + 1):
            coefficient += _weighted_inner(coefficients[i], coefficients[n - i]) / 2
        energy_coefficients.append(coefficient)
    return TaylorData(
        coefficients=tuple(coefficients),
        residual_cubic=residual_cubic,
        energy_coefficients=tuple(energy_coefficients),
    )


def _bilinear_norm(x: Sequence[object], y: Sequence[object], derivative: int):
    """Wiener derivative bound for B(x,y)."""

    return sum(
        comb(derivative, j) * x[j] * y[derivative - j + 1]
        for j in range(derivative + 1)
    )


def _inner_bound(x: Sequence[object], y: Sequence[object]):
    """Bound the |k|^2 Fourier inner product, choosing the best split."""

    candidates = [x[j] * y[2 - j] for j in range(3)]
    best = candidates[0]
    for candidate in candidates[1:]:
        # If interval comparison is undecidable, min is only an optimization;
        # retaining the earlier candidate is still a valid upper bound.
        if bool(candidate < best):
            best = candidate
    return best


def _polynomial_interval(coefficients: Sequence[object], t_interval, derivative: int = 0):
    from flint import arb

    derived: list[object] = []
    for n in range(derivative, len(coefficients)):
        factor = 1
        for value in range(n - derivative + 1, n + 1):
            factor *= value
        derived.append(coefficients[n] * factor)
    result = arb(0)
    for coefficient in reversed(derived):
        result = result * t_interval + coefficient
    return result


def _symmetric(radius):
    from flint import arb

    return arb(0, radius)


def _serialize_ball(value, digits: int) -> dict[str, object]:
    return {
        "ball": value.str(digits),
        "lower": value.lower().str(digits),
        "upper": value.upper().str(digits),
        "finite": bool(value.is_finite()),
    }


def _definitely_greater(left, right) -> bool:
    """Endpoint-explicit strict comparison between two Arb enclosures."""

    from flint import arb

    if not hasattr(right, "upper"):
        right = arb(right)
    return bool(left.lower() > right.upper())


def _attempt_interval(taylor: TaylorData, tau: Fraction) -> dict[str, object]:
    """Attempt one full-interval certificate at a specified rational tau."""

    from flint import arb

    viscosity = _arb_fraction(VISCOSITY)
    radius0 = _arb_fraction(ANALYTIC_RADIUS)
    time = _arb_fraction(tau)
    # Arb slightly rounds the radius outward, so this contains [0,tau].
    time_interval = arb(time / 2, time / 2)
    # Residual norms are needed through order 12; the derivative in B(x,y)
    # consequently asks for Taylor-coefficient norms through order 13.
    max_derivative = 12
    coefficient_derivative_max = max_derivative + 1

    coefficient_norms = [
        [
            _field_norm(field, derivative=m)
            for m in range(coefficient_derivative_max + 1)
        ]
        for field in taylor.coefficients
    ]
    coefficient_analytic = [
        [_field_norm(field, derivative=m, radius=radius0) for m in range(3)]
        for field in taylor.coefficients
    ]

    # Residual coefficients r_0,r_1,r_2 vanish exactly.  r_3 is calculated
    # mode-by-mode.  For r_4,r_5,r_6 the convolution inequality encloses the
    # complete (untruncated) Minkowski support.
    residual_norms: list[list[object]] = []
    for n in range(7):
        row: list[object] = []
        for m in range(max_derivative + 1):
            if n < 3:
                bound = arb(0)
            elif n == 3:
                bound = _field_norm(taylor.residual_cubic, derivative=m)
            else:
                bound = arb(0)
                for i in range(max(0, n - 3), min(3, n) + 1):
                    bound += _bilinear_norm(
                        coefficient_norms[i], coefficient_norms[n - i], m
                    )
            row.append(bound)
        residual_norms.append(row)

    residual_analytic: list[object] = []
    for n in range(7):
        if n < 3:
            bound = arb(0)
        elif n == 3:
            bound = _field_norm(taylor.residual_cubic, radius=radius0)
        else:
            bound = arb(0)
            for i in range(max(0, n - 3), min(3, n) + 1):
                # B_0(x,y) <= ||x||_a ||y||_{a,1}.
                bound += coefficient_analytic[i][0] * coefficient_analytic[n - i][1]
        residual_analytic.append(bound)

    powers = [time**n for n in range(7)]
    approximate_norms = [
        sum(
            (coefficient_norms[j][m] * powers[j] for j in range(4)), arb(0)
        )
        for m in range(11)
    ]
    residual_endpoint = [
        sum((residual_norms[j][m] * powers[j] for j in range(7)), arb(0))
        for m in range(11)
    ]
    residual_time_derivative = [
        sum(
            (
                j * residual_norms[j][m] * time ** (j - 1)
                for j in range(1, 7)
            ),
            arb(0),
        )
        for m in range(11)
    ]

    approximate_analytic = sum(
        (coefficient_analytic[j][0] * powers[j] for j in range(4)), arb(0)
    )
    approximate_analytic_derivative = sum(
        (coefficient_analytic[j][1] * powers[j] for j in range(4)), arb(0)
    )
    residual_analytic_endpoint = sum(
        (residual_analytic[j] * powers[j] for j in range(7)), arb(0)
    )
    error_bound = residual_analytic_endpoint * (
        (approximate_analytic_derivative * time).exp() - 1
    ) / approximate_analytic_derivative
    radius_slope = approximate_analytic + error_bound
    radius_minimum = radius0 - radius_slope * time

    common: dict[str, object] = {
        "tau": str(tau),
        "analytic_radius_initial": radius0,
        "approximate_analytic_norm": approximate_analytic,
        "approximate_analytic_derivative_norm": approximate_analytic_derivative,
        "residual_analytic_norm": residual_analytic_endpoint,
        "error_tube_analytic_norm": error_bound,
        "analytic_radius_minimum": radius_minimum,
    }
    if not _definitely_greater(radius_minimum, 0):
        return {**common, "status": "analytic_radius_failed", "certified": False}

    euler = arb(1).exp()
    error_derivative_norms = [error_bound]
    for m in range(1, 11):
        error_derivative_norms.append(
            (arb(m) / (euler * radius_minimum)) ** m * error_bound
        )
    solution_norms = [
        approximate_norms[m] + error_derivative_norms[m] for m in range(11)
    ]

    def bnorm(x, y, m):
        return _bilinear_norm(x, y, m)

    def ibound(x, y):
        return _inner_bound(x, y)

    f_approx = [
        bnorm(approximate_norms, approximate_norms, m)
        + viscosity * approximate_norms[m + 2]
        for m in range(5)
    ]
    f_solution = [
        bnorm(solution_norms, solution_norms, m) + viscosity * solution_norms[m + 2]
        for m in range(5)
    ]
    f_difference = [
        bnorm(error_derivative_norms, solution_norms, m)
        + bnorm(approximate_norms, error_derivative_norms, m)
        + viscosity * error_derivative_norms[m + 2]
        for m in range(5)
    ]

    df_residual = [
        bnorm(residual_endpoint, approximate_norms, m)
        + bnorm(approximate_norms, residual_endpoint, m)
        + viscosity * residual_endpoint[m + 2]
        for m in range(3)
    ]
    residual_e1_correction = ibound(approximate_norms, residual_endpoint)
    residual_e2_correction = (
        2 * ibound(f_approx, residual_endpoint)
        + ibound(residual_endpoint, residual_endpoint)
        + ibound(approximate_norms, df_residual)
        + ibound(approximate_norms, residual_time_derivative)
    )

    g_approx = [
        bnorm(f_approx, approximate_norms, m)
        + bnorm(approximate_norms, f_approx, m)
        + viscosity * f_approx[m + 2]
        for m in range(3)
    ]
    g_solution = [
        bnorm(f_solution, solution_norms, m)
        + bnorm(solution_norms, f_solution, m)
        + viscosity * f_solution[m + 2]
        for m in range(3)
    ]
    g_difference = [
        bnorm(f_difference, solution_norms, m)
        + bnorm(f_approx, error_derivative_norms, m)
        + bnorm(error_derivative_norms, f_solution, m)
        + bnorm(approximate_norms, f_difference, m)
        + viscosity * f_difference[m + 2]
        for m in range(3)
    ]

    enstrophy_error = (
        ibound(error_derivative_norms, solution_norms)
        + ibound(approximate_norms, error_derivative_norms)
    ) / 2
    e1_error = ibound(error_derivative_norms, f_solution) + ibound(
        approximate_norms, f_difference
    )
    e2_error = (
        ibound(f_difference, f_solution)
        + ibound(f_approx, f_difference)
        + ibound(error_derivative_norms, g_solution)
        + ibound(approximate_norms, g_difference)
    )

    enstrophy_approx = _polynomial_interval(
        taylor.energy_coefficients, time_interval, derivative=0
    )
    e1_approx = _polynomial_interval(
        taylor.energy_coefficients, time_interval, derivative=1
    ) + _symmetric(residual_e1_correction)
    e2_approx = _polynomial_interval(
        taylor.energy_coefficients, time_interval, derivative=2
    ) + _symmetric(residual_e2_correction)
    enstrophy_tube = enstrophy_approx + _symmetric(enstrophy_error)
    e1_tube = e1_approx + _symmetric(e1_error)
    e2_tube = e2_approx + _symmetric(e2_error)

    if not _definitely_greater(enstrophy_tube, 0):
        return {
            **common,
            "status": "enstrophy_denominator_failed",
            "certified": False,
            "enstrophy_tube": enstrophy_tube,
        }

    exponent = arb(2) + _arb_fraction(DELTA)
    qprime_tube = e2_tube / (enstrophy_tube**exponent) - exponent * (
        e1_tube * e1_tube
    ) / (enstrophy_tube ** (exponent + 1))
    slope = _arb_fraction(CERTIFIED_SLOPE)
    certified = _definitely_greater(qprime_tube, slope)
    return {
        **common,
        "status": "certified" if certified else "qprime_lower_bound_failed",
        "certified": certified,
        "enstrophy_approximation": enstrophy_approx,
        "enstrophy_tube": enstrophy_tube,
        "enstrophy_rate_tube": e1_tube,
        "enstrophy_second_derivative_tube": e2_tube,
        "residual_e1_correction": residual_e1_correction,
        "residual_e2_correction": residual_e2_correction,
        "enstrophy_error": enstrophy_error,
        "enstrophy_rate_error": e1_error,
        "enstrophy_second_derivative_error": e2_error,
        "qprime_tube": qprime_tube,
        "certified_slope": slope,
        "endpoint_check": {
            "qprime_lower": qprime_tube.lower(),
            "slope_upper": slope.upper(),
            "qprime_lower_strictly_above_slope_upper": certified,
        },
    }


def evaluate_trajectory_certificate(
    datum: ExactDatum,
    *,
    precision: int,
    trial_times: Sequence[Fraction] = DEFAULT_TRIAL_TIMES,
) -> dict[str, object]:
    """Run the deterministic halving checker at one Arb precision."""

    if importlib.metadata.version("python-flint") != "0.9.0":
        raise RuntimeError("trajectory proof requires pinned python-flint==0.9.0")
    from flint import ctx

    previous_precision = ctx.prec
    try:
        ctx.prec = int(precision)
        taylor = _build_taylor(datum)
        attempts: list[dict[str, object]] = []
        for tau in trial_times:
            attempt = _attempt_interval(taylor, Fraction(tau))
            attempts.append(attempt)
            if bool(attempt["certified"]):
                break
        final = attempts[-1]
        return {
            "precision_bits": int(precision),
            "taylor_supports": [len(field) for field in taylor.coefficients],
            "residual_cubic_support": len(taylor.residual_cubic),
            "attempts": attempts,
            "certified": bool(final["certified"]),
            "certified_tau": final["tau"] if final["certified"] else None,
        }
    finally:
        ctx.prec = previous_precision


def _serialize_attempt(attempt: Mapping[str, object], digits: int) -> dict[str, object]:
    serialized: dict[str, object] = {
        "tau": attempt["tau"],
        "status": attempt["status"],
        "certified": attempt["certified"],
    }
    for key, value in attempt.items():
        if key in serialized:
            continue
        if isinstance(value, Mapping):
            serialized[key] = {
                subkey: (
                    _serialize_ball(subvalue, digits)
                    if hasattr(subvalue, "lower")
                    else subvalue
                )
                for subkey, subvalue in value.items()
            }
            continue
        serialized[f"{key}_ball"] = _serialize_ball(value, digits)
    return serialized


def _dependency_record() -> dict[str, object]:
    distribution = importlib.metadata.distribution("python-flint")
    files = distribution.files or ()
    binaries = sorted(str(path) for path in files if str(path).endswith((".pyd", ".so")))
    digest_rows: list[dict[str, object]] = []
    for relative in binaries:
        path = Path(distribution.locate_file(relative))
        data = path.read_bytes()
        digest_rows.append(
            {
                "path": relative.replace("\\", "/"),
                "size_bytes": len(data),
                "sha256": sha256(data).hexdigest(),
            }
        )
    return {
        "package": "python-flint",
        "version": distribution.version,
        "compiled_binaries": digest_rows,
    }


def _checker_source_record() -> dict[str, object]:
    module_path = Path(__file__).resolve()
    repository_root = module_path.parents[2]
    script_path = repository_root / "scripts" / "certify_p3_trajectory.py"
    exactification_path = repository_root / "src" / "extreme_flows" / "certify.py"

    def record(path: Path) -> dict[str, object]:
        data = path.read_bytes()
        return {
            "path": str(path.relative_to(repository_root)).replace("\\", "/"),
            "size_bytes": len(data),
            "sha256": sha256(data).hexdigest(),
        }

    return {
        "module": record(module_path),
        "exactification_module": record(exactification_path),
        "script": record(script_path),
    }


def build_trajectory_certificate(
    candidate_path: str | Path,
    *,
    precisions: Sequence[int] = (256, 512),
) -> dict[str, object]:
    """Build the archive-ready, independently repeated trajectory proof."""

    precisions = _validated_proof_precisions(precisions)
    source = Path(candidate_path)
    datum = load_exactified_candidate(source)
    raw_runs = [
        evaluate_trajectory_certificate(datum, precision=int(precision))
        for precision in precisions
    ]
    certified = all(bool(run["certified"]) for run in raw_runs)
    taus = {run["certified_tau"] for run in raw_runs}
    certified = certified and len(taus) == 1
    agreed_tau = next(iter(taus)) if certified else None
    serialized_runs: list[dict[str, object]] = []
    for run in raw_runs:
        digits = max(30, int(int(run["precision_bits"]) * 0.30103) - 8)
        serialized_runs.append(
            {
                "precision_bits": run["precision_bits"],
                "taylor_supports": run["taylor_supports"],
                "residual_cubic_support": run["residual_cubic_support"],
                "certified": run["certified"],
                "certified_tau": run["certified_tau"],
                "attempts": [
                    _serialize_attempt(attempt, digits) for attempt in run["attempts"]
                ],
            }
        )

    return {
        "format_version": 1,
        "truth_label": (
            "proof_grade_positive_time_trajectory_certificate"
            if certified
            else "failed_positive_time_trajectory_attempt"
        ),
        "source": {
            "candidate_path": str(source),
            "candidate_sha256": datum.source_sha256,
            "exactification": (
                "literal decimals as rationals; conjugate-pair averaging; "
                "rational Leray projection; alpha=sqrt(100/E_raw)"
            ),
        },
        "problem": {
            "domain": "[0,2*pi)^3, periodic",
            "viscosity": str(VISCOSITY),
            "target_enstrophy": str(TARGET_ENSTROPHY),
            "delta": str(DELTA),
            "q_definition": "q=E'/E^(21/10)",
        },
        "method": {
            "time_approximation": "degree-3 full Fourier Taylor polynomial",
            "analytic_norm": "sum_k exp(a|k|_2)|u_k|_2",
            "analytic_radius_initial": str(ANALYTIC_RADIUS),
            "trial_times": [str(value) for value in DEFAULT_TRIAL_TIMES],
            "residual_policy": (
                "r_0..r_2 vanish algebraically; r_3 is a complete Fourier "
                "convolution; r_4..r_6 include all modes through rigorous "
                "Wiener convolution bounds"
            ),
            "tail_policy": (
                "no Galerkin tail is discarded; the moving analytic-Wiener "
                "tube encloses the full periodic PDE"
            ),
            "certified_slope": str(CERTIFIED_SLOPE),
            "bootstrap_lemma": {
                "constants": (
                    "V=sup||v||_a0, D=sup||v||_(a0,1), "
                    "R=sup||v_t-F(v)||_a0; z(t)=R(expm1(Dt))/D; M=V+z(tau)"
                ),
                "radius": "a(t)=a0-Mt",
                "condition": "a(tau)>0",
                "conclusion": (
                    "the full periodic mild solution exists uniquely on [0,tau] "
                    "and ||u(t)-v(t)||_a(t)<=z(t)"
                ),
                "absorbed_terms": (
                    "a'(t)||w||_(a,1) cancels the B(v,w)+B(w,w) "
                    "derivative-loss majorant; B(w,v) contributes D||w||_a"
                ),
            },
        },
        "dependency": _dependency_record(),
        "checker_source": _checker_source_record(),
        "runs": serialized_runs,
        "claim": {
            "certified": certified,
            "tau": agreed_tau,
            "qprime_lower_bound": str(CERTIFIED_SLOPE) if certified else None,
            "statement": (
                f"For the exactified P3 datum, q'(t)>={CERTIFIED_SLOPE} and "
                f"therefore q(t)>=q(0)+t/50 throughout 0<=t<={agreed_tau}."
                if certified
                else "No positive-time trajectory interval was certified."
            ),
            "scope": (
                "This is a local certificate for one explicit periodic datum, "
                "not a global regularity or global optimization theorem."
            ),
        },
    }
