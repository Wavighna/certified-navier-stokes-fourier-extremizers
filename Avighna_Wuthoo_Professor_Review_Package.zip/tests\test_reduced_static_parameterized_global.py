from fractions import Fraction

import pytest

from extreme_flows.reduced_static_parameterized_global import (
    FACE_CROSSING_RESULTANTS,
    face_eta_and_rate,
    high_eta_global_ansatz_theorem,
    interior_dimensionless_rate,
    interior_eta,
    six_amplitude_inviscid_extremizer,
    symmetry_branch_crossover_asymptotics,
    symmetry_branch_large_eta_efficiency,
)


def test_high_eta_global_ansatz_claim_is_limited_to_the_six_amplitude_class():
    payload = high_eta_global_ansatz_theorem()
    claims = payload["claims"]
    assert claims["global_static_maximum_within_six_amplitude_ansatz_for_eta_gt_1867_over_4"]
    assert not claims["full_64d_global_maximum"]
    assert not claims["navier_stokes_trajectory_or_regularity_statement"]
    assert all(all(value > 0 for value in polynomial) for polynomial in FACE_CROSSING_RESULTANTS.values())


def test_exact_branch_functions_have_consistent_positive_high_eta_values():
    # This is a rational interior parameter above sqrt(28), not a numerical root solve.
    assert interior_eta(Fraction(11)) > Fraction(1867, 4)
    assert interior_dimensionless_rate(Fraction(11)) > 0
    for name in FACE_CROSSING_RESULTANTS:
        eta, rate = face_eta_and_rate(name, Fraction(7))
        assert eta > 0
        assert rate > 0


def test_symbolic_resultants_match_the_archived_exact_positive_polynomials():
    sympy = pytest.importorskip("sympy")
    m, t = sympy.symbols("m t")
    eta_interior = (
        69 * m**4 + 1696 * m**3 + 14936 * m**2 + 54656 * m + 68368
    ) / (32 * (m + 8) ** 2)
    rate_interior = (
        23 * m**5 + 516 * m**4 + 3840 * m**3 + 8864 * m**2 - 8432 * m - 33728
    ) / (16 * (m + 8) ** 2)
    face_expressions = {
        "acd": (
            3 * (3 * t**2 + 24 * t + 44) / 4,
            3 * (t**3 + 6 * t**2 - 24) / 2,
        ),
        "aef": (
            3 * (3 * t**2 + 24 * t + 44) / 2,
            3 * (t**3 + 6 * t**2 - 24),
        ),
        "bdf": (
            (t + 4) * (3 * t + 20),
            2 * (t + 4) * (t**2 + 4 * t - 16),
        ),
    }
    for name, (eta_face, rate_face) in face_expressions.items():
        equation_eta = sympy.together(eta_interior - eta_face).as_numer_denom()[0]
        equation_rate = sympy.together(rate_interior - rate_face).as_numer_denom()[0]
        factors = sympy.factor_list(sympy.resultant(equation_eta, equation_rate, t))[1]
        degree_eight = next(
            factor for factor, multiplicity in factors if sympy.Poly(factor, m).degree() == 8
        )
        coefficients = tuple(reversed(sympy.Poly(degree_eight, m).all_coeffs()))
        assert coefficients == FACE_CROSSING_RESULTANTS[name]


def test_exact_high_eta_efficiency_ordering_of_the_two_symmetry_branches():
    payload = symmetry_branch_large_eta_efficiency()
    assert payload["six_amplitude"]["limit"] == "8*sqrt(138)/207"
    assert payload["competing_two_amplitude"]["limit"] == "4/9"
    # Comparing squares avoids any floating-point or radical comparison.
    assert payload["strict_ordering"]["squared_difference_six_minus_competing"] == "16/1863"
    assert payload["strict_ordering"]["six_amplitude_branch_eventually_higher"]
    assert not payload["full_64d_global_ordering"]


def test_two_term_asymptotics_explain_the_scale_of_the_certified_switch():
    payload = symmetry_branch_crossover_asymptotics()
    assert payload["six_multiplier"]["constant_coefficient"] == "-296/69"
    assert "-(112/69)t" in payload["difference_six_minus_competing"]
    assert payload["two_term_crossover_predictor"]["formula"] == (
        "7056/(23-2*sqrt(138))^2"
    )
    # This is intentionally marked as an asymptotic predictor, not a proof
    # of the finite crossover or a full 64-dimensional ordering.
    assert "not a replacement" in payload["two_term_crossover_predictor"]["meaning"]
    assert not payload["full_64d_global_ordering"]


def test_crossover_asymptotic_coefficients_follow_from_exact_branch_formulas():
    sympy = pytest.importorskip("sympy")
    t = sympy.symbols("t", positive=True)
    root = sympy.sqrt(138)
    mu = 4 * root / (69 * t) - sympy.Rational(296, 69) + 1913 * root * t / 9522
    eta = (
        69 * mu**4 + 1696 * mu**3 + 14936 * mu**2 + 54656 * mu + 68368
    ) / (32 * (mu + 8) ** 2)
    rate_six = (
        23 * mu**5 + 516 * mu**4 + 3840 * mu**3 + 8864 * mu**2
        - 8432 * mu - 33728
    ) / (16 * (mu + 8) ** 2)
    # The inverted multiplier satisfies eta=t^-2 through the required order.
    assert sympy.series(t**2 * eta - 1, t, 0, 3).removeO().expand() == 0
    target_six = 8 * root / 207 - sympy.Rational(296, 69) * t + 1913 * root * t**2 / 4761
    assert sympy.simplify(
        sympy.series(t**3 * rate_six, t, 0, 3).removeO() - target_six
    ) == 0
    rate_two = sympy.Rational(4, 9) * ((t**-2 + 1) ** sympy.Rational(3, 2) - 6 * t**-2 - 1)
    target_two = sympy.Rational(4, 9) - sympy.Rational(8, 3) * t + sympy.Rational(2, 3) * t**2
    assert sympy.simplify(
        sympy.series(t**3 * rate_two, t, 0, 3).removeO() - target_two
    ) == 0


def test_exact_inviscid_six_amplitude_extremizer_matches_high_eta_constant():
    payload = six_amplitude_inviscid_extremizer()
    assert payload["claims"]["exact_inviscid_six_amplitude_cubic_maximizer"]
    assert payload["claims"]["global_maximum_within_six_amplitude_inviscid_cubic_problem"]
    assert not payload["claims"]["full_64d_inviscid_cubic_global_maximum"]
    sympy = pytest.importorskip("sympy")
    a, b, c, d, e, f = (
        sympy.sqrt(69) / 23,
        -sympy.sqrt(690) / 552,
        sympy.sqrt(345) / 276,
        sympy.sqrt(690) / 138,
        sympy.sqrt(69) / 276,
        sympy.sqrt(138) / 69,
    )
    enstrophy = 2 * a**2 + 32 * b**2 + 48 * c**2 + 8 * d**2 + 48 * e**2 + 4 * f**2
    stretching = 64 * a * c * d + 32 * a * e * f - 64 * b * d * f
    palinstrophy = 2 * a**2 + 128 * b**2 + 144 * c**2 + 16 * d**2 + 144 * e**2 + 8 * f**2
    assert sympy.simplify(enstrophy - 1) == 0
    assert sympy.simplify(stretching - 8 * sympy.sqrt(138) / 207) == 0
    assert sympy.simplify(palinstrophy - sympy.Rational(148, 69)) == 0


def test_inviscid_amplitude_ray_follows_from_the_exact_parameterized_branch():
    sympy = pytest.importorskip("sympy")
    mu = sympy.symbols("mu", positive=True)
    eta = (
        69 * mu**4 + 1696 * mu**3 + 14936 * mu**2 + 54656 * mu + 68368
    ) / (32 * (mu + 8) ** 2)
    nu = 1 / sympy.sqrt(eta)
    a2 = nu**2 * 3 * (mu + 6) * (3 * mu**2 + 48 * mu + 156) / (32 * (mu + 8))
    d2 = nu**2 * (5 * mu**2 + 48 * mu + 100) / 64
    f2 = nu**2 * (mu**2 - 28) / 16
    a, d, f = (sympy.sqrt(a2), sympy.sqrt(d2), sympy.sqrt(f2))
    b = -d * f / (nu * (mu + 8))
    c = 2 * a * d / (3 * nu * (mu + 6))
    e = a * f / (3 * nu * (mu + 6))
    limits = [sympy.simplify(sympy.limit(value, mu, sympy.oo)) for value in (a, b, c, d, e, f)]
    assert limits == [
        sympy.sqrt(69) / 23,
        -sympy.sqrt(690) / 552,
        sympy.sqrt(345) / 276,
        sympy.sqrt(690) / 138,
        sympy.sqrt(69) / 276,
        sympy.sqrt(138) / 69,
    ]
