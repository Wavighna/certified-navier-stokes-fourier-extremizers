import jax
import jax.numpy as jnp
import numpy as np

from extreme_flows.spectral import (
    SpectralGrid,
    abc_flow,
    diagnostics,
    ifft_velocity,
    physical_to_state,
    oversampled_max_vorticity,
    resample_state,
    rhs,
    rk4_step,
    strain_alignment_diagnostics,
)

jax.config.update("jax_enable_x64", True)


def test_projection_enforces_incompressibility_and_zero_mean():
    grid = SpectralGrid(12)
    key = jax.random.PRNGKey(7)
    raw = jax.random.normal(key, (grid.n, grid.n, grid.n, 3))
    state = physical_to_state(raw, grid)
    diag = diagnostics(state, grid, viscosity=0.01)
    physical = np.asarray(ifft_velocity(state))

    assert float(diag["divergence_l2"]) < 1e-11
    assert np.linalg.norm(physical.mean(axis=(0, 1, 2))) < 1e-12


def test_abc_is_steady_for_euler_and_laplacian_eigenflow_for_ns():
    grid = SpectralGrid(12)
    state = abc_flow(grid)
    euler_rhs = rhs(state, grid, viscosity=0.0)
    ns_rhs = rhs(state, grid, viscosity=0.025)

    relative_euler = np.linalg.norm(np.asarray(euler_rhs)) / np.linalg.norm(
        np.asarray(state)
    )
    relative_ns_error = np.linalg.norm(np.asarray(ns_rhs + 0.025 * state)) / np.linalg.norm(
        np.asarray(state)
    )
    assert relative_euler < 1e-11
    assert relative_ns_error < 1e-11


def test_enstrophy_rate_matches_short_time_finite_difference():
    grid = SpectralGrid(12)
    key = jax.random.PRNGKey(11)
    raw = jax.random.normal(key, (grid.n, grid.n, grid.n, 3))
    state = physical_to_state(raw, grid)
    viscosity = 0.02
    dt = 1e-5

    before = diagnostics(state, grid, viscosity)
    after_state = rk4_step(state, grid, viscosity, dt)
    after = diagnostics(after_state, grid, viscosity)
    finite_difference = (float(after["enstrophy"]) - float(before["enstrophy"])) / dt
    exact_rate = float(before["enstrophy_rate"])

    assert np.isclose(finite_difference, exact_rate, rtol=2e-3, atol=2e-5)


def test_euler_energy_is_conserved_over_short_run():
    grid = SpectralGrid(12)
    key = jax.random.PRNGKey(23)
    raw = jax.random.normal(key, (grid.n, grid.n, grid.n, 3))
    state = physical_to_state(raw, grid)
    e0 = float(diagnostics(state, grid, 0.0)["energy"])

    for _ in range(10):
        state = rk4_step(state, grid, viscosity=0.0, dt=1e-4)
    e1 = float(diagnostics(state, grid, 0.0)["energy"])

    assert abs(e1 - e0) / e0 < 1e-10


def test_spectral_refinement_preserves_low_mode_diagnostics():
    coarse = SpectralGrid(10)
    fine = SpectralGrid(20)
    state = abc_flow(coarse, a=1.0, b=0.5, c=1.5)
    refined = resample_state(state, coarse, fine)
    coarse_diag = diagnostics(state, coarse, viscosity=0.01)
    fine_diag = diagnostics(refined, fine, viscosity=0.01)

    for key in ("energy", "enstrophy", "helicity", "enstrophy_rate"):
        assert np.isclose(
            float(coarse_diag[key]), float(fine_diag[key]), rtol=1e-12, atol=1e-12
        )


def test_palinstrophy_and_strain_decomposition_are_consistent():
    grid = SpectralGrid(12)
    key = jax.random.PRNGKey(29)
    state = physical_to_state(
        jax.random.normal(key, (grid.n, grid.n, grid.n, 3)), grid
    )
    diag = diagnostics(state, grid, viscosity=0.03)
    alignment = strain_alignment_diagnostics(state, grid)

    assert np.isclose(
        float(diag["viscous_dissipation"]),
        2.0 * 0.03 * float(diag["palinstrophy"]),
        rtol=1e-13,
    )
    assert np.isclose(
        np.asarray(alignment["stretching_contributions"]).sum(),
        float(diag["stretching"]),
        rtol=1e-12,
        atol=1e-12,
    )
    assert np.isclose(
        np.asarray(alignment["vorticity_alignment_fractions"]).sum(),
        1.0,
        rtol=1e-12,
        atol=1e-12,
    )
    assert float(alignment["betchov_relative_residual"]) < 1e-11
    factorized = (
        4.0
        / (3.0 * np.sqrt(6.0))
        * float(alignment["strain_topology_factor"])
        * float(alignment["normalized_strain_concentration"])
    )
    assert np.isclose(
        factorized,
        float(alignment["normalized_stretching"]),
        rtol=1e-11,
        atol=1e-11,
    )


def test_oversampled_vorticity_max_does_not_decrease():
    grid = SpectralGrid(12)
    key = jax.random.PRNGKey(31)
    state = physical_to_state(
        jax.random.normal(key, (grid.n, grid.n, grid.n, 3)), grid
    )
    native = float(diagnostics(state, grid, viscosity=0.0)["max_vorticity"])
    padded = float(oversampled_max_vorticity(state, grid, factor=2))
    assert padded >= native * (1.0 - 1e-13)
