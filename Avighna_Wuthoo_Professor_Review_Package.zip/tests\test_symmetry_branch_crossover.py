"""Regression guard for the rigorously certified symmetry-branch switch."""

from __future__ import annotations

import json
from hashlib import sha256
from pathlib import Path


def test_crossover_certificate_reports_the_limited_branch_ordering() -> None:
    payload = json.loads(
        Path("artifacts/proofs/symmetry_branch_crossover.json").read_text(encoding="utf-8")
    )
    claims = payload["claims"]
    assert claims["unique_positive_resultant_root"]
    assert claims["unique_crossing_on_the_high_eta_six_amplitude_branch"]
    assert claims["ordering_on_either_side"]
    assert not claims["full_64d_global_ordering"]
    for run in payload["arb_runs"]:
        assert run["verified"]
    assert payload["dependency"]["python_flint"] == "0.9.0"
    for record in payload["checker_source"].values():
        path = Path(record["path"])
        assert record["sha256"] == sha256(path.read_bytes()).hexdigest()
    assert all(
        run["competing_branch_higher"]
        for run in payload["ordering_anchors"]["eta_10000"]
    )
    assert all(
        run["six_amplitude_branch_higher"]
        for run in payload["ordering_anchors"]["eta_40000"]
    )
