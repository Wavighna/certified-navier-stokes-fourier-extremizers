import json
from pathlib import Path

import jax
import numpy as np
import pytest

from extreme_flows.low_modes import load_low_mode_candidate
from extreme_flows.spectral import SpectralGrid
from scripts.analyze_mechanisms import (
    _select_endpoint_states,
    analyze_archive,
)

jax.config.update("jax_enable_x64", True)

CANDIDATE = (
    Path(__file__).parents[1]
    / "artifacts"
    / "candidates"
    / "depletion_v3_low_modes.json"
)


def _candidate_state(n: int = 12) -> np.ndarray:
    return np.asarray(load_low_mode_candidate(CANDIDATE).lift(SpectralGrid(n)))


def test_multires_archive_prefers_validation_endpoint_and_reports_guard(tmp_path):
    state = _candidate_state()
    archive_path = tmp_path / "multires.npz"
    metadata = {
        "joint_config": {"dt": 0.001, "steps": 208},
        "validation": [
            {
                "dt": 0.0005,
                "steps": 416,
                "grids": [{"n": 12}],
            }
        ],
    }
    np.savez_compressed(
        archive_path,
        final_state_n12=1.2 * state,
        validation_final_state_n12=1.1 * state,
        metadata=np.asarray(json.dumps(metadata)),
    )

    payload = analyze_archive(
        archive_path,
        candidate=CANDIDATE,
        grid_n=12,
    )

    assert payload["selection"]["mode"] == "candidate_reconstructed_initial"
    assert payload["selection"]["final_state_key"] == "validation_final_state_n12"
    assert payload["positivity_guard"]["scope"] == "endpoints only"
    assert "no pathwise positivity claim" in payload["positivity_guard"][
        "description"
    ]
    assert payload["ledger"]["guard_scope"] == "endpoints only"
    assert payload["checks"]["endpoint_logarithmic_budget_valid"]
    assert payload["checks"]["identities_within_tolerance"]
    assert payload["time_final"] == pytest.approx(0.208)
    assert payload["ledger"]["enstrophy_amplification"] == pytest.approx(1.21)
    assert abs(payload["ledger"]["beta"]["direct"]) < 1.0e-12


def test_legacy_state_pair_remains_the_default(tmp_path):
    state = _candidate_state()
    archive_path = tmp_path / "legacy.npz"
    np.savez_compressed(archive_path, state=state, final_state=1.1 * state)

    with np.load(archive_path) as archive:
        initial, final, selection = _select_endpoint_states(
            archive,
            candidate=None,
            requested_grid=None,
        )

    assert selection["mode"] == "legacy_archive_pair"
    assert selection["initial_state_key"] == "state"
    assert selection["final_state_key"] == "final_state"
    np.testing.assert_array_equal(initial, state)
    np.testing.assert_array_equal(final, 1.1 * state)


def test_multires_archive_requires_grid_when_endpoint_resolutions_are_ambiguous(
    tmp_path,
):
    state = _candidate_state()
    archive_path = tmp_path / "multiple_grids.npz"
    np.savez_compressed(
        archive_path,
        final_state_n12=state,
        validation_final_state_n16=np.zeros((16, 16, 16, 3), dtype=np.complex128),
    )

    with np.load(archive_path) as archive, pytest.raises(
        ValueError, match="--grid is required"
    ):
        _select_endpoint_states(
            archive,
            candidate=CANDIDATE,
            requested_grid=None,
        )
