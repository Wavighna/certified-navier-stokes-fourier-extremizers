# Paper A release materials

This directory is the complete supporting package for the finite-dimensional
static-extremizer paper. The authoritative integrity record is
`artifacts/proofs/paper_a_release_manifest.json`.

## Start here

- `output/pdf/paper_a_static_extremizers.pdf` — rendered manuscript.
- `paper/main.tex` and `paper/references.bib` — submission source.
- `paper/REVIEWER_GUIDE.md` — claim-to-evidence map.
- `paper/PRE_SUBMISSION_AUDIT.md` — scope and remaining external submission gates.
- `artifacts/proofs/paper_a_verification.json` — latest theorem-claim result.
- `artifacts/proofs/paper_a_release_manifest.json` — SHA-256 manifest.

## Reproduction

With the pinned package versions in `pyproject.toml` and `python-flint==0.9.0`:

```powershell
.venv\Scripts\python.exe scripts\verify_paper_a.py
.venv\Scripts\python.exe scripts\build_paper_a_manifest.py
```

The verifier recomputes the finite-dimensional exact and interval certificates.
It does not claim a full Navier--Stokes regularity result, finite-time
singularity result, or full 64-dimensional global maximizer.

## Package contents

- `paper/`: manuscript, bibliography, figure assets, reviewer and priority notes.
- `src/`: exact Fourier algebra and certificate implementation.
- `scripts/`: proof checkers, independent algebra audits, and reproducibility tools.
- `tests/`: regression and source-consistency tests.
- `artifacts/proofs/`: candidates, Arb/Krawczyk records, exact SOS certificates,
  verification output, and release manifest.
- `artifacts/raw/`: numerical exploration and validation provenance, including
  rejected/depletion studies. These data are supporting material, not theorem
  evidence unless explicitly identified as such by the manuscript or manifest.
- `artifacts/candidates/`: grid-independent candidate controls.
- `notes/`, `RESEARCH_LEDGER.md`, and `FINDINGS.md`: derivations, negative
  results, research history, and truth labels.
