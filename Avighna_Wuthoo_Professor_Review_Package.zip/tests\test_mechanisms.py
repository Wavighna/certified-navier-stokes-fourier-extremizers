from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import pytest

from extreme_flows.mechanisms import (
    IDENTITY_RESIDUAL_NAMES,
    endpoint_mechanism_ledger,
    mechanism_diagnostics,
    miller_residual_strain,
)
from extreme_flows.spectral import SpectralGrid, physical_to_state

jax.config.update("jax_enable_x64", True)


def test_betchov_miller_factorizations_and_orthogonality_are_exact():
    grid = SpectralGrid(12)
    state = physical_to_state(
        jax.random.normal(jax.random.PRNGKey(101), (12, 12, 12, 3)),
        grid,
    )
    values = mechanism_diagnostics(state, grid)
    residual = miller_residual_strain(state, grid)

    assert 0.0 < float(values["d"]) < 1.0
    assert abs(float(values["Theta"])) <= 1.0 + 1.0e-12
    assert abs(float(values["H"])) <= 1.0 + 1.0e-12
    assert np.isclose(
        np.mean(np.sum(np.asarray(residual) ** 2, axis=(-1, -2))),
        float(values["E"] * values["d"]),
        rtol=1.0e-11,
        atol=1.0e-11,
    )
    assert np.isclose(
        float(values["chi"]),
        float(values["chi_betchov"]),
        rtol=1.0e-11,
        atol=1.0e-11,
    )
    assert np.isclose(
        float(values["chi"]),
        float(values["chi_dual"]),
        rtol=1.0e-11,
        atol=1.0e-11,
    )
    for name in IDENTITY_RESIDUAL_NAMES:
        assert float(values[name]) < 1.0e-10, name


def test_endpoint_ledger_refuses_undefined_logarithms():
    invalid = {
        "K": 0.0,
        "E": 0.0,
        "P": 0.0,
        "Q": 0.0,
        "A": -1.0,
        "Theta": -0.5,
        "I3": 0.0,
        "rho": 0.0,
        "d": 0.0,
        "H": -0.25,
        "J4": 0.0,
        "chi": -0.1,
        "chi_betchov": -0.1,
        "chi_dual": -0.1,
        **{name: 0.0 for name in IDENTITY_RESIDUAL_NAMES},
    }
    ledger = endpoint_mechanism_ledger(invalid, invalid)

    assert not ledger["valid"]
    assert ledger["exponents"] is None
    assert all(value is None for value in ledger["beta"].values())
    assert ledger["signed_factors"]["A"] == {
        "initial": -1.0,
        "final": -1.0,
    }


RAW_D3_N48 = (
    Path(__file__).parents[1]
    / "artifacts"
    / "raw"
    / "depletion_v3_lift_n48_t0208.npz"
)


@pytest.mark.skipif(not RAW_D3_N48.exists(), reason="untracked N48 research archive absent")
def test_d3_n48_endpoint_beta_and_both_ledgers_regression():
    archive = np.load(RAW_D3_N48)
    grid = SpectralGrid(48)
    initial = mechanism_diagnostics(jnp.asarray(archive["state"]), grid)
    final = mechanism_diagnostics(jnp.asarray(archive["final_state"]), grid)
    ledger = endpoint_mechanism_ledger(initial, final)

    expected_beta = 0.3143076647975669
    assert ledger["valid"]
    assert np.isclose(
        ledger["beta"]["direct"], expected_beta, rtol=0.0, atol=1.0e-12
    )
    assert abs(ledger["ledger_agreement"]["betchov_minus_direct"]) < 1.0e-10
    assert abs(ledger["ledger_agreement"]["dual_minus_direct"]) < 1.0e-10
    assert ledger["maximum_identity_residual"] < 1.0e-10
