from scripts.scan_six_branch_stability import scan


def test_six_branch_full_hessian_atlas_has_expected_sampled_inertia():
    payload = scan([467.0, 1_000.0, 1_000_000.0])
    assert payload["summary"]["all_sampled_nontranslation_eigenvalues_negative"]
    assert payload["summary"]["full_space_uniform_local_maximum_proved"] is False
    for row in payload["rows"]:
        assert row["max_abs_full_kkt_residual"] < 1.0e-10
        assert row["negative_nontranslation_eigenvalue_count"] == 60
        assert row["positive_nontranslation_eigenvalue_count"] == 0
        assert row["translation_zero_count_numerical"] == 3
