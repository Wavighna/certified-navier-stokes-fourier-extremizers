"""Numerical dense SOS reconnaissance for the final ``(3,3,4)`` shell block.

This deliberately uses no unproved symmetry reduction because canonical
shell-three polarizations mix under cube rotations. It is a numerical search,
not a certificate.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
from itertools import combinations_with_replacement
import json
from pathlib import Path

import cvxpy as cp
import numpy as np

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.inviscid_sos_target import exact_stretching_cubic_terms
from extreme_flows.shellwise_bounds import _add, _shell_indices, shell_of_coordinate


def build_system(constant: Fraction):
    model = StaticLowModePolynomial(); three, four = _shell_indices(model, 3), _shell_indices(model, 4)
    three_pos={index:item for item,index in enumerate(three)}; four_pos={index:item for item,index in enumerate(four)}
    components=[defaultdict(Fraction) for _ in four]
    for monomial, coefficient in exact_stretching_cubic_terms(model).items():
        if tuple(sorted(shell_of_coordinate(model,index) for index in monomial)) != (3,3,4): continue
        pair=tuple(sorted(three_pos[index] for index in monomial if index in three_pos))
        linear=next(index for index in monomial if index in four_pos)
        components[four_pos[linear]][pair]+=coefficient
    target={}
    for left,gl in enumerate(three):
        for right,gr in enumerate(three):
            _add(target,(left,left,right,right),constant/4*model.enstrophy_diagonal_exact[gl]*model.enstrophy_diagonal_exact[gr])
    for pos,component in enumerate(components):
        divisor=model.enstrophy_diagonal_exact[four[pos]]
        for left,lv in component.items():
            for right,rv in component.items(): _add(target,left+right,-2*lv*rv/divisor)
    basis=tuple(combinations_with_replacement(range(16),2)); pos={m:i for i,m in enumerate(basis)}
    entries=tuple((i,j) for i in range(136) for j in range(i,136)); ep={e:i for i,e in enumerate(entries)}
    support=sorted({tuple(sorted(basis[i]+basis[j])) for i,j in entries}|set(target)); rp={m:i for i,m in enumerate(support)}
    mat=np.zeros((len(support),len(entries))); rhs=np.zeros(len(support))
    for col,(left,right) in enumerate(entries): mat[rp[tuple(sorted(basis[left]+basis[right]))],col]=1 if left==right else 2
    for m,v in target.items(): rhs[rp[m]]=float(v)
    return mat,rhs,entries


def main():
    p=argparse.ArgumentParser();p.add_argument('--constant',default='2/27');p.add_argument('--output',default='tmp/shell334_sdp.json');a=p.parse_args()
    c=Fraction(a.constant);mat,rhs,entries=build_system(c); x=cp.Variable(len(entries)); G=cp.Variable((136,136),symmetric=True)
    constraints=[mat@x==rhs,G>>0]
    for col,(i,j) in enumerate(entries): constraints.append(G[i,j]==x[col])
    prob=cp.Problem(cp.Minimize(cp.trace(G)),constraints);prob.solve(solver='CLARABEL',max_iter=50_000)
    ev=np.linalg.eigvalsh(G.value) if G.value is not None else np.array([])
    out={'truth_label':'numerical_sos_search_not_a_certificate','constant':str(c),'status':prob.status,'objective':None if prob.value is None else float(prob.value),'equation_count':int(mat.shape[0]),'symmetric_gram_entries':len(entries),'max_residual':None if x.value is None else float(np.max(np.abs(mat@x.value-rhs))),'min_eigenvalue':None if not ev.size else float(ev[0])}
    path=Path(a.output);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
    if G.value is not None:
        np.savez_compressed(path.with_suffix('.npz'), gram=np.asarray(G.value), entries=np.asarray(entries), coefficient_solution=np.asarray(x.value))


if __name__=='__main__': main()
