<#
Run the expensive Paper-A verifier only after a bounded numerical campaign
has exited.  This avoids treating a timeout under CPU contention as a failed
proof and leaves an auditable transcript under artifacts/raw.

It is a convenience launcher, not part of the mathematical proof checker.
#>
param(
    [int]$CampaignProcessId,
    [int]$PollSeconds = 30
)

$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $PSScriptRoot
$Log = Join-Path $Root 'artifacts\raw\paper_a_post_campaign_verification.log'

while (Get-Process -Id $CampaignProcessId -ErrorAction SilentlyContinue) {
    Start-Sleep -Seconds $PollSeconds
}

Set-Location -LiteralPath $Root
& .venv\Scripts\python.exe scripts\verify_paper_a.py *>&1 |
    Tee-Object -LiteralPath $Log
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

& .venv\Scripts\python.exe scripts\build_paper_a_manifest.py *>&1 |
    Tee-Object -LiteralPath $Log -Append
if ($LASTEXITCODE -ne 0) {
    exit $LASTEXITCODE
}

& .venv\Scripts\python.exe -m pytest `
    tests\test_reduced_static_parameterized_global.py `
    tests\test_verify_paper_a.py `
    tests\test_paper_release_manifest.py `
    tests\test_paper_source.py `
    tests\test_proof_provenance.py -q *>&1 |
    Tee-Object -LiteralPath $Log -Append
exit $LASTEXITCODE
