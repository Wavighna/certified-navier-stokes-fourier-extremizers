"""Arb certificate for the six-amplitude static-production ansatz.

This checker is deliberately independent from the 64-variable certificate.
It proves a local constrained maximum *within the explicit six-amplitude
ansatz* and does not infer exact membership of the nearby 64-variable root.
"""

from __future__ import annotations

from fractions import Fraction
from hashlib import sha256
import importlib.metadata
import json
from pathlib import Path
import platform
import sys
from typing import Sequence

import numpy as np

from .reduced_static import reduced_amplitudes_from_controls


_E_WEIGHTS = (2, 32, 48, 8, 48, 4)
_P_WEIGHTS = (2, 128, 144, 16, 144, 8)
_VISCOSITY = Fraction(1, 100)
_TARGET_ENSTROPHY = Fraction(100)


def _arb_fraction(value: Fraction | int):
    from flint import arb

    value = Fraction(value)
    return arb(value.numerator) / arb(value.denominator)


def _vector(values: Sequence[object]):
    from flint import arb_mat

    return arb_mat([[value] for value in values])


def _identity(size: int):
    from flint import arb, arb_mat

    return arb_mat([[arb(int(i == j)) for j in range(size)] for i in range(size)])


def _components(point: Sequence[object]):
    """Evaluate the 7-variable KKT system and symmetric bordered Hessian."""

    from flint import arb, arb_mat

    if len(point) != 7:
        raise ValueError("expected six amplitudes and one multiplier")
    a, b, c, d, e, f, multiplier = point
    nu = _arb_fraction(_VISCOSITY)
    values = (a, b, c, d, e, f)
    e_weights = [_arb_fraction(weight) for weight in _E_WEIGHTS]
    p_weights = [_arb_fraction(weight) for weight in _P_WEIGHTS]

    grad_e = [2 * e_weights[i] * values[i] for i in range(6)]
    grad_r = [
        64 * c * d + 32 * e * f - 8 * nu * a,
        -64 * d * f - 512 * nu * b,
        64 * a * d - 576 * nu * c,
        64 * a * c - 64 * b * f - 64 * nu * d,
        32 * a * f - 576 * nu * e,
        32 * a * e - 64 * b * d - 32 * nu * f,
    ]
    residual = [
        grad_r[index] - multiplier * grad_e[index] for index in range(6)
    ]
    enstrophy = sum(
        (e_weights[index] * values[index] * values[index] for index in range(6)),
        arb(0),
    )
    residual.append(enstrophy - _arb_fraction(_TARGET_ENSTROPHY))

    hessian = [[arb(0) for _ in range(6)] for _ in range(6)]
    diagonal = (-8 * nu, -512 * nu, -576 * nu, -64 * nu, -576 * nu, -32 * nu)
    for index in range(6):
        hessian[index][index] = diagonal[index] - 2 * multiplier * e_weights[index]
    for i, j, value in (
        (0, 2, 64 * d),
        (0, 3, 64 * c),
        (0, 4, 32 * f),
        (0, 5, 32 * e),
        (1, 3, -64 * f),
        (1, 5, -64 * d),
        (2, 3, 64 * a),
        (3, 5, -64 * b),
        (4, 5, 32 * a),
    ):
        hessian[i][j] = value
        hessian[j][i] = value

    kkt = [[arb(0) for _ in range(7)] for _ in range(7)]
    bordered = [[arb(0) for _ in range(7)] for _ in range(7)]
    for i in range(6):
        for j in range(6):
            kkt[i][j] = hessian[i][j]
            bordered[i][j] = hessian[i][j]
        kkt[i][6] = -grad_e[i]
        kkt[6][i] = grad_e[i]
        bordered[i][6] = grad_e[i]
        bordered[6][i] = grad_e[i]
    return residual, arb_mat(kkt), arb_mat(bordered)


def _refine(initial: Sequence[float], *, iterations: int = 6):
    from flint import arb

    point = [arb(repr(float(value))).mid() for value in initial]
    for _ in range(iterations):
        residual, jacobian, _ = _components(point)
        correction = jacobian.solve(_vector(residual))
        point = [(point[i] - correction[i, 0]).mid() for i in range(7)]
    residual, _, _ = _components(point)
    return point, residual


def _krawczyk(center: Sequence[object], *, radius_exponents: Sequence[int] = (30, 40, 50, 60)):
    """Produce an existence-and-uniqueness Krawczyk inclusion."""

    from flint import arb, arb_mat

    residual, jacobian, _ = _components(center)
    inverse = jacobian.inv()
    preconditioner = arb_mat([[inverse[i, j].mid() for j in range(7)] for i in range(7)])
    determinant = preconditioner.det()
    nonsingular = not determinant.contains(0)
    newton_center = _vector(center) - preconditioner * _vector(residual)
    identity = _identity(7)
    attempts: list[dict[str, object]] = []
    for exponent in radius_exponents:
        base_radius = arb(2) ** (-int(exponent))
        box = []
        delta = []
        for value in center:
            scale = abs(value)
            if scale < 1:
                scale = arb(1)
            radius = (base_radius * scale).upper()
            enclosed = arb(value, radius)
            box.append(enclosed)
            delta.append(enclosed - value)
        _, interval_jacobian, bordered = _components(box)
        defect = identity - preconditioner * interval_jacobian
        image = newton_center + defect * _vector(delta)
        included = [box[i].contains_interior(image[i, 0]) for i in range(7)]
        weights = [entry.abs_upper() for entry in delta]
        rows = [
            sum((defect[i, j].abs_upper() * weights[j] for j in range(7)), arb(0))
            / weights[i]
            for i in range(7)
        ]
        contraction = max(rows, key=float)
        strict = all(row < 1 for row in rows)
        attempt = {
            "radius_power_of_two": -int(exponent),
            "all_components_strictly_interior": all(included),
            "failed_component_count": included.count(False),
            "max_image_to_box_radius_ratio": max(
                float(image[i, 0].rad() / box[i].rad()) for i in range(7)
            ),
            "preconditioner_nonsingular": nonsingular,
            "weighted_infinity_contraction_strictly_below_one": strict,
            "weighted_infinity_contraction_upper_float": float(contraction),
        }
        attempts.append(attempt)
        if all(included) and nonsingular and strict:
            return {
                "verified": True,
                "box": box,
                "bordered_hessian": bordered,
                "preconditioner_determinant": determinant,
                "contraction_upper": contraction,
                "attempts": attempts,
                "selected_attempt": attempt,
            }
    return {"verified": False, "attempts": attempts}


def _inertia(matrix) -> dict[str, object]:
    """Certify symmetric inertia through dyadic congruence and Gershgorin."""

    from flint import arb, arb_mat

    midpoint = np.asarray(
        [[float(matrix[i, j].mid()) for j in range(7)] for i in range(7)]
    )
    midpoint = 0.5 * (midpoint + midpoint.T)
    _, vectors = np.linalg.eigh(midpoint)
    congruence = arb_mat(
        [[arb(repr(float(vectors[i, j]))).mid() for j in range(7)] for i in range(7)]
    )
    transformed = congruence.transpose() * matrix * congruence
    positive = negative = unresolved = 0
    margins = []
    for i in range(7):
        off = sum(
            (transformed[i, j].abs_upper() for j in range(7) if j != i), arb(0)
        )
        positive_margin = transformed[i, i].lower() - off
        negative_margin = -transformed[i, i].upper() - off
        if positive_margin > 0:
            positive += 1
            margins.append(positive_margin)
        elif negative_margin > 0:
            negative += 1
            margins.append(negative_margin)
        else:
            unresolved += 1
    return {
        "verified": not congruence.det().contains(0) and unresolved == 0,
        "positive": positive,
        "negative": negative,
        "zero_or_unresolved": unresolved,
        "minimum_signed_gershgorin_margin": min(margins, key=float) if margins else arb(0),
    }


def _ball(value) -> dict[str, object]:
    return {
        "ball": str(value),
        "lower": str(value.lower()),
        "upper": str(value.upper()),
        "finite": bool(value.is_finite()),
    }


def _dependency() -> dict[str, object]:
    distribution = importlib.metadata.distribution("python-flint")
    root = Path(distribution.locate_file(""))
    record = root / "python_flint-0.9.0.dist-info" / "RECORD"
    metadata = root / "python_flint-0.9.0.dist-info" / "METADATA"
    return {
        "package": "python-flint",
        "version": distribution.version,
        "python": sys.version,
        "platform": platform.platform(),
        "record_sha256": sha256(record.read_bytes()).hexdigest(),
        "metadata_sha256": sha256(metadata.read_bytes()).hexdigest(),
    }


def _source_record(script_name: str) -> dict[str, object]:
    module = Path(__file__).resolve()
    root = module.parents[2]
    script = root / "scripts" / script_name
    def record(path: Path) -> dict[str, object]:
        payload = path.read_bytes()
        return {
            "path": path.relative_to(root).as_posix(),
            "size_bytes": len(payload),
            "sha256": sha256(payload).hexdigest(),
        }
    return {"module": record(module), "script": record(script)}


def evaluate_reduced_static_certificate_arb(
    candidate: dict[str, object], *, precision: int
) -> dict[str, object]:
    """Run one Arb precision for the reduced constrained local maximum."""

    from flint import ctx

    ctx.prec = int(precision)
    amplitudes = reduced_amplitudes_from_controls(candidate["controls"])  # type: ignore[arg-type]
    initial = [*amplitudes, float(candidate["multipliers"][0])]  # type: ignore[index]
    center, residual = _refine(initial)
    krawczyk = _krawczyk(center)
    if not krawczyk["verified"]:
        return {"precision_bits": precision, "krawczyk_verified": False, "krawczyk": krawczyk}
    inertia = _inertia(krawczyk["bordered_hessian"])
    krawczyk_record = {
        "verified": True,
        "attempts": krawczyk["attempts"],
        "selected_attempt": krawczyk["selected_attempt"],
        "preconditioner_determinant": _ball(
            krawczyk["preconditioner_determinant"]
        ),
        "weighted_infinity_contraction_upper": _ball(
            krawczyk["contraction_upper"]
        ),
    }
    inertia_record = {
        **{
            key: value
            for key, value in inertia.items()
            if key != "minimum_signed_gershgorin_margin"
        },
        "minimum_signed_gershgorin_margin": _ball(
            inertia["minimum_signed_gershgorin_margin"]
        ),
    }
    return {
        "precision_bits": precision,
        "krawczyk_verified": True,
        "existence_verified": True,
        "uniqueness_verified": True,
        "krawczyk": krawczyk_record,
        "bordered_inertia": inertia_record,
        "root_box_balls": [_ball(value) for value in krawczyk["box"]],
        "refined_residual_balls": [_ball(value) for value in residual],
    }


def build_reduced_static_certificate(
    candidate_path: str | Path,
    *,
    precisions: Sequence[int] = (256, 512),
) -> dict[str, object]:
    """Build a proof-grade certificate for the reduced six-variable problem."""

    precision_set = tuple(int(value) for value in precisions)
    if len(set(precision_set)) < 2 or not {256, 512}.issubset(precision_set):
        raise ValueError("proof-grade builders require distinct 256-bit and 512-bit runs")
    source = Path(candidate_path)
    raw = json.loads(source.read_text(encoding="utf-8"))
    candidate = raw["candidate"]
    runs = [
        evaluate_reduced_static_certificate_arb(candidate, precision=precision)
        for precision in precision_set
    ]
    certified = all(
        run.get("krawczyk_verified")
        and run.get("bordered_inertia", {}).get("verified")
        and run["bordered_inertia"]["positive"] == 1
        and run["bordered_inertia"]["negative"] == 6
        for run in runs
    )
    amplitudes = reduced_amplitudes_from_controls(candidate["controls"])  # type: ignore[arg-type]
    return {
        "schema_version": 1,
        "truth_label": "proof_grade_reduced_static_local_maximum" if certified else "reduced_static_certificate_incomplete",
        "source": {
            "path": str(source).replace("\\", "/"),
            "sha256": sha256(source.read_bytes()).hexdigest(),
            "candidate_truth_label": raw.get("truth_label"),
        },
        "problem": {
            "amplitudes": "(a,b,c,d,e,f)",
            "viscosity": "1/100",
            "target_enstrophy": 100,
            "stretching": "64*a*c*d + 32*a*e*f - 64*b*d*f",
            "enstrophy": "2*a^2 + 32*b^2 + 48*c^2 + 8*d^2 + 48*e^2 + 4*f^2",
            "palinstrophy": "2*a^2 + 128*b^2 + 144*c^2 + 16*d^2 + 144*e^2 + 8*f^2",
        },
        "numerical_seed": {
            "amplitudes": list(amplitudes),
            "multiplier": candidate["multipliers"][0],
            "rate": candidate["rate"],
        },
        "arb": {"dependency": _dependency(), "runs": runs},
        "checker_source": _source_record("certify_reduced_static.py"),
        "claims": {
            "unique_reduced_kkt_root_in_reported_box": certified,
            "strict_local_maximum_within_six_amplitude_ansatz": certified,
            "global_maximum_within_ansatz": False,
            "exact_membership_of_full_64d_certified_root": False,
        },
        "limitations": {
            "six_amplitude_static_ansatz_only": True,
            "no_global_optimization_claim": True,
            "no_navier_stokes_trajectory_or_regularity_claim": True,
        },
    }


__all__ = [
    "build_reduced_static_certificate",
    "evaluate_reduced_static_certificate_arb",
]
