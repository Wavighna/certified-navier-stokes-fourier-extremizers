"""Rationalize the sparse numerical shell-334 Gram discovery and check it exactly.

The generated JSON is a candidate data object.  The exact polynomial and PSD
checks below, not the floating SDP, determine whether it can become a proof.
"""

from __future__ import annotations

from fractions import Fraction
import json
from itertools import combinations_with_replacement
from pathlib import Path

import numpy as np

from extreme_flows.shellwise_bounds import _gram_terms, _psd_pivots, shell334_quartic_target


ROOT = Path(__file__).resolve().parents[1]


def candidate_from_discovery() -> tuple[tuple[Fraction, ...], ...]:
    values = np.load(ROOT / "tmp" / "shell334_c2over27.npz")["gram"]
    gram = [[Fraction(0) for _ in range(136)] for _ in range(136)]
    for left in range(136):
        for right in range(left, 136):
            value = Fraction(float(values[left, right])).limit_denominator(100)
            if abs(float(values[left, right])) < 1e-6:
                value = Fraction(0)
            gram[left][right] = gram[right][left] = value
    return tuple(tuple(row) for row in gram)


def main() -> None:
    gram = candidate_from_discovery()
    target = shell334_quartic_target()
    if _gram_terms(gram, coordinate_dimension=16) != target:
        raise SystemExit("rationalized Gram does not exactly match the shell-334 target")
    pivots = _psd_pivots(gram)
    entries = [
        [left, right, str(gram[left][right])]
        for left in range(136)
        for right in range(left, 136)
        if gram[left][right]
    ]
    output = ROOT / "artifacts" / "proofs" / "shell334_rational_gram_candidate.json"
    output.write_text(json.dumps({"dimension": 136, "entries": entries, "positive_pivots": len(pivots)}, indent=2) + "\n", encoding="utf-8")
    print("exact identity and PSD passed", len(entries), len(pivots), output)


if __name__ == "__main__":
    main()
