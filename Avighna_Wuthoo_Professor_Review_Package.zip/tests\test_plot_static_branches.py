"""Checks that the Paper A branch figure uses the certified ordering anchors."""

from __future__ import annotations

import numpy as np

from scripts.plot_static_branches import (
    ASYMPTOTIC_TWO_TERM_PREDICTOR,
    CROSSOVER_ETA,
    competing_rate,
    six_branch_rate,
)


def test_plot_formula_respects_certified_ordering_anchors() -> None:
    eta = np.asarray([10_000.0, 40_000.0])
    difference = competing_rate(eta) - six_branch_rate(eta)
    assert difference[0] > 0.0
    assert difference[1] < 0.0


def test_two_term_predictor_is_close_but_not_substituted_for_certified_crossing():
    assert ASYMPTOTIC_TWO_TERM_PREDICTOR > CROSSOVER_ETA
    assert abs(ASYMPTOTIC_TWO_TERM_PREDICTOR / CROSSOVER_ETA - 1.0) < 0.04
