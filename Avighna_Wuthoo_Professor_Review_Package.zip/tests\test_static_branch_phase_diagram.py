from scripts.explore_static_branch_phase_diagram import explore_phase_diagram


def test_phase_diagram_exploration_preserves_exact_branch_order_and_scope():
    payload = explore_phase_diagram(
        eta_values=(10_000.0, 1_000_000.0),
        starts=1,
        seed=2026081204,
        max_iterations=120,
    )
    assert payload["truth_label"] == "numerical_static_branch_phase_diagram_exploration_only"
    assert payload["claims"]["full_64d_global_phase_diagram_proved"] is False
    lower, upper = payload["rows"]
    assert lower["two_minus_six"] > 0.0
    assert upper["two_minus_six"] < 0.0
    assert lower["restart_summary"]["full_global_maximum_proved"] is False
