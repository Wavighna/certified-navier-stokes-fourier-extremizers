import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_archived_generalized_hessian_block_factorization_has_expected_structure():
    payload = json.loads(
        (ROOT / "artifacts/proofs/competing_hessian_spectral_blocks.json").read_text(
            encoding="utf-8"
        )
    )
    assert payload["truth_label"] == (
        "exact_symbolic_competing_branch_generalized_hessian_block_factorization"
    )
    assert payload["claims"]["exact_generalized_hessian_sector_factorization"]
    assert not payload["claims"]["all_parameter_inertia_signs_proved_by_this_artifact"]
    assert not payload["claims"]["full_64d_global_maximum"]
    blocks = payload["derivation"]["blocks"]
    assert [blocks[name]["sector_dimension"] for name in (
        "trivial_even",
        "two_dimensional_even",
        "three_dimensional_even",
        "trivial_odd",
        "two_dimensional_odd",
        "three_dimensional_odd",
    )] == [2, 6, 24, 2, 6, 24]
    assert "t**3" in blocks["three_dimensional_odd"]["characteristic_polynomial"]
    assert "**2" in blocks["two_dimensional_even"]["characteristic_polynomial"]
    assert "**3" in blocks["three_dimensional_even"]["characteristic_polynomial"]


def test_archived_symbolic_continuation_has_exact_global_parameter_inertia():
    payload = json.loads(
        (ROOT / "artifacts/proofs/competing_all_eta_symbolic_continuation.json").read_text(
            encoding="utf-8"
        )
    )
    assert payload["claims"][
        "strict_full_space_local_maximum_modulo_translations_for_all_positive_eta"
    ]
    assert payload["exact_sample"]["full_generalized_hessian_inertia"] == {
        "positive": 1,
        "negative": 60,
        "zero": 3,
    }
    for block in payload["zero_crossing_certificate"].values():
        assert block["nontranslation_t_zero_root_count_on_open_unit_s_interval"] == 0
    assert payload["zero_crossing_certificate"]["three_dimensional_odd"][
        "translation_zero_multiplicity"
    ] == 3
    geometry = payload["constraint_and_orbit_geometry"]
    assert geometry["nontrivial_sectors_are_enstrophy_tangent"]
    assert geometry["all_translation_basis_tangents_in_odd_three_dimensional_sector"]
    assert geometry["branch_translation_gram_determinant"] == "8*(3+s^2)^3/729"
    assert geometry["branch_translation_orbit_dimension"] == 3
