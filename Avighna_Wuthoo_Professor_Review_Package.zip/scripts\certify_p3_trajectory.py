"""Generate the validated positive-time P3 trajectory certificate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from extreme_flows.trajectory_certificate import build_trajectory_certificate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "candidate",
        nargs="?",
        default="artifacts/candidates/persistent_v3_low_modes.json",
    )
    parser.add_argument(
        "--output",
        default="artifacts/proofs/p3_trajectory_certificate.json",
    )
    parser.add_argument("--precisions", nargs="+", type=int, default=(256, 512))
    args = parser.parse_args()

    payload = build_trajectory_certificate(args.candidate, precisions=args.precisions)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output}")
    print(payload["truth_label"])
    print(payload["claim"]["statement"])
    if not payload["claim"]["certified"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()

