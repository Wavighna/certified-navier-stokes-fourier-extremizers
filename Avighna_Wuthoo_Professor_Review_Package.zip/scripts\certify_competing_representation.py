"""Certify the rational isotypic split of the competing symmetry action."""

from __future__ import annotations

import json
from hashlib import sha256
from pathlib import Path

from extreme_flows.static_symmetry import competing_representation_sector_dimensions


ROOT = Path(__file__).resolve().parents[1]


def _record(relative: str) -> dict[str, object]:
    path = ROOT / relative
    data = path.read_bytes()
    return {
        "path": relative.replace("\\", "/"),
        "size_bytes": len(data),
        "sha256": sha256(data).hexdigest(),
    }


def build_payload() -> dict[str, object]:
    """Build the exact sector-dimension certificate."""

    decomposition = competing_representation_sector_dimensions()
    if not decomposition["exact_isotypic_decomposition_verified"]:
        raise AssertionError("competing representation sectors did not exhaust 64 controls")
    return {
        "schema_version": 1,
        "truth_label": "exact_isotypic_dimensions_of_competing_A4_times_C2_control_action",
        "statement": (
            "The exact 64-real-control action decomposes into rational ranks "
            "(2,6,24) in each central C2 parity sector. This is a symmetry "
            "block-structure certificate, not a uniform Hessian-sign theorem."
        ),
        "decomposition": decomposition,
        "checker_source": _record("scripts/certify_competing_representation.py"),
        "group_implementation": _record("src/extreme_flows/static_symmetry.py"),
        "claims": {
            "control_representation_isotypic_dimensions_certified": True,
            "parameter_uniform_full_space_local_maximum": False,
            "full_space_global_maximum": False,
        },
    }


def main() -> None:
    output = ROOT / "artifacts" / "proofs" / "competing_representation_sectors.json"
    output.write_text(json.dumps(build_payload(), indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
