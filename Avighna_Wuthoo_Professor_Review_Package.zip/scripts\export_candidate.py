"""Export a band-limited initial state as explicit continuous Fourier data."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import jax.numpy as jnp
import numpy as np

from extreme_flows.spectral import SpectralGrid, diagnostics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--tolerance", type=float, default=1.0e-12)
    args = parser.parse_args()

    archive = np.load(args.input)
    state = archive["state"]
    n = int(state.shape[0])
    grid = SpectralGrid(n)
    coefficients = state / n**3
    modes_1d = np.fft.fftfreq(n) * n
    records = []
    for i, kx in enumerate(modes_1d):
        for j, ky in enumerate(modes_1d):
            for k, kz in enumerate(modes_1d):
                coefficient = coefficients[i, j, k]
                if np.linalg.norm(coefficient) <= args.tolerance:
                    continue
                records.append(
                    {
                        "k": [int(kx), int(ky), int(kz)],
                        "real": coefficient.real.tolist(),
                        "imag": coefficient.imag.tolist(),
                    }
                )

    metadata = json.loads(str(archive["metadata"].item()))
    viscosity = float(metadata["config"]["viscosity"])
    diag = diagnostics(jnp.asarray(state), grid, viscosity)
    payload = {
        "format_version": 1,
        "source_archive": str(args.input),
        "source_sha256": hashlib.sha256(args.input.read_bytes()).hexdigest(),
        "domain": "[0,2*pi)^3 with periodic boundary conditions",
        "coefficient_convention": "u(x)=sum_k c_k exp(i k dot x)",
        "reality_condition": "c[-k]=conjugate(c[k])",
        "mean_zero": True,
        "viscosity": viscosity,
        "initial_diagnostics": {name: float(value) for name, value in diag.items()},
        "search_metadata": metadata,
        "nonzero_mode_count_including_conjugates": len(records),
        "modes": records,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(
        json.dumps(
            {
                "output": str(args.output),
                "mode_count": len(records),
                "sha256": payload["source_sha256"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
