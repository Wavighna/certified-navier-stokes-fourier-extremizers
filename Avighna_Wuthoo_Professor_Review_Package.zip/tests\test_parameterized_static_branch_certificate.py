from hashlib import sha256
import json
from pathlib import Path

from scripts.certify_parameterized_static_branch import build_certificate


def test_parameterized_branch_certificate_claims_are_properly_limited():
    payload = build_certificate()
    claims = payload["claims"]
    assert claims["unique_admissible_positive_interior_kkt_branch_for_eta_gt_1867_over_4"]
    assert not claims["parameter_uniform_global_maximum"]
    assert not claims["full_64d_global_maximum"]


def test_archived_parameterized_certificate_has_current_sources():
    payload = json.loads(
        Path("artifacts/proofs/parameterized_static_branch.json").read_text(
            encoding="utf-8"
        )
    )
    for source in payload["checker_source"].values():
        data = Path(source["path"]).read_bytes()
        assert source["size_bytes"] == len(data)
        assert source["sha256"] == sha256(data).hexdigest()
