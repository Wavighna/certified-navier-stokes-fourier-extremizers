"""Run a reproducible dense-field extreme-flow search."""

from __future__ import annotations

import argparse
import json
from dataclasses import asdict
from pathlib import Path
from time import perf_counter

import jax
import jax.numpy as jnp
import numpy as np

from extreme_flows.search import (
    SearchConfig,
    DIAGNOSTIC_NAMES,
    DEPLETION_OBJECTIVE_VERSION,
    INSTANTANEOUS_OBJECTIVE_VERSION,
    OBJECTIVE_VERSION,
    adam_ascent,
    constrained_state,
    depletion_objective,
    make_value_and_grad,
    persistence_objective,
    instantaneous_objective,
    trajectory_diagnostics,
)
from extreme_flows.spectral import SpectralGrid, diagnostics


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--mode", choices=("instant", "persistent", "depletion"), default="instant"
    )
    parser.add_argument("--n", type=int, default=12)
    parser.add_argument("--viscosity", type=float, default=0.01)
    parser.add_argument("--enstrophy", type=float, default=100.0)
    parser.add_argument("--dt", type=float, default=0.002)
    parser.add_argument("--steps", type=int, default=30)
    parser.add_argument("--delta", type=float, default=0.1)
    parser.add_argument("--target-amplification", type=float, default=2.0)
    parser.add_argument("--amplification-penalty", type=float, default=1.0e-2)
    parser.add_argument("--skip-time", type=float, default=0.0)
    parser.add_argument("--tail-weight", type=float, default=1.0e-1)
    parser.add_argument("--tail-threshold", type=float, default=1.0e-1)
    parser.add_argument("--initial-max-mode", type=float, default=3.0)
    parser.add_argument("--iterations", type=int, default=100)
    parser.add_argument("--learning-rate", type=float, default=0.03)
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument("--resume", type=Path)
    parser.add_argument("--output", type=Path, default=Path("artifacts/raw/search.npz"))
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    persistent = args.mode == "persistent"
    depletion = args.mode == "depletion"
    grid = SpectralGrid(args.n)
    config = SearchConfig(
        viscosity=args.viscosity,
        target_enstrophy=args.enstrophy,
        dt=args.dt,
        steps=args.steps,
        delta=args.delta,
        target_amplification=args.target_amplification,
        amplification_penalty=args.amplification_penalty,
        skip_time=args.skip_time,
        tail_weight=args.tail_weight,
        tail_threshold=args.tail_threshold,
        initial_max_mode=args.initial_max_mode,
    )
    if depletion:
        objective = depletion_objective
        value_and_grad = jax.jit(
            jax.value_and_grad(lambda theta: objective(theta, grid, config))
        )
    else:
        value_and_grad = make_value_and_grad(grid, config, persistent=persistent)
        objective = persistence_objective if persistent else instantaneous_objective

    initializations: list[tuple[str, jax.Array]] = []
    if args.resume is not None:
        resumed = np.load(args.resume)
        resume_theta = jnp.asarray(resumed["theta"])
        if resume_theta.shape != (args.n, args.n, args.n, 3):
            raise ValueError(
                f"resume theta shape {resume_theta.shape} does not match N={args.n}"
            )
        initializations.append(("resume", resume_theta))
    for seed in range(args.seeds):
        initializations.append(
            (
                f"random-{seed}",
                jax.random.normal(
                    jax.random.PRNGKey(seed),
                    (args.n, args.n, args.n, 3),
                    dtype=jnp.float64,
                ),
            )
        )
    if not initializations:
        raise ValueError("provide --resume or request at least one random seed")

    best = None
    started = perf_counter()
    for label, theta0 in initializations:
        initial_value = float(objective(theta0, grid, config))

        def report(iteration: int, value: float, _theta) -> None:
            if iteration == 1 or iteration % 20 == 0 or iteration == args.iterations:
                print(f"start={label} iteration={iteration} objective={value:.9e}", flush=True)

        theta, optimization_history = adam_ascent(
            theta0,
            value_and_grad,
            iterations=args.iterations,
            learning_rate=args.learning_rate,
            callback=report,
        )
        final_value = float(objective(theta, grid, config))
        print(
            f"start={label} initial={initial_value:.9e} final={final_value:.9e}",
            flush=True,
        )
        if best is None or final_value > best["objective"]:
            best = {
                "start": label,
                "objective": final_value,
                "theta": theta,
                "optimization_history": optimization_history,
            }

    assert best is not None
    state = constrained_state(best["theta"], grid, config)
    _, trajectory = trajectory_diagnostics(state, grid, config)
    initial_diagnostics = diagnostics(state, grid, config.viscosity)
    final_value, final_gradient = value_and_grad(best["theta"])
    theta_array = jnp.asarray(best["theta"])
    radial_component = (
        jnp.sum(final_gradient * theta_array)
        / jnp.maximum(jnp.sum(theta_array * theta_array), 1.0e-30)
    )
    tangent_gradient = final_gradient - radial_component * theta_array
    elapsed = perf_counter() - started

    args.output.parent.mkdir(parents=True, exist_ok=True)
    metadata = {
        "mode": args.mode,
        "n": args.n,
        "start": best["start"],
        "objective": best["objective"],
        "elapsed_seconds": elapsed,
        "config": asdict(config),
        "jax_version": jax.__version__,
        "diagnostic_names": DIAGNOSTIC_NAMES,
        "artifact_schema_version": 2,
        "objective_version": (
            DEPLETION_OBJECTIVE_VERSION
            if depletion
            else OBJECTIVE_VERSION
            if persistent
            else INSTANTANEOUS_OBJECTIVE_VERSION
        ),
        "final_objective_recomputed": float(final_value),
        "final_tangent_gradient_rms": float(
            jnp.sqrt(jnp.mean(tangent_gradient * tangent_gradient))
        ),
        "last_10_objective_gain": float(
            best["optimization_history"][-1]
            - best["optimization_history"][max(0, len(best["optimization_history"]) - 10)]
        ),
    }
    np.savez_compressed(
        args.output,
        theta=np.asarray(best["theta"]),
        state=np.asarray(state),
        optimization_history=np.asarray(best["optimization_history"]),
        trajectory=np.asarray(trajectory),
        metadata=np.asarray(json.dumps(metadata)),
    )
    printable = {key: float(value) for key, value in initial_diagnostics.items()}
    print(json.dumps({"metadata": metadata, "initial": printable}, indent=2))


if __name__ == "__main__":
    main()
