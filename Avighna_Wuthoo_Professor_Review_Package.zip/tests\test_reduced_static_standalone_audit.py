"""Regression guard for the independent six-amplitude Fourier audit."""

from scripts.audit_reduced_static_standalone import EXPECTED, _coefficients, audit


def test_standalone_six_amplitude_audit_recovers_every_polynomial_coefficient() -> None:
    coefficients = _coefficients()
    nonzero = {
        name: {term: value for term, value in polynomial.items() if value}
        for name, polynomial in coefficients.items()
    }
    assert nonzero == EXPECTED
    payload = audit()
    assert payload["all_coefficients_match"]
    assert payload["basis_mode_counts"] == [2, 4, 4, 2, 4, 2]
    assert "imports no project implementation" in payload["independence_statement"]
