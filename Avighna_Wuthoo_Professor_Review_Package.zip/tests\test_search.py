import jax
import numpy as np

from extreme_flows.search import (
    SearchConfig,
    constrained_state,
    depletion_objective,
    persistence_objective,
    soft_max,
    soft_min,
    spectral_enstrophy,
    trajectory_diagnostics,
)
from extreme_flows.spectral import SpectralGrid


def test_constraint_hits_target_enstrophy():
    grid = SpectralGrid(10)
    config = SearchConfig(target_enstrophy=12.5, steps=2, initial_max_mode=2.0)
    theta = jax.random.normal(jax.random.PRNGKey(2), (10, 10, 10, 3))
    state = constrained_state(theta, grid, config)
    assert np.isclose(float(spectral_enstrophy(state, grid)), 12.5, rtol=1e-12)


def test_trajectory_shape_and_finite_persistence_gradient():
    grid = SpectralGrid(10)
    config = SearchConfig(
        target_enstrophy=5.0,
        dt=1e-3,
        steps=3,
        skip_time=1e-3,
        initial_max_mode=2.0,
    )
    theta = jax.random.normal(jax.random.PRNGKey(3), (10, 10, 10, 3))
    state = constrained_state(theta, grid, config)
    _, history = trajectory_diagnostics(state, grid, config)
    value, gradient = jax.value_and_grad(
        lambda x: persistence_objective(x, grid, config)
    )(theta)

    assert history.shape == (config.steps + 1, 15)
    assert np.isfinite(float(value))
    assert np.isfinite(np.asarray(gradient)).all()


def test_amplification_shortfall_is_penalized():
    grid = SpectralGrid(10)
    theta = jax.random.normal(jax.random.PRNGKey(5), (10, 10, 10, 3))
    loose = SearchConfig(
        target_enstrophy=5.0,
        dt=1e-3,
        steps=2,
        initial_max_mode=2.0,
        target_amplification=1.0,
        amplification_weight=0.0,
        tail_weight=0.0,
    )
    demanding = SearchConfig(
        target_enstrophy=5.0,
        dt=1e-3,
        steps=2,
        initial_max_mode=2.0,
        target_amplification=3.0,
        amplification_weight=0.0,
        tail_weight=0.0,
    )

    assert float(persistence_objective(theta, grid, demanding)) < float(
        persistence_objective(theta, grid, loose)
    )


def test_depletion_objective_has_finite_gradient():
    grid = SpectralGrid(10)
    config = SearchConfig(
        target_enstrophy=5.0,
        dt=1e-3,
        steps=2,
        initial_max_mode=2.0,
    )
    theta = jax.random.normal(jax.random.PRNGKey(13), (10, 10, 10, 3))
    value, gradient = jax.value_and_grad(
        lambda x: depletion_objective(x, grid, config)
    )(theta)
    assert np.isfinite(float(value))
    assert np.isfinite(np.asarray(gradient)).all()


def test_soft_extrema_are_conservative_bounds():
    values = jax.numpy.asarray([1.0, 2.0, 3.0])
    assert float(soft_min(values, 0.1)) <= 1.0
    assert float(soft_max(values, 0.1)) >= 3.0
