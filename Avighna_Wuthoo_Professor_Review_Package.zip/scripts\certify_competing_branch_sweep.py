"""Interval-certify selected points on the exact competing KKT branch.

This is evidence across scale, not a parameter-uniform stability theorem.  The
closed-form branch itself is exact for every positive parameter; each entry in
this sweep separately proves strict local maximality at one rational-viscosity
point of that branch.
"""

from __future__ import annotations

import json
import importlib.metadata
from fractions import Fraction
from hashlib import sha256
from pathlib import Path
import platform
import sys

import numpy as np

from extreme_flows.certify import (
    StaticLowModePolynomial,
    _certify_symmetric_inertia_arb,
    _krawczyk_static_box,
    _refine_static_root_arb,
)
from extreme_flows.reduced_competing import embed_competing, optimizer_formula


TARGET = 100.0
# eta=E/nu². All choices use an exact rational viscosity and span 2.6 decades.
VISCOSITIES = (Fraction(1), Fraction(1, 2), Fraction(1, 5), Fraction(1, 10), Fraction(1, 20))


def _record(relative_path: str) -> dict[str, object]:
    root = Path(__file__).resolve().parents[1]
    path = root / relative_path
    data = path.read_bytes()
    return {
        "path": relative_path.replace("\\", "/"),
        "size_bytes": len(data),
        "sha256": sha256(data).hexdigest(),
    }


def run_point(viscosity: Fraction, precision: int) -> dict[str, object]:
    from flint import ctx

    model = StaticLowModePolynomial(
        viscosity=viscosity,
        phase_waves=((1, 0, 0), (0, 1, 0), (0, 0, 1)),
        phase_polarizations=(0, 1, 0),
    )
    formula = optimizer_formula(TARGET, float(viscosity))
    exact_a = embed_competing(Fraction(1), Fraction(0))
    exact_b = embed_competing(Fraction(0), Fraction(1))
    controls = np.asarray(
        [float(x) * formula["a"] + float(y) * formula["b"] for x, y in zip(exact_a, exact_b, strict=True)]
    )
    multipliers = np.array([8 * formula["b"] - 2 * float(viscosity), 0.0, 0.0, 0.0])
    old_precision = ctx.prec
    try:
        ctx.prec = precision
        center, residual, correction = _refine_static_root_arb(
            model, np.concatenate((controls, multipliers))
        )
        krawczyk = _krawczyk_static_box(model, center)
        if not krawczyk["verified"]:
            return {"precision_bits": precision, "verified": False, "attempts": krawczyk["attempts"]}
        inertia = _certify_symmetric_inertia_arb(krawczyk["bordered_hessian"])
        selected = [index - 2 for index in model.phase_indices]
        regular = all(not krawczyk["box"][index].contains(0) for index in selected)
        verified = bool(
            regular
            and inertia["verified"]
            and inertia["positive"] == 4
            and inertia["negative"] == 64
            and inertia["zero_or_unresolved"] == 0
        )
        return {
            "precision_bits": precision,
            "verified": verified,
            "krawczyk_contraction_upper": str(krawczyk["weighted_infinity_contraction_upper"]),
            "last_newton_correction": str(correction),
            "phase_chart_regular": regular,
            "inertia": {
                "verified": bool(inertia["verified"]),
                "positive": int(inertia["positive"]),
                "negative": int(inertia["negative"]),
                "zero_or_unresolved": int(inertia["zero_or_unresolved"]),
                "minimum_margin": str(inertia["minimum_signed_gershgorin_margin"]),
            },
        }
    finally:
        ctx.prec = old_precision


def main() -> None:
    if importlib.metadata.version("python-flint") != "0.9.0":
        raise RuntimeError("proof evaluation requires python-flint==0.9.0")
    entries = []
    for viscosity in VISCOSITIES:
        runs = [run_point(viscosity, precision) for precision in (256, 512)]
        entries.append(
            {
                "viscosity": f"{viscosity.numerator}/{viscosity.denominator}",
                "enstrophy": "100",
                "eta": str(Fraction(100, 1) / (viscosity * viscosity)),
                "runs": runs,
                "strict_local_maximum_certified_at_both_precisions": all(run["verified"] for run in runs),
            }
        )
        print(f"nu={viscosity}: {entries[-1]['strict_local_maximum_certified_at_both_precisions']}")
    payload = {
        "schema_version": 1,
        "truth_label": "finite_parameter_sweep_of_certified_competing_branch_local_maxima",
        "dependency": {
            "python_flint": importlib.metadata.version("python-flint"),
            "python": sys.version,
            "platform": platform.platform(),
        },
        "checker_source": {
            "stability_sweep": _record("scripts/certify_competing_branch_sweep.py"),
            "exact_polynomial": _record("src/extreme_flows/certify.py"),
            "competing_formula": _record("src/extreme_flows/reduced_competing.py"),
        },
        "statement": "Each listed parameter point separately has a 256/512-bit local-maximum certificate; no interpolation or all-parameter stability claim is made.",
        "entries": entries,
        "claims": {
            "all_listed_points_certified": all(entry["strict_local_maximum_certified_at_both_precisions"] for entry in entries),
            "parameter_uniform_full_space_local_maximum": False,
            "full_space_global_maximum": False,
        },
    }
    output = Path("artifacts/proofs/competing_branch_stability_sweep.json")
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    if not payload["claims"]["all_listed_points_certified"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
