from fractions import Fraction
import json

import numpy as np

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.static_symmetry import (
    COMPETING_ANSATZ_GENERATORS,
    STATIC_ANSATZ_GENERATORS,
    competing_ansatz_fixed_space_dimension,
    reduced_ansatz_is_exact_fixed_space,
    reduced_competing_ansatz_is_exact_fixed_space,
    signed_coordinate_matrices,
    static_ansatz_fixed_space_dimension,
    transform_static_controls,
    competing_symmetry_group_structure,
    competing_representation_sector_dimensions,
    compose_lattice_symmetries,
    static_symmetry_matrix,
)


def test_generators_preserve_exact_static_fourier_invariants():
    controls = tuple(Fraction((7 * index) % 13 - 6, 11) for index in range(64))
    model = StaticLowModePolynomial()
    original = model.exact_invariants(controls)

    for generator in STATIC_ANSATZ_GENERATORS:
        transformed = transform_static_controls(controls, generator)
        assert model.exact_invariants(transformed) == original


def test_all_cubic_signed_coordinate_isometries_preserve_static_invariants():
    controls = tuple(Fraction((11 * index) % 17 - 8, 13) for index in range(64))
    model = StaticLowModePolynomial()
    original = model.exact_invariants(controls)

    matrices = signed_coordinate_matrices()
    assert len(matrices) == 48
    assert len(set(matrices)) == 48
    for matrix in matrices:
        transformed = transform_static_controls(controls, (matrix, (0, 0, 0)))
        assert model.exact_invariants(transformed) == original


def test_six_amplitude_ansatz_is_exact_common_fixed_space():
    assert static_ansatz_fixed_space_dimension() == 6
    assert reduced_ansatz_is_exact_fixed_space()


def test_competing_two_amplitude_ansatz_is_exact_common_fixed_space():
    assert len(COMPETING_ANSATZ_GENERATORS) == 2
    assert competing_ansatz_fixed_space_dimension() == 2
    assert reduced_competing_ansatz_is_exact_fixed_space()


def test_competing_generators_close_to_the_exact_a4_times_c2_symmetry_group():
    structure = competing_symmetry_group_structure()
    assert structure["direct_product_verified"]
    assert structure["abstract_group"] == "A4 x C2"
    assert structure["group_order"] == 24
    assert structure["order_profile"] == {1: 1, 2: 7, 3: 8, 6: 8}
    assert structure["a4_complement_order_profile"] == {1: 1, 2: 3, 3: 8}


def test_competing_control_action_obeys_group_composition_and_exact_sector_split():
    left, right = COMPETING_ANSATZ_GENERATORS
    product = compose_lattice_symmetries(left, right)
    left_matrix = static_symmetry_matrix(left)
    right_matrix = static_symmetry_matrix(right)
    expected = static_symmetry_matrix(product)
    composed = tuple(
        tuple(sum(left_matrix[row][index] * right_matrix[index][column] for index in range(64))
              for column in range(64))
        for row in range(64)
    )
    assert composed == expected
    sectors = competing_representation_sector_dimensions()
    assert sectors["exact_isotypic_decomposition_verified"]
    assert sectors["sector_dimensions"] == {
        "trivial_even": 2,
        "two_dimensional_even": 6,
        "three_dimensional_even": 24,
        "trivial_odd": 2,
        "two_dimensional_odd": 6,
        "three_dimensional_odd": 24,
    }


def test_competing_generators_preserve_exact_static_fourier_invariants():
    controls = tuple(Fraction((5 * index) % 19 - 9, 17) for index in range(64))
    model = StaticLowModePolynomial()
    original = model.exact_invariants(controls)
    for generator in COMPETING_ANSATZ_GENERATORS:
        assert model.exact_invariants(transform_static_controls(controls, generator)) == original


def test_numerical_static_representative_obeys_the_generators():
    with open(
        "artifacts/proofs/static_adaptive_kkt_candidate.json", encoding="utf-8"
    ) as handle:
        controls = json.load(handle)["candidate"]["controls"]
    rational_controls = tuple(Fraction(str(value)) for value in controls)

    for generator in STATIC_ANSATZ_GENERATORS:
        image = np.asarray(transform_static_controls(rational_controls, generator), dtype=float)
        assert np.max(np.abs(image - controls)) < 1.0e-12
