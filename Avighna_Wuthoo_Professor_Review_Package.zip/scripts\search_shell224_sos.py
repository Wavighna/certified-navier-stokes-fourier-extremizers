"""Numerically search a symmetry-adapted Gram matrix for the ``(2,2,4)`` bound.

This is a discovery tool only.  It does not create a proof artifact.  Any
output must be rationalized and checked by an exact coefficient expansion and
exact PSD test before it can support a theorem.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
from itertools import combinations_with_replacement
import json
from pathlib import Path

import cvxpy as cp
import numpy as np

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.inviscid_sos_target import exact_stretching_cubic_terms
from extreme_flows.shellwise_bounds import _add, _shell_indices, _signed_orbits, shell_of_coordinate


def target_224() -> dict[tuple[int, ...], Fraction]:
    """Return ``E2^2 - 2 sum M_j^2/d_j`` for the candidate unit-constant bound."""

    model = StaticLowModePolynomial()
    shell_two = _shell_indices(model, 2)
    shell_four = _shell_indices(model, 4)
    two_position = {index: position for position, index in enumerate(shell_two)}
    four_position = {index: position for position, index in enumerate(shell_four)}
    components: list[dict[tuple[int, int], Fraction]] = [defaultdict(Fraction) for _ in shell_four]
    for monomial, coefficient in exact_stretching_cubic_terms(model).items():
        if tuple(sorted(shell_of_coordinate(model, index) for index in monomial)) != (2, 2, 4):
            continue
        pair = tuple(sorted(two_position[index] for index in monomial if index in two_position))
        linear = next(index for index in monomial if index in four_position)
        components[four_position[linear]][pair] += coefficient
    target: dict[tuple[int, ...], Fraction] = {}
    for first, global_first in enumerate(shell_two):
        for second, global_second in enumerate(shell_two):
            _add(
                target,
                (first, first, second, second),
                Fraction(1, 4)
                * model.enstrophy_diagonal_exact[global_first]
                * model.enstrophy_diagonal_exact[global_second],
            )
    for position, component in enumerate(components):
        divisor = model.enstrophy_diagonal_exact[shell_four[position]]
        for left, left_coefficient in component.items():
            for right, right_coefficient in component.items():
                _add(target, left + right, -2 * left_coefficient * right_coefficient / divisor)
    return target


def gram_linear_system():
    """Return the exact coefficient system and symmetry Gram basis for 224."""

    monomials = tuple(combinations_with_replacement(range(24), 2))
    entries, roots, forced_zero, signs, all_roots = _signed_orbits(2)
    free_roots = tuple(root for root in all_roots if not forced_zero[root])
    root_position = {root: position for position, root in enumerate(free_roots)}
    row_coefficients: dict[tuple[int, ...], dict[int, int]] = defaultdict(lambda: defaultdict(int))
    basis = np.zeros((len(free_roots), 300, 300), dtype=float)
    for item, (first, second) in enumerate(entries):
        root = roots[item]
        if forced_zero[root]:
            continue
        parameter = root_position[root]
        sign = signs[item]
        factor = 1 if first == second else 2
        row_coefficients[tuple(sorted(monomials[first] + monomials[second]))][parameter] += factor * sign
        basis[parameter, first, second] = sign
        basis[parameter, second, first] = sign
    target = target_224()
    support = sorted(set(row_coefficients) | set(target))
    matrix = np.zeros((len(support), len(free_roots)), dtype=float)
    rhs = np.zeros(len(support), dtype=float)
    for row, monomial in enumerate(support):
        for column, value in row_coefficients[monomial].items():
            matrix[row, column] = value
        rhs[row] = float(target.get(monomial, 0))
    return matrix, rhs, basis, target, support


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="tmp/shell224_sdp.json")
    parser.add_argument("--solver", default="CLARABEL", choices=("CLARABEL", "SCS"))
    args = parser.parse_args()
    matrix, rhs, basis, target, support = gram_linear_system()
    print("linear system", matrix.shape, "rank", np.linalg.matrix_rank(matrix), "target terms", len(target))
    variable = cp.Variable(basis.shape[0])
    gram = sum(variable[index] * basis[index] for index in range(basis.shape[0]))
    constraints = [matrix @ variable == rhs, gram >> 0]
    problem = cp.Problem(cp.Minimize(cp.trace(gram)), constraints)
    options = {"max_iter": 50_000} if args.solver == "CLARABEL" else {"max_iters": 100_000, "eps": 1e-8}
    problem.solve(solver=args.solver, **options)
    eig = np.linalg.eigvalsh(np.asarray(gram.value, dtype=float)) if gram.value is not None else np.array([])
    payload = {
        "truth_label": "numerical_sos_search_not_a_certificate",
        "solver": args.solver,
        "status": problem.status,
        "objective": None if problem.value is None else float(problem.value),
        "free_signed_gram_orbits": int(basis.shape[0]),
        "coefficient_equation_count": int(matrix.shape[0]),
        "coefficient_system_rank": int(np.linalg.matrix_rank(matrix)),
        "target_quartic_monomial_count": len(target),
        "max_coefficient_residual": None if variable.value is None else float(np.max(np.abs(matrix @ variable.value - rhs))),
        "minimum_gram_eigenvalue": None if not eig.size else float(eig[0]),
        "orbit_values": None if variable.value is None else [float(value) for value in variable.value],
        "next_step": "Rationalize a feasible point and prove exact expansion plus exact PSD, or reject this constant.",
    }
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
