# Supplementary-materials index for SIADS — draft

## Manuscript

- paper/main.tex and paper/references.bib: manuscript source and bibliography.
- paper/REVIEWER_GUIDE.md: claim-to-evidence map and independent-audit guide.

## One-command verification

- scripts/verify_paper_a.py: recomputes the finite-dimensional Paper A
  theorem claims at 256 and 512 bit precision.
- scripts/build_paper_a_manifest.py: produces a SHA-256 content manifest for
  the declared reproducibility release.
- pyproject.toml: Python dependency declaration; the proof extra pins
  python-flint to version 0.9.0.

## Exact construction and certificates

- src/extreme_flows/certify.py: exact rational Fourier arithmetic, Krawczyk
  machinery, and bordered-inertia checks.
- src/extreme_flows/reduced_static*.py and static_symmetry*.py: six-amplitude
  branch and symmetry connection.
- src/extreme_flows/reduced_competing.py and
  scripts/certify_reduced_competing.py: explicit competing branch, complete
  coefficient recovery, symbolic KKT reduction, and optimized-rate formula.
- src/extreme_flows/reduced_static_parameterized_global.py: exact
  high-parameter branch efficiencies and the two-term asymptotic crossover
  predictor; the predictor is explicitly not used in place of the interval
  crossing certificate.
- scripts/derive_competing_hessian_blocks.py and
  artifacts/proofs/competing_hessian_spectral_blocks.json: exact symbolic
  $A_4\times C_2$ generalized-Hessian sector factorization.
- scripts/certify_competing_all_eta_symbolic.py and
  artifacts/proofs/competing_all_eta_symbolic_continuation.json: exact
  Sturm/no-crossing continuation proof of the all-parameter constrained
  inertia; the separate Arb cover is a second proof route, not an independent
  software audit.
- artifacts/proofs/*.json: machine-readable candidates, interval records,
  crossover certificate, top-level verifier record, and release manifest.

## Verification procedure

From the repository root, use Python 3.12 and python-flint 0.9.0:

    .venv\Scripts\python.exe scripts\verify_paper_a.py
    .venv\Scripts\python.exe scripts\build_paper_a_manifest.py

The verifier must report all positive finite-dimensional claims as true and
must retain both negative flags:

    full_64d_global_maximum=False
    navier_stokes_regularity_or_blowup_statement=False

## Scope of the supplement

The material supports only the finite 16-pair Fourier claims in the paper.
It does not certify an unrestricted Navier--Stokes result, a PDE trajectory,
or any singularity or regularity statement.
