"""Numerically map competing static branches across the dimensionless scale.

This is an exploratory companion to the interval-certified branch results.  It
uses deterministic random restarts in the *full* 64-real-control sphere and
compares the best observed rate with the two rigorous symmetry-branch
formulas.  It deliberately does not infer full-space globality from any
finite restart count.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from extreme_flows.reduced_competing import optimized_rate_formula

# Support both ``python scripts/...py`` and package-style test imports.
try:  # pragma: no cover - selected by invocation style.
    from scripts.explore_full_static_landscape import (
        _parameterized_ansatz_rate,
        explore,
    )
except ModuleNotFoundError:  # pragma: no cover
    from explore_full_static_landscape import _parameterized_ansatz_rate, explore


DEFAULT_ETA_VALUES = (5_000.0, 10_000.0, 20_000.0, 28_000.0, 30_000.0, 50_000.0, 100_000.0, 1_000_000.0)


def explore_phase_diagram(
    *,
    eta_values: tuple[float, ...] = DEFAULT_ETA_VALUES,
    starts: int = 64,
    seed: int = 2026081203,
    max_iterations: int = 750,
    viscosity: float = 0.01,
) -> dict[str, object]:
    """Run deterministic full-space restart probes at the supplied ``eta``.

    The normalization keeps ``nu`` fixed and assigns ``E=eta*nu**2``.  Rates
    are therefore compared only after division by ``nu**3``; this has no
    bearing on the exact branch theorems, which use their own certificates.
    """

    if viscosity <= 0.0:
        raise ValueError("viscosity must be positive")
    if starts <= 0 or max_iterations <= 0:
        raise ValueError("starts and max_iterations must be positive")
    if any(eta <= 1867.0 / 4.0 for eta in eta_values):
        raise ValueError("eta values must lie in the certified high-six-branch regime")

    rows: list[dict[str, object]] = []
    for index, eta in enumerate(eta_values):
        enstrophy = float(eta) * viscosity * viscosity
        payload = explore(
            starts=starts,
            seed=seed + index,
            max_iterations=max_iterations,
            classify_symmetry_orbits=True,
            viscosity=viscosity,
            target_enstrophy=enstrophy,
        )
        six_rate = _parameterized_ansatz_rate(viscosity, enstrophy)
        two_rate = optimized_rate_formula(enstrophy, viscosity)
        best_rate = float(payload["summary"]["best_rate"])
        scale = max(abs(six_rate), abs(two_rate), 1.0e-30)
        rows.append(
            {
                "eta": float(eta),
                "enstrophy": enstrophy,
                "six_amplitude_branch_rate": six_rate,
                "two_amplitude_branch_rate": two_rate,
                "two_minus_six": two_rate - six_rate,
                "numerical_full_space_best_rate": best_rate,
                "best_minus_six": best_rate - six_rate,
                "best_minus_two": best_rate - two_rate,
                "relative_best_gap_from_larger_displayed_branch": (
                    best_rate - max(six_rate, two_rate)
                )
                / scale,
                "restart_summary": payload["summary"],
                "runs": payload["runs"],
            }
        )
    return {
        "truth_label": "numerical_static_branch_phase_diagram_exploration_only",
        "statement": (
            "Full-64-dimensional random-restart evidence only.  A sampled best "
            "rate, and agreement with either displayed branch, do not prove "
            "that branch is globally optimal in the 64-coordinate class."
        ),
        "model": {
            "dimension": 64,
            "independent_mode_pairs": 16,
            "mode_cutoff_squared": 4,
            "viscosity": viscosity,
        },
        "optimizer": {
            "starts_per_eta": starts,
            "max_iterations": max_iterations,
            "seed": seed,
            "method": "full-sphere L-BFGS-B random restarts",
        },
        "rows": rows,
        "claims": {
            "full_64d_global_phase_diagram_proved": False,
            "branch_crossover_proved_by_this_exploration": False,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--eta", type=float, nargs="+", default=list(DEFAULT_ETA_VALUES))
    parser.add_argument("--starts", type=int, default=64)
    parser.add_argument("--seed", type=int, default=2026081203)
    parser.add_argument("--max-iterations", type=int, default=750)
    parser.add_argument("--viscosity", type=float, default=0.01)
    parser.add_argument(
        "--output", default="artifacts/raw/static_branch_phase_diagram_exploration.json"
    )
    args = parser.parse_args()
    payload = explore_phase_diagram(
        eta_values=tuple(float(value) for value in args.eta),
        starts=args.starts,
        seed=args.seed,
        max_iterations=args.max_iterations,
        viscosity=args.viscosity,
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output}")
    for row in payload["rows"]:
        print(
            f"eta={row['eta']:.0f} best={row['numerical_full_space_best_rate']:.12g} "
            f"two-six={row['two_minus_six']:.3e}"
        )


if __name__ == "__main__":
    main()
