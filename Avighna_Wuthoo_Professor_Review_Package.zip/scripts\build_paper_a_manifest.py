"""Build a deterministic content manifest for a Paper A reproducibility release.

The manifest is deliberately a list of bytes and truth labels, not a claim
that the results have received independent review. It lets an external reader
check that the manuscript, checker, and archived proof objects belong to one
identified working tree.
"""

from __future__ import annotations

import argparse
from hashlib import sha256
import importlib.metadata
import json
from pathlib import Path
import platform
import subprocess
import sys


ROOT = Path(__file__).resolve().parents[1]
FILES = (
    "pyproject.toml",
    "RELEASE_MATERIALS.md",
    "paper/main.tex",
    "paper/references.bib",
    "paper/README.md",
    "paper/PRE_SUBMISSION_AUDIT.md",
    "paper/PRIORITY_SEARCH_LOG.md",
    "paper/PRIORITY_COMPARISON.md",
    "paper/REVIEWER_GUIDE.md",
    "paper/SUBMISSION_STRATEGY.md",
    "paper/COVER_LETTER_SIADS_DRAFT.md",
    "paper/SUPPLEMENT_INDEX_SIADS_DRAFT.md",
    "paper/figures/symmetry_branch_rates.png",
    "paper/figures/symmetry_branch_rates.pdf",
    "output/pdf/paper_a_static_extremizers.pdf",
    "scripts/verify_paper_a.py",
    "scripts/audit_competing_standalone.py",
    "scripts/audit_reduced_static_standalone.py",
    "scripts/audit_paper_a_clean_tree.py",
    "scripts/build_paper_a_manifest.py",
    "scripts/certify_reduced_competing.py",
    "scripts/certify_competing_symmetry_group.py",
    "scripts/certify_competing_representation.py",
    "scripts/certify_competing_high_eta_uniform.py",
    "scripts/certify_competing_all_eta_uniform.py",
    "scripts/certify_high_static_branch.py",
    "scripts/certify_inviscid_six_local.py",
    "scripts/certify_inviscid_competing_local.py",
    "scripts/certify_six_high_eta_uniform.py",
    "scripts/certify_shell112_sos.py",
    "scripts/certify_shell123_sos.py",
    "scripts/certify_shell224_sos.py",
    "scripts/certify_shell334_sos.py",
    "scripts/certify_competing_branch_sweep.py",
    "scripts/certify_branch_crossover.py",
    "scripts/derive_competing_hessian_blocks.py",
    "scripts/certify_competing_all_eta_symbolic.py",
    "scripts/plot_static_branches.py",
    "src/extreme_flows/certify.py",
    "src/extreme_flows/reduced_static.py",
    "src/extreme_flows/reduced_static_global.py",
    "src/extreme_flows/reduced_static_parameterized.py",
    "src/extreme_flows/reduced_static_parameterized_global.py",
    "src/extreme_flows/reduced_competing.py",
    "src/extreme_flows/static_symmetry.py",
    "src/extreme_flows/static_symmetry_connection.py",
    "artifacts/proofs/reduced_static_global_arb_certificate.json",
    "artifacts/proofs/reduced_static_standalone_algebra_audit.json",
    "artifacts/proofs/static_adaptive_kkt_candidate.json",
    "artifacts/proofs/static_adaptive_arb_certificate.json",
    "artifacts/proofs/static_symmetry_connection_certificate.json",
    "artifacts/proofs/high_branch_eta10000_candidate.json",
    "artifacts/proofs/high_branch_eta10000_arb_certificate.json",
    "artifacts/proofs/inviscid_six_full64_local_certificate.json",
    "artifacts/proofs/inviscid_competing_full64_local_certificate.json",
    "artifacts/proofs/six_branch_high_eta_uniform.json",
    "artifacts/proofs/shell112_sos_certificate.json",
    "artifacts/proofs/shell123_sos_certificate.json",
    "artifacts/proofs/shell224_sos_certificate.json",
    "artifacts/proofs/shell334_sos_certificate.json",
    "artifacts/proofs/shell334_rational_gram_candidate.json",
    "artifacts/proofs/reduced_competing_formula.json",
    "artifacts/proofs/competing_symmetry_group.json",
    "artifacts/proofs/competing_representation_sectors.json",
    "artifacts/proofs/competing_high_eta_uniform.json",
    "artifacts/proofs/competing_all_eta_uniform.json",
    "artifacts/proofs/competing_standalone_algebra_audit.json",
    "artifacts/proofs/competing_branch_stability_sweep.json",
    "artifacts/proofs/symmetry_branch_crossover.json",
    "artifacts/proofs/competing_hessian_spectral_blocks.json",
    "artifacts/proofs/competing_all_eta_symbolic_continuation.json",
    "artifacts/proofs/paper_a_verification.json",
)


def _record(relative: str) -> dict[str, object]:
    path = ROOT / relative
    data = path.read_bytes()
    return {
        "path": relative.replace("\\", "/"),
        "size_bytes": len(data),
        "sha256": sha256(data).hexdigest(),
    }


def _git_revision() -> dict[str, object]:
    try:
        revision = subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
        ).strip()
        dirty = bool(
            subprocess.check_output(
                ["git", "status", "--porcelain"], cwd=ROOT, text=True
            ).strip()
        )
        return {"revision": revision, "worktree_dirty": dirty}
    except (OSError, subprocess.CalledProcessError):
        return {"revision": None, "worktree_dirty": None}


def build_manifest() -> dict[str, object]:
    """Return a byte-level release manifest for all declared Paper A inputs."""

    missing = [relative for relative in FILES if not (ROOT / relative).is_file()]
    if missing:
        raise FileNotFoundError(f"missing Paper A release input(s): {missing}")
    verification = json.loads(
        (ROOT / "artifacts/proofs/paper_a_verification.json").read_text(encoding="utf-8")
    )
    claims = verification["claims"]
    if claims["full_64d_global_maximum"] or claims[
        "navier_stokes_regularity_or_blowup_statement"
    ]:
        raise AssertionError("release manifest refuses prohibited PDE-level claims")
    return {
        "schema_version": 1,
        "truth_label": "paper_a_release_content_manifest",
        "scope": "content addressing and finite-dimensional theorem claims only",
        "git": _git_revision(),
        "runtime": {
            "python": sys.version,
            "platform": platform.platform(),
            "python_flint": importlib.metadata.version("python-flint"),
        },
        "verification_claims": claims,
        "prohibited_claims": {
            "full_64d_global_maximum": False,
            "navier_stokes_regularity_or_blowup_statement": False,
            "independent_software_audit_completed": False,
        },
        "files": [_record(relative) for relative in FILES],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output", default="artifacts/proofs/paper_a_release_manifest.json"
    )
    args = parser.parse_args()
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(build_manifest(), indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
