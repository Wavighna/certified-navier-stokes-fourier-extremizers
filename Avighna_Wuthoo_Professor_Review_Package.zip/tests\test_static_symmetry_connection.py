from hashlib import sha256
import json
from pathlib import Path

import pytest

from extreme_flows.static_symmetry_connection import (
    build_static_symmetry_connection_certificate,
    evaluate_static_symmetry_connection,
)


def test_connection_certificate_requires_two_declared_precisions():
    with pytest.raises(ValueError, match="256-bit and 512-bit"):
        build_static_symmetry_connection_certificate("unused.json", precisions=(256,))


def test_reduced_root_is_inside_the_unique_full_krawczyk_box():
    pytest.importorskip("flint")
    run = evaluate_static_symmetry_connection(
        "artifacts/proofs/static_adaptive_kkt_candidate.json", precision=128, bits=60
    )

    assert run["full_krawczyk_verified"]
    assert run["exact_fixed_space_dimension_is_six"]
    assert run["reduced_root_inside_full_krawczyk_box"]
    assert run["failed_component_count"] == 0
    # This smoke run deliberately uses only 128-bit arithmetic and a coarse
    # multiplier interval.  Containment in the contraction box is the theorem;
    # the much tighter 256/512-bit archive separately records a <1e-20 ratio.
    assert run["maximum_center_distance_over_full_box_radius"] < 1.0e-6


def test_archived_connection_certificate_has_current_checker_hashes():
    payload = json.loads(
        Path("artifacts/proofs/static_symmetry_connection_certificate.json").read_text(
            encoding="utf-8"
        )
    )
    assert payload["claims"]["reduced_global_ansatz_root_is_the_full_certified_kkt_root"]
    for record in payload["checker_source"].values():
        data = Path(record["path"]).read_bytes()
        assert record["size_bytes"] == len(data)
        assert record["sha256"] == sha256(data).hexdigest()
