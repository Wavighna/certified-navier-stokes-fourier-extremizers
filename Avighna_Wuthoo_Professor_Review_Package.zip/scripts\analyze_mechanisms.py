"""Analyze exact Betchov--Miller mechanism ledgers in a saved trajectory."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import re
from typing import Any

import jax.numpy as jnp
import numpy as np

from extreme_flows.mechanisms import (
    IDENTITY_RESIDUAL_NAMES,
    endpoint_mechanism_ledger,
    mechanism_diagnostics,
    scalarize_mechanisms,
)
from extreme_flows.low_modes import load_low_mode_candidate
from extreme_flows.spectral import SpectralGrid


_MULTIRES_FINAL_STATE = re.compile(
    r"^(?P<validation>validation_)?final_state_n(?P<n>[0-9]+)$"
)


def _metadata(archive: np.lib.npyio.NpzFile) -> dict[str, Any]:
    if "metadata" not in archive.files:
        return {}
    return json.loads(str(archive["metadata"].item()))


def _finite_json(value: Any) -> Any:
    """Replace non-finite floats recursively so JSON is standards compliant."""

    if isinstance(value, dict):
        return {key: _finite_json(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_finite_json(item) for item in value]
    if isinstance(value, (float, np.floating)) and not math.isfinite(float(value)):
        return None
    return value


def _archive_endpoint_beta(
    archive: np.lib.npyio.NpzFile, metadata: dict[str, Any]
) -> float | None:
    if "trajectory" not in archive.files:
        return None
    names = metadata.get("diagnostic_names", [])
    if "enstrophy" not in names or "stretching_efficiency" not in names:
        return None
    history = np.asarray(archive["trajectory"])
    enstrophy = history[:, names.index("enstrophy")]
    chi = history[:, names.index("stretching_efficiency")]
    if min(enstrophy[0], enstrophy[-1], chi[0], chi[-1]) <= 0.0:
        return None
    return float(
        -np.log(chi[-1] / chi[0])
        / np.log(enstrophy[-1] / enstrophy[0])
    )


def _spectral_state(value: Any, *, name: str) -> np.ndarray:
    """Validate and return one cubic three-component spectral state."""

    state = np.asarray(value)
    if (
        state.ndim != 4
        or state.shape[-1] != 3
        or len(set(state.shape[:3])) != 1
    ):
        raise ValueError(f"{name} must have shape (N,N,N,3)")
    return state


def _multires_final_state_keys(
    archive: np.lib.npyio.NpzFile,
) -> dict[int, tuple[str, ...]]:
    """Index resolution-tagged endpoint states in deterministic priority order."""

    by_grid: dict[int, list[str]] = {}
    for key in archive.files:
        match = _MULTIRES_FINAL_STATE.fullmatch(key)
        if match is not None:
            by_grid.setdefault(int(match.group("n")), []).append(key)
    return {
        n: tuple(
            sorted(
                keys,
                key=lambda key: (not key.startswith("validation_"), key),
            )
        )
        for n, keys in by_grid.items()
    }


def _select_endpoint_states(
    archive: np.lib.npyio.NpzFile,
    *,
    candidate: Path | None,
    requested_grid: int | None,
) -> tuple[np.ndarray, np.ndarray, dict[str, Any]]:
    """Select legacy endpoints or reconstruct a multires initial endpoint.

    Legacy ``state``/``final_state`` archives retain their historical behavior
    when no candidate is supplied.  A candidate is necessary for a multires
    archive because those archives intentionally store only the final spectral
    states plus grid-independent controls.  If both endpoint variants exist at
    a resolution, the smaller-step validation endpoint is preferred.
    """

    if requested_grid is not None and requested_grid <= 0:
        raise ValueError("--grid must be positive")

    if candidate is None and "state" in archive.files and "final_state" in archive.files:
        initial = _spectral_state(archive["state"], name="state")
        final = _spectral_state(archive["final_state"], name="final_state")
        if initial.shape != final.shape:
            raise ValueError("state and final_state must have matching shapes")
        n = int(initial.shape[0])
        if requested_grid is not None and requested_grid != n:
            raise ValueError(
                f"--grid {requested_grid} does not match legacy archive grid N={n}"
            )
        return initial, final, {
            "mode": "legacy_archive_pair",
            "initial_state_source": "archive",
            "initial_state_key": "state",
            "final_state_key": "final_state",
            "candidate": None,
            "requested_grid": requested_grid,
        }

    multires_keys = _multires_final_state_keys(archive)
    if requested_grid is not None:
        n = requested_grid
    elif len(multires_keys) == 1:
        n = next(iter(multires_keys))
    elif not multires_keys and "final_state" in archive.files:
        n = int(_spectral_state(archive["final_state"], name="final_state").shape[0])
    elif multires_keys:
        available = ", ".join(f"N={value}" for value in sorted(multires_keys))
        raise ValueError(
            "--grid is required because the archive contains endpoints at "
            f"multiple resolutions ({available})"
        )
    else:
        raise ValueError(
            "archive has no final_state or resolution-tagged final-state key"
        )

    if candidate is None:
        raise ValueError(
            "--candidate is required to reconstruct the initial low-mode state "
            "for a multires archive"
        )

    if n in multires_keys:
        final_key = multires_keys[n][0]
    elif "final_state" in archive.files:
        final_key = "final_state"
    else:
        available = ", ".join(f"N={value}" for value in sorted(multires_keys)) or "none"
        raise ValueError(
            f"archive has no final endpoint for N={n}; available grids: {available}"
        )

    final = _spectral_state(archive[final_key], name=final_key)
    if int(final.shape[0]) != n:
        raise ValueError(
            f"{final_key} has grid N={final.shape[0]}, not requested N={n}"
        )
    control = load_low_mode_candidate(candidate)
    initial = np.asarray(control.lift(SpectralGrid(n)))
    return initial, final, {
        "mode": "candidate_reconstructed_initial",
        "initial_state_source": "low_mode_candidate",
        "initial_state_key": None,
        "final_state_key": final_key,
        "candidate": str(candidate),
        "requested_grid": requested_grid,
    }


def _time_final(metadata: dict[str, Any], *, n: int, final_key: str) -> float | None:
    """Recover the relevant horizon from legacy or multires metadata."""

    if "dt" in metadata and "steps" in metadata:
        return float(metadata["dt"] * metadata["steps"])
    if final_key.startswith("validation_"):
        for validation in metadata.get("validation", []):
            grids = validation.get("grids", [])
            if grids and int(grids[0].get("n", -1)) == n:
                if "dt" in validation and "steps" in validation:
                    return float(validation["dt"] * validation["steps"])
    config = metadata.get("joint_config", {})
    if "dt" in config and "steps" in config:
        return float(config["dt"] * config["steps"])
    return None


def analyze_archive(
    input_path: Path,
    *,
    candidate: Path | None = None,
    grid_n: int | None = None,
    identity_tolerance: float = 1.0e-10,
    beta_tolerance: float = 1.0e-10,
    expected_beta: float | None = None,
) -> dict[str, Any]:
    """Analyze one legacy or multires endpoint archive."""

    with np.load(input_path) as archive:
        metadata = _metadata(archive)
        state, final_state, selection = _select_endpoint_states(
            archive,
            candidate=candidate,
            requested_grid=grid_n,
        )
        archive_beta = _archive_endpoint_beta(archive, metadata)

    if state.shape != final_state.shape:
        raise ValueError("initial and final states must have matching shapes")
    n = int(state.shape[0])
    grid = SpectralGrid(n)
    initial = scalarize_mechanisms(mechanism_diagnostics(jnp.asarray(state), grid))
    final = scalarize_mechanisms(
        mechanism_diagnostics(jnp.asarray(final_state), grid)
    )
    # No intermediate mechanism snapshots are supplied here.  The sign guard
    # therefore certifies the logarithmic budgets at the two endpoints only.
    ledger = endpoint_mechanism_ledger(initial, final)
    direct_beta = ledger["beta"]["direct"]

    checks = {
        "identities_within_tolerance": (
            ledger["maximum_identity_residual"] <= identity_tolerance
        ),
        "endpoint_logarithmic_budget_valid": ledger["valid"],
        # Retained for compatibility with existing report consumers.
        "ledger_valid": ledger["valid"],
        "archive_beta_agreement": (
            None
            if archive_beta is None or direct_beta is None
            else abs(archive_beta - direct_beta) <= beta_tolerance
        ),
        "expected_beta_agreement": (
            None
            if expected_beta is None or direct_beta is None
            else abs(expected_beta - direct_beta) <= beta_tolerance
        ),
    }
    return {
        "source": str(input_path),
        "selection": selection,
        "n": n,
        "time_final": _time_final(
            metadata,
            n=n,
            final_key=str(selection["final_state_key"]),
        ),
        "archive_endpoint_beta": archive_beta,
        "positivity_guard": {
            "scope": "endpoints only",
            "description": (
                "A, Theta, H, chi, and all logarithm arguments were checked "
                "only at the initial and final endpoints; no pathwise positivity "
                "claim is made."
            ),
            "passed": ledger["valid"],
            "invalid_reasons": ledger["invalid_reasons"],
        },
        "identity_residual_names": list(IDENTITY_RESIDUAL_NAMES),
        "initial": initial,
        "final": final,
        "ledger": ledger,
        "checks": checks,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Evaluate endpoint Betchov and Miller exponent ledgers."
    )
    parser.add_argument("input", type=Path)
    parser.add_argument(
        "--candidate",
        type=Path,
        help=(
            "grid-independent low-mode candidate used to reconstruct the initial "
            "state of a multires search archive"
        ),
    )
    parser.add_argument(
        "--grid",
        type=int,
        help=(
            "endpoint grid N; validation_final_state_nN is preferred over "
            "final_state_nN"
        ),
    )
    parser.add_argument("--output", type=Path)
    parser.add_argument("--identity-tol", type=float, default=1.0e-10)
    parser.add_argument("--beta-tol", type=float, default=1.0e-10)
    parser.add_argument("--expect-beta", type=float)
    args = parser.parse_args()
    payload = analyze_archive(
        args.input,
        candidate=args.candidate,
        grid_n=args.grid,
        identity_tolerance=args.identity_tol,
        beta_tolerance=args.beta_tol,
        expected_beta=args.expect_beta,
    )
    rendered = json.dumps(_finite_json(payload), indent=2, allow_nan=False)
    print(rendered)
    if args.output is not None:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
