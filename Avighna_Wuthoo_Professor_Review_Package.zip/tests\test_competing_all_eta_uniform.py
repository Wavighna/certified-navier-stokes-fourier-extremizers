"""Truth-label guards for the all-positive-eta interval certificate."""

from __future__ import annotations

import json
from fractions import Fraction
from hashlib import sha256
from pathlib import Path


def test_all_eta_certificate_has_two_complete_overlapping_covers() -> None:
    payload = json.loads(
        Path("artifacts/proofs/competing_all_eta_uniform.json").read_text(encoding="utf-8")
    )
    assert payload["truth_label"] == (
        "proved_uniform_competing_full_space_local_maximum_all_positive_eta"
    )
    assert payload["claims"][
        "strict_full_space_local_maximum_modulo_translations_for_all_positive_eta"
    ]
    assert not payload["claims"]["full_space_global_maximum"]
    assert not payload["claims"]["navier_stokes_regularity_or_blowup_statement"]
    assert payload["normalization"]["low_cover_upper_endpoint"] == "47/50"
    assert "47/50 > 9049/10000" in payload["normalization"]["overlap"]
    assert [run["precision_bits"] for run in payload["arb"]["runs"]] == [256, 512]
    for run in payload["arb"]["runs"]:
        assert run["all_intervals_certified"]
        assert run["rescaled_low_cover"]["interval_count"] == 188
        assert run["rescaled_low_cover"]["all_intervals_certified"]
        assert run["ordinary_high_cover"]["interval_count"] == 238
        assert run["ordinary_high_cover"]["all_intervals_certified"]
        assert not run["rescaled_low_cover"]["failures"]
        assert not run["ordinary_high_cover"]["failures"]
    for name in ("checker_source", "high_cover_source", "formula_source", "polynomial_source"):
        record = payload[name]
        assert record["sha256"] == sha256(Path(record["path"]).read_bytes()).hexdigest()


def test_low_s_rescaled_bordered_hessian_is_congruent_at_interior_points() -> None:
    """Check the cancellation formula against the ordinary Hessian entrywise.

    This does not replace the interval proof.  It guards the exact algebraic
    bridge used there: for interior ``s``, the low-s matrix must equal
    ``s D(s)^T B(s) D(s)``, where D is ``1/s`` on the |k|^2=1 controls and
    identity on all remaining control and multiplier/phase coordinates.
    """

    from flint import ctx

    from extreme_flows.certify import StaticLowModePolynomial, _arb_fraction
    from scripts.certify_competing_all_eta_uniform import (
        PHASE_POLARIZATIONS,
        PHASE_WAVES,
        _branch_tensors,
        _rescaled_low_bordered_hessian,
    )
    from scripts.certify_competing_high_eta_uniform import _branch_bordered_hessian

    previous_precision = ctx.prec
    try:
        ctx.prec = 256
        model = StaticLowModePolynomial(
            phase_waves=PHASE_WAVES, phase_polarizations=PHASE_POLARIZATIONS
        )
        branch_data = _branch_tensors(model)
        weak = branch_data[2]
        size = model.dimension + 4
        for s in (Fraction(1, 100), Fraction(1, 4), Fraction(9, 10)):
            rescaled = _rescaled_low_bordered_hessian(model, s, s, branch_data)
            ordinary = _branch_bordered_hessian(model, s, s)
            scales = [Fraction(1, s) if index in weak else Fraction(1) for index in range(size)]
            for row in range(size):
                for column in range(size):
                    factor = s * scales[row] * scales[column]
                    assert 0 in (rescaled[row, column] - _arb_fraction(factor) * ordinary[row, column])
    finally:
        ctx.prec = previous_precision
