import jax
import jax.numpy as jnp
import numpy as np

import extreme_flows.multires as multires_module
from extreme_flows.low_modes import load_low_mode_candidate, normalize_coordinates
from extreme_flows.multires import (
    CERTIFIED_P3_INITIAL_Q_FLOOR,
    PROTECTED_MARGIN_NAMES,
    MultiResolutionConfig,
    epigraph_constraint_values,
    gamma_at_amplifications,
    initial_q_margin,
    make_initial_q_margin_value_and_grad,
    make_joint_value_and_grad,
    make_optimizer_state_evaluator,
    multiresolution_raw_evaluation,
    multistage_riemannian_adam,
    summarize_multiresolution,
    tangent_gradient_check,
    trust_constr_epigraph_refine,
)


def small_config() -> MultiResolutionConfig:
    return MultiResolutionConfig(
        grid_sizes=(8,),
        steps=2,
        block_size=2,
        amplification_levels=(1.0001, 1.0002),
        velocity_tail_limits=(1.0,),
        enstrophy_tail_limits=(1.0,),
        palinstrophy_tail_limits=(1.0,),
    )


def test_log_interpolation_recovers_exact_power_law_gamma():
    enstrophy = jnp.asarray([100.0, 117.0, 153.0, 211.0])
    expected_gamma = -0.073
    zeta = 0.4 * (enstrophy / enstrophy[0]) ** expected_gamma
    levels = (1.1, 1.2, 1.5, 2.0)
    gammas, crossing_times, reached = gamma_at_amplifications(
        enstrophy, zeta, levels, dt=0.01
    )

    assert np.allclose(np.asarray(gammas), expected_gamma, atol=2e-13)
    assert np.all(np.asarray(reached))
    assert np.all(np.diff(np.asarray(crossing_times)) > 0.0)


def test_certified_baseline_floor_blocks_zero_zeta_log_ratio_exploit():
    enstrophy = jnp.asarray([100.0, 110.0, 200.0])
    zeta = jnp.asarray([0.0, 0.5, 0.6])
    zeta_floor = (
        CERTIFIED_P3_INITIAL_Q_FLOOR * 100.0**0.85 / 4.0**0.75
    )
    unfloored, _, _ = gamma_at_amplifications(
        enstrophy, zeta, (1.1, 2.0), dt=0.1
    )
    bounded, _, _ = gamma_at_amplifications(
        enstrophy,
        zeta,
        (1.1, 2.0),
        dt=0.1,
        baseline_zeta_floor=zeta_floor,
    )

    assert float(jnp.min(unfloored)) > 1.0e3
    assert float(jnp.max(bounded)) < 10.0
    assert np.isclose(
        float(bounded[0]),
        np.log(0.5 / zeta_floor) / np.log(1.1),
        rtol=1e-13,
    )


def test_joint_objective_gradient_and_constraint_interfaces_are_finite():
    control = load_low_mode_candidate(
        "artifacts/candidates/depletion_v3_low_modes.json"
    )
    config = small_config()
    raw = multiresolution_raw_evaluation(control.coordinates, config)
    value, gradient = make_joint_value_and_grad(config)(control.coordinates)
    equalities, inequalities = epigraph_constraint_values(
        control.coordinates, jnp.min(raw["gammas"]), config
    )

    assert raw["gammas"].shape == (1, 2)
    assert raw["unfloored_gammas"].shape == (1, 2)
    assert raw["trajectories"].shape == (1, 3, 10)
    assert raw["final_states"][0].shape == (8, 8, 8, 3)
    assert equalities.shape == (1,)
    assert inequalities.ndim == 1
    assert np.isclose(
        float(raw["inequality_constraints"][0]),
        float(raw["initial_q_margins"][0]),
    )
    assert np.isfinite(float(value))
    assert np.isfinite(np.asarray(gradient)).all()
    assert np.isfinite(np.asarray(equalities)).all()
    assert np.isfinite(np.asarray(inequalities)).all()


def test_riemannian_adam_retracts_and_ad_matches_tangent_difference():
    control = load_low_mode_candidate(
        "artifacts/candidates/persistent_v3_low_modes.json"
    )
    config = small_config()
    result = multistage_riemannian_adam(
        control.coordinates,
        config,
        stages=((1, 2.0e-3),),
        learning_rate=1.0e-3,
    )
    checks = tangent_gradient_check(
        control.coordinates,
        config,
        directions=1,
        epsilon=2.0e-6,
    )

    assert np.isclose(np.linalg.norm(np.asarray(result.coordinates)), 1.0, atol=1e-13)
    assert len(result.objective_history) == 1
    assert len(result.telemetry_history) == 1
    assert len(result.stage_terminations) == 1
    assert result.stage_terminations[0].reason == "completed_requested_iterations"
    assert result.telemetry_history[-1].accepted
    assert result.telemetry_history[-1].q_direction_adjusted
    assert not result.telemetry_history[-1].q_restoration
    assert result.telemetry_history[-1].q_projection_norm > 0.0
    assert result.telemetry_history[-1].q_directional_derivative_after > 0.0
    recomputed = summarize_multiresolution(result.coordinates, config)["objective"]
    assert np.isclose(result.objective_history[-1], recomputed, rtol=1e-12)
    assert result.telemetry_history[-1].minimum_initial_q_margin >= -1e-9
    assert checks[0]["relative_error"] < 1e-4


def test_adam_stage_stops_after_consecutive_rejected_line_searches(monkeypatch):
    """Plateau stopping records a bounded numerical exit, not fake progress."""

    control = load_low_mode_candidate(
        "artifacts/candidates/persistent_v3_low_modes.json"
    )
    point = normalize_coordinates(control.coordinates)

    def state(coordinates):
        displacement = jnp.vdot(coordinates - point, coordinates - point)
        return multires_module._OptimizerState(
            -displacement,
            jnp.asarray(0.0),
            jnp.ones((1,)),
            jnp.asarray(True),
            jnp.asarray(1.0),
        )

    def fake_value_and_grad(_config, _temperature):
        def evaluate(coordinates):
            current = state(coordinates)
            return (current.objective, current), jnp.ones_like(coordinates)

        return evaluate

    monkeypatch.setattr(
        multires_module, "make_optimizer_value_and_grad", fake_value_and_grad
    )
    monkeypatch.setattr(
        multires_module,
        "make_optimizer_state_evaluator",
        lambda _config, _temperature: state,
    )
    monkeypatch.setattr(
        multires_module,
        "make_initial_q_margin_value_and_grad",
        lambda _config: lambda coordinates: (
            jnp.asarray(1.0),
            jnp.zeros_like(coordinates),
        ),
    )

    result = multistage_riemannian_adam(
        point,
        small_config(),
        stages=((5, 2.0e-3),),
        learning_rate=0.1,
        max_backtracks=0,
        stage_rejection_patience=2,
    )

    assert len(result.objective_history) == 2
    assert not any(step.accepted for step in result.telemetry_history)
    assert result.stage_terminations[0]._asdict() == {
        "stage_index": 0,
        "temperature": 2.0e-3,
        "requested_iterations": 5,
        "executed_iterations": 2,
        "consecutive_rejections": 2,
        "reason": "rejection_patience_exhausted",
    }


def test_near_floor_infeasible_q_direction_is_restorative_and_accepted():
    control = load_low_mode_candidate(
        "artifacts/candidates/persistent_v3_low_modes.json"
    )
    config = small_config()
    point = normalize_coordinates(control.coordinates)
    _, q_gradient = make_initial_q_margin_value_and_grad(config)(point)
    q_gradient -= jnp.vdot(point, q_gradient) * point
    outward = -q_gradient / jnp.linalg.norm(q_gradient)
    near_floor = normalize_coordinates(point + 1.0e-3 * outward)
    before = float(initial_q_margin(near_floor, config))
    result = multistage_riemannian_adam(
        near_floor,
        config,
        stages=((1, 2.0e-3),),
        learning_rate=1.0e-3,
    )
    telemetry = result.telemetry_history[-1]

    assert -0.01 < before < 0.0
    assert telemetry.accepted
    assert telemetry.q_direction_adjusted
    assert telemetry.q_restoration
    assert telemetry.q_directional_derivative_after > 0.0
    assert telemetry.minimum_initial_q_margin > before


def test_optimizer_preserves_each_grid_family_margin_without_grid_reduction():
    control = load_low_mode_candidate(
        "artifacts/candidates/persistent_v3_low_modes.json"
    )
    config = MultiResolutionConfig(
        grid_sizes=(8, 10),
        steps=1,
        block_size=1,
        amplification_levels=(1.0001,),
        velocity_tail_limits=(1.0, 1.0),
        enstrophy_tail_limits=(1.0, 1.0),
        palinstrophy_tail_limits=(1.0, 1.0),
    )
    raw = multiresolution_raw_evaluation(control.coordinates, config)
    state = make_optimizer_state_evaluator(config, 2.0e-3)(control.coordinates)

    assert state.protected_margins.shape == (
        len(config.grid_sizes) * len(PROTECTED_MARGIN_NAMES),
    )
    assert np.allclose(
        np.asarray(state.protected_margins),
        np.asarray(raw["protected_group_margins"]).reshape(-1),
        rtol=1.0e-13,
        atol=1.0e-13,
    )


def test_p3_actual_n16_screen_step_enters_q_feasible_side():
    control = load_low_mode_candidate(
        "artifacts/candidates/persistent_v3_low_modes.json"
    )
    config = MultiResolutionConfig(
        grid_sizes=(16,),
        velocity_tail_limits=(0.01,),
        enstrophy_tail_limits=(0.05,),
        palinstrophy_tail_limits=(0.15,),
    )
    result = multistage_riemannian_adam(
        control.coordinates,
        config,
        stages=((1, 2.0e-3),),
        learning_rate=0.005,
        max_backtracks=12,
    )
    telemetry = result.telemetry_history[0]

    assert telemetry.accepted
    assert telemetry.q_direction_adjusted
    assert not telemetry.q_restoration
    assert telemetry.q_directional_derivative_after > 0.0
    assert telemetry.minimum_initial_q_margin >= -1.0e-9
    assert telemetry.backtracks <= 12


def test_initial_q_floor_is_hard_and_near_zero_zeta_cannot_win():
    p3 = load_low_mode_candidate(
        "artifacts/candidates/persistent_v3_low_modes.json"
    )
    config = small_config()
    feasible = multiresolution_raw_evaluation(p3.coordinates, config)
    infeasible = multiresolution_raw_evaluation(-p3.coordinates, config)
    infeasible_summary = summarize_multiresolution(-p3.coordinates, config)

    assert float(feasible["initial_q_values"][0]) >= (
        config.initial_q_floor - 1e-14
    )
    assert float(infeasible["initial_q_margins"][0]) < 0.0
    assert float(infeasible["initial_q_loss"]) > 0.0
    assert float(infeasible["objective"]) < 100.0
    assert infeasible_summary["minimum_exact_gamma"] is None
    assert not infeasible_summary["all_hard_feasible"]


def test_trust_constr_epigraph_refinement_is_callable_and_bounded():
    control = load_low_mode_candidate(
        "artifacts/candidates/depletion_v3_low_modes.json"
    )
    config = MultiResolutionConfig(
        grid_sizes=(8,),
        steps=1,
        block_size=1,
        amplification_levels=(1.1,),
        velocity_tail_limits=(1.0,),
        enstrophy_tail_limits=(1.0,),
        palinstrophy_tail_limits=(1.0,),
    )
    result = trust_constr_epigraph_refine(
        control.coordinates, config, max_iterations=1
    )

    assert result.iterations == 1
    assert np.isfinite(result.epigraph_gamma)
    assert np.isfinite(result.optimality)
    assert np.isfinite(result.constraint_violation)
    assert np.isfinite(result.solver_optimality)
    assert np.isfinite(result.solver_constraint_violation)
    assert result.normalization_displacement >= 0.0
    assert np.isclose(np.linalg.norm(result.coordinates), 1.0, atol=1e-13)
