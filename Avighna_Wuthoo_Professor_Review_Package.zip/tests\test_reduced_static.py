from fractions import Fraction
import json

import numpy as np

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.reduced_static import (
    embed_reduced_static,
    reduced_amplitudes_from_controls,
    reduced_static_invariants,
)


def test_reduced_static_formula_is_exact_fourier_algebra():
    amplitudes = tuple(Fraction(value) for value in (1, 2, 3, 5, 7, 11))
    model = StaticLowModePolynomial(
        phase_waves=((2, 0, 0), (0, 2, 0), (0, 0, 1))
    )

    expected = reduced_static_invariants(amplitudes)
    actual = model.exact_invariants(embed_reduced_static(amplitudes))

    assert actual == expected


def test_certified_static_root_is_in_reduced_ansatz_and_reproduces_rate():
    with open(
        "artifacts/proofs/static_adaptive_kkt_candidate.json", encoding="utf-8"
    ) as handle:
        payload = json.load(handle)
    controls = payload["candidate"]["controls"]

    amplitudes = reduced_amplitudes_from_controls(controls, tolerance=1.0e-10)
    invariants = reduced_static_invariants(amplitudes, viscosity=0.01)

    assert np.isclose(invariants["enstrophy"], 100.0, rtol=0.0, atol=1e-11)
    assert np.isclose(
        invariants["stretching"],
        payload["candidate"]["stretching"],
        rtol=0.0,
        atol=1e-11,
    )
    assert np.isclose(
        invariants["rate"], payload["candidate"]["rate"], rtol=0.0, atol=1e-11
    )


def test_reduced_rate_gradient_matches_the_full_fourier_polynomial():
    amplitudes = np.asarray((1.0, -2.0, 3.0, -5.0, 7.0, -11.0))
    controls = np.asarray(embed_reduced_static(amplitudes), dtype=float)
    model = StaticLowModePolynomial(
        phase_waves=((2, 0, 0), (0, 2, 0), (0, 0, 1))
    )
    full_gradient = np.asarray(model.evaluate(controls)["gradient_rate"])
    embedding = np.column_stack(
        [
            np.asarray(
                embed_reduced_static(
                    tuple(float(index == column) for index in range(6))
                ),
                dtype=float,
            )
            for column in range(6)
        ]
    )
    a, b, c, d, e, f = amplitudes
    reduced_gradient = np.asarray(
        (
            64 * c * d + 32 * e * f - 0.08 * a,
            -64 * d * f - 5.12 * b,
            64 * a * d - 5.76 * c,
            64 * a * c - 64 * b * f - 0.64 * d,
            32 * a * f - 5.76 * e,
            32 * a * e - 64 * b * d - 0.32 * f,
        )
    )

    assert np.allclose(embedding.T @ full_gradient, reduced_gradient, atol=1e-12)


def test_reduced_static_rejects_a_control_outside_the_ansatz():
    controls = list(embed_reduced_static((1.0, 2.0, 3.0, 5.0, 7.0, 11.0)))
    controls[2] = 1.0e-3

    try:
        reduced_amplitudes_from_controls(controls)
    except ValueError as error:
        assert "reduced static ansatz" in str(error)
    else:
        raise AssertionError("outside control was incorrectly accepted")
