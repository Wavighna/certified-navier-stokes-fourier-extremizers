"""Analyze amplitude-rescaled trajectories at their first enstrophy doubling."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--reference-enstrophy", type=float, default=100.0)
    parser.add_argument("--delta", type=float, default=0.1)
    parser.add_argument("--plot", type=Path)
    args = parser.parse_args()

    rows = []
    for path in args.inputs:
        archive = np.load(path)
        metadata = json.loads(str(archive["metadata"].item()))
        history = archive["trajectory"]
        dt = float(metadata["dt"] if "dt" in metadata else metadata["config"]["dt"])
        enstrophy = history[:, 1]
        indices = np.flatnonzero(enstrophy >= 2.0 * enstrophy[0])
        index = int(indices[0]) if indices.size else history.shape[0] - 1
        zeta = history[:, 11]
        chi = zeta / enstrophy**0.25
        q_delta = history[:, 2] / enstrophy ** (2.0 + args.delta)
        time = index * dt
        mean_q = (
            enstrophy[0] ** (-1.0 - args.delta)
            - enstrophy[index] ** (-1.0 - args.delta)
        ) / ((1.0 + args.delta) * time)
        beta = -np.log(chi[index] / chi[0]) / np.log(
            enstrophy[index] / enstrophy[0]
        )
        rows.append(
            {
                "path": str(path),
                "initial_enstrophy": float(enstrophy[0]),
                "amplification": float(enstrophy[index] / enstrophy[0]),
                "time": float(time),
                "amplitude_scaled_time": float(
                    np.sqrt(enstrophy[0] / args.reference_enstrophy) * time
                ),
                "fitted_chi_exponent": float(beta),
                "zeta_ratio": float(zeta[index] / zeta[0]),
                "persistence_flatness": float(q_delta[: index + 1].min() / mean_q),
                "palinstrophy_tail": float(history[: index + 1, 10].max()),
            }
        )
    rows.sort(key=lambda row: row["initial_enstrophy"])
    print(json.dumps(rows, indent=2))

    if args.plot is not None:
        enstrophy = np.asarray([row["initial_enstrophy"] for row in rows])
        beta = np.asarray([row["fitted_chi_exponent"] for row in rows])
        scaled_time = np.asarray([row["amplitude_scaled_time"] for row in rows])
        flatness = np.asarray([row["persistence_flatness"] for row in rows])
        fig, axes = plt.subplots(1, 3, figsize=(12, 3.7), constrained_layout=True)
        axes[0].semilogx(enstrophy, beta, "o-")
        axes[0].axhline(0.25, color="black", linestyle="--", label="critical 1/4")
        axes[0].set(ylabel=r"fitted $\beta$ in $\chi\sim E^{-\beta}$")
        axes[0].legend(fontsize=8)
        axes[1].semilogx(enstrophy, scaled_time, "o-")
        axes[1].set(ylabel="amplitude-scaled crossing time")
        axes[2].semilogx(enstrophy, flatness, "o-")
        axes[2].set(ylabel="production flatness", ylim=(0.0, 1.0))
        for axis in axes:
            axis.set_xlabel("initial enstrophy")
            axis.grid(alpha=0.25)
        args.plot.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(args.plot, dpi=180)


if __name__ == "__main__":
    main()
