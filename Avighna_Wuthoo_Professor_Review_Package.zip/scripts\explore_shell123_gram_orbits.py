"""Count symmetry-reduced bilinear Gram degrees of freedom for shell (1,2,3).

This is structure reconnaissance only: no inequality or SOS claim is made.
The shell-three coordinates are the linear Cauchy factor, so the quartic
remainder lives on products of shell-one and shell-two coordinates.
"""

from __future__ import annotations

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.shellwise_bounds import _shell_indices
from extreme_flows.static_symmetry import IDENTITY_GENERATOR, signed_coordinate_matrices, static_symmetry_matrix


def summary() -> dict[str, int]:
    model = StaticLowModePolynomial()
    first_shell, second_shell = _shell_indices(model, 1), _shell_indices(model, 2)
    first_position = {coordinate: index for index, coordinate in enumerate(first_shell)}
    second_position = {coordinate: index for index, coordinate in enumerate(second_shell)}
    basis = tuple((first, second) for first in range(len(first_shell)) for second in range(len(second_shell)))
    basis_position = {item: index for index, item in enumerate(basis)}

    def action(generator):
        def shell_action(coordinates, positions):
            destination, signs = [], []
            for column in coordinates:
                rows = [row for row in coordinates if generator[row][column]]
                if len(rows) != 1:
                    raise ArithmeticError("action is not signed-permutational on a required shell")
                destination.append(positions[rows[0]])
                signs.append(int(generator[rows[0]][column]))
            return destination, signs
        first_destination, first_signs = shell_action(first_shell, first_position)
        second_destination, second_signs = shell_action(second_shell, second_position)
        return (
            tuple(basis_position[(first_destination[left], second_destination[right])] for left, right in basis),
            tuple(first_signs[left] * second_signs[right] for left, right in basis),
        )

    actions = [
        action(static_symmetry_matrix((IDENTITY_GENERATOR[0], shift)))
        for shift in ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    ]
    actions.extend(action(static_symmetry_matrix((matrix, (0, 0, 0)))) for matrix in signed_coordinate_matrices())
    entries = tuple((first, second) for first in range(len(basis)) for second in range(first, len(basis)))
    entry_position = {entry: index for index, entry in enumerate(entries)}
    parent, signs_to_parent, forced_zero = list(range(len(entries))), [1] * len(entries), [False] * len(entries)

    def find(index: int):
        if parent[index] == index:
            return index, 1
        direct = parent[index]
        root, inherited = find(direct)
        signs_to_parent[index] *= inherited
        parent[index] = root
        return root, signs_to_parent[index]

    def union(left: int, right: int, relation: int) -> None:
        left_root, left_sign = find(left)
        right_root, right_sign = find(right)
        if left_root == right_root:
            if left_sign != relation * right_sign:
                forced_zero[left_root] = True
            return
        parent[left_root] = right_root
        signs_to_parent[left_root] = relation * right_sign * left_sign
        forced_zero[right_root] = forced_zero[right_root] or forced_zero[left_root]

    for destination, signs in actions:
        for index, (left, right) in enumerate(entries):
            union(entry_position[tuple(sorted((destination[left], destination[right])))], index, signs[left] * signs[right])
    roots = {find(index)[0] for index in range(len(entries))}
    return {
        "bilinear_basis_size": len(basis),
        "symmetric_gram_entries": len(entries),
        "all_orbits": len(roots),
        "forced_zero_orbits": sum(forced_zero[root] for root in roots),
        "free_signed_orbits": sum(not forced_zero[root] for root in roots),
    }


if __name__ == "__main__":
    print(summary())
