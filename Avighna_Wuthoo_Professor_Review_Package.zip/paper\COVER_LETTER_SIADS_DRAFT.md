# Draft cover letter for SIADS — do not submit without author confirmation

Dear Editor,

Please consider the enclosed manuscript, “Certified symmetry-reduced
local maximizers in a periodic 3D Navier--Stokes Fourier
Fourier class,” for publication in the SIAM Journal on Applied Dynamical
Systems.

The paper studies a fixed-enstrophy instantaneous-production problem in a
specified 64-real-coordinate Fourier class. Its contributions are exact
symmetry reductions, a computer-assisted global maximum within a
six-amplitude fixed space, an explicit competing two-amplitude full-KKT
branch with a closed optimized-rate formula, and a rigorously certified branch
crossover. At the inviscid endpoint, it also certifies two distinct full-space
strict local maxima modulo translations and their exact positive value gap.
The paper makes no claim of a global optimum in the full Fourier class and no
claim about Navier--Stokes global regularity or finite-time singularities.

The submission includes a reproducibility package containing exact rational
Fourier algebra, Arb/Krawczyk proof records at two precisions, source hashes,
candidate data, a one-command verifier, and a reviewer guide. The supplied
supplement index identifies the contents and their role in verification.

[AUTHOR MUST CONFIRM: This manuscript is original, is not under consideration
elsewhere, and has not previously been published in substantially the same
form.]

[AUTHOR MUST CONFIRM: All authors have approved the submission, authorship and
affiliations are accurate, conflicts of interest and funding disclosures are
complete, and SIAM’s current policies (including any AI-use disclosure
requirements) have been reviewed and satisfied.]

Thank you for your consideration.

Sincerely,

[Corresponding author name, affiliation, postal address, and email]
