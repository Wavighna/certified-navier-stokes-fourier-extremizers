"""Generate a numerical 64-variable static KKT candidate (not a proof)."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from extreme_flows.certify import optimize_static_rate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "candidate",
        nargs="?",
        default="artifacts/candidates/persistent_v3_low_modes.json",
    )
    parser.add_argument(
        "--output",
        default="artifacts/proofs/static_low_mode_kkt_candidate.json",
    )
    parser.add_argument("--max-iterations", type=int, default=600)
    parser.add_argument(
        "--adaptive-active-chart",
        action="store_true",
        help="phase-fix the active waves (2,0,0), (0,2,0), and (0,0,1)",
    )
    args = parser.parse_args()

    phase_waves = (
        ((2, 0, 0), (0, 2, 0), (0, 0, 1))
        if args.adaptive_active_chart
        else None
    )
    payload = optimize_static_rate(
        args.candidate,
        max_iterations=args.max_iterations,
        phase_waves=phase_waves,
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    candidate = payload["candidate"]
    print(f"wrote {output}")
    print(f"R={candidate['rate']:.15g}")
    print(f"scaled KKT residual={candidate['scaled_kkt_residual']:.3e}")
    print(f"numeric bordered inertia={candidate['numeric_bordered_hessian_inertia']}")
    print("interval Krawczyk/local maximum proof: NOT CERTIFIED")


if __name__ == "__main__":
    main()
