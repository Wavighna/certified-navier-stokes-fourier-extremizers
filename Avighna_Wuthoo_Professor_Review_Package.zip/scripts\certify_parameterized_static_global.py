"""Emit the parameter-uniform high-eta global ansatz certificate."""

from __future__ import annotations

from hashlib import sha256
import json
from pathlib import Path

from extreme_flows.reduced_static_global import build_global_static_certificate
from extreme_flows.reduced_static_parameterized_global import (
    high_eta_global_ansatz_theorem,
)


ROOT = Path(__file__).resolve().parents[1]


def _record(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "size_bytes": len(data),
        "sha256": sha256(data).hexdigest(),
    }


def build_certificate() -> dict[str, object]:
    """Combine exact resultant logic with the independent Arb sign anchor."""

    theorem = high_eta_global_ansatz_theorem()
    anchor = build_global_static_certificate(precisions=(256, 512))
    if not anchor["claims"]["global_maximum_within_six_amplitude_static_ansatz"]:
        raise AssertionError("eta=10^6 Arb anchor did not certify strict face dominance")
    return {
        "schema_version": 1,
        "truth_label": "proved_parameter_uniform_high_eta_global_static_ansatz_maximum",
        "parameter_regime": "eta=E0/nu^2 > 1867/4",
        "proof": theorem,
        "arb_anchor": {
            "eta": "1000000",
            "precisions": [run["precision_bits"] for run in anchor["arb"]["runs"]],
            "strict_interior_dominance": [
                run["strict_interior_dominance"] for run in anchor["arb"]["runs"]
            ],
        },
        "claims": theorem["claims"],
        "checker_source": {
            "script": _record(Path(__file__).resolve()),
            "parameterized_global": _record(
                ROOT / "src" / "extreme_flows" / "reduced_static_parameterized_global.py"
            ),
            "parameterized_branch": _record(
                ROOT / "src" / "extreme_flows" / "reduced_static_parameterized.py"
            ),
            "fixed_point_anchor": _record(
                ROOT / "src" / "extreme_flows" / "reduced_static_global.py"
            ),
        },
    }


def main() -> None:
    output = ROOT / "artifacts" / "proofs" / "parameterized_static_global.json"
    payload = build_certificate()
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output.relative_to(ROOT)}")
    print(payload["truth_label"])


if __name__ == "__main__":
    main()
