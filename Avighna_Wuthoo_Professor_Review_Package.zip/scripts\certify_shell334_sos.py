"""Write the exact SOS certificate for the (3,3,4) shellwise bound."""

from __future__ import annotations

import json
from pathlib import Path

from extreme_flows.shellwise_bounds import shell334_sos_certificate


def main() -> None:
    output = Path("artifacts/proofs/shell334_sos_certificate.json")
    payload = shell334_sos_certificate()
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(payload["truth_label"])
    print(f"wrote {output}")


if __name__ == "__main__":
    main()
