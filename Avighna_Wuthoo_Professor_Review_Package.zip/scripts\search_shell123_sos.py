"""Numerically search a symmetry-adapted SOS for the ``(1,2,3)`` block.

This is a discovery calculation only. A successful result is not a theorem
until an exact coefficient identity and an exact PSD proof are added.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
from fractions import Fraction
import json
from pathlib import Path

import cvxpy as cp
import numpy as np

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.inviscid_sos_target import exact_stretching_cubic_terms
from extreme_flows.shellwise_bounds import _shell_indices, shell_of_coordinate
from explore_shell123_gram_orbits import summary  # validates the same group model is small
from extreme_flows.static_symmetry import IDENTITY_GENERATOR, signed_coordinate_matrices, static_symmetry_matrix


def build_system(cauchy_constant: Fraction = Fraction(16, 3)):
    model = StaticLowModePolynomial()
    shell_one, shell_two, shell_three = (_shell_indices(model, item) for item in (1, 2, 3))
    one_position = {coordinate: index for index, coordinate in enumerate(shell_one)}
    two_position = {coordinate: index for index, coordinate in enumerate(shell_two)}
    three_position = {coordinate: index for index, coordinate in enumerate(shell_three)}
    basis = tuple((first, second) for first in range(12) for second in range(24))
    basis_position = {item: index for index, item in enumerate(basis)}
    components: list[dict[tuple[int, int], Fraction]] = [defaultdict(Fraction) for _ in shell_three]
    for monomial, coefficient in exact_stretching_cubic_terms(model).items():
        if tuple(sorted(shell_of_coordinate(model, index) for index in monomial)) != (1, 2, 3):
            continue
        left = next(one_position[index] for index in monomial if index in one_position)
        middle = next(two_position[index] for index in monomial if index in two_position)
        linear = next(index for index in monomial if index in three_position)
        components[three_position[linear]][(left, middle)] += coefficient

    target: dict[tuple[int, int], Fraction] = {}
    # C E1 E2 gives coefficient (C/4) d1_i*d2_j on (y_i z_j)^2.
    for left, global_left in enumerate(shell_one):
        for middle, global_middle in enumerate(shell_two):
            target[(basis_position[(left, middle)], basis_position[(left, middle)])] = (
                cauchy_constant / 4 * model.enstrophy_diagonal_exact[global_left] * model.enstrophy_diagonal_exact[global_middle]
            )
    for position, component in enumerate(components):
        divisor = model.enstrophy_diagonal_exact[shell_three[position]]
        for left, left_value in component.items():
            for right, right_value in component.items():
                key = tuple(sorted((basis_position[left], basis_position[right])))
                target[key] = target.get(key, Fraction(0)) - 2 * left_value * right_value / divisor

    def action(generator):
        def shell_action(coordinates, positions):
            destination, signs = [], []
            for column in coordinates:
                rows = [row for row in coordinates if generator[row][column]]
                if len(rows) != 1:
                    raise ArithmeticError("required shell action is not signed-permutational")
                destination.append(positions[rows[0]])
                signs.append(int(generator[rows[0]][column]))
            return destination, signs
        first_destination, first_signs = shell_action(shell_one, one_position)
        second_destination, second_signs = shell_action(shell_two, two_position)
        return (
            tuple(basis_position[(first_destination[left], second_destination[right])] for left, right in basis),
            tuple(first_signs[left] * second_signs[right] for left, right in basis),
        )

    actions = [action(static_symmetry_matrix((IDENTITY_GENERATOR[0], shift))) for shift in ((1, 0, 0), (0, 1, 0), (0, 0, 1))]
    actions.extend(action(static_symmetry_matrix((matrix, (0, 0, 0)))) for matrix in signed_coordinate_matrices())
    entries = tuple((first, second) for first in range(288) for second in range(first, 288))
    entry_position = {entry: index for index, entry in enumerate(entries)}
    parent, signs_to_parent, forced_zero = list(range(len(entries))), [1] * len(entries), [False] * len(entries)
    def find(index: int):
        if parent[index] == index:
            return index, 1
        direct = parent[index]
        root, inherited = find(direct)
        signs_to_parent[index] *= inherited
        parent[index] = root
        return root, signs_to_parent[index]
    def union(left: int, right: int, relation: int) -> None:
        left_root, left_sign = find(left); right_root, right_sign = find(right)
        if left_root == right_root:
            if left_sign != relation * right_sign: forced_zero[left_root] = True
            return
        parent[left_root] = right_root; signs_to_parent[left_root] = relation * right_sign * left_sign
        forced_zero[right_root] = forced_zero[right_root] or forced_zero[left_root]
    for destination, signs in actions:
        for index, (left, right) in enumerate(entries):
            union(entry_position[tuple(sorted((destination[left], destination[right])))], index, signs[left] * signs[right])
    roots = [find(index)[0] for index in range(len(entries))]
    free = tuple(root for root in sorted(set(roots)) if not forced_zero[root])
    if len(free) != 50: raise ArithmeticError("unexpected orbit count")
    free_position = {root: index for index, root in enumerate(free)}
    coefficient_rows: dict[tuple[int, int], dict[int, int]] = defaultdict(lambda: defaultdict(int))
    gram_basis = np.zeros((50, 288, 288))
    for index, (left, right) in enumerate(entries):
        root = roots[index]
        if forced_zero[root]: continue
        sign = find(index)[1]
        parameter = free_position[root]
        coefficient_rows[(left, right)][parameter] += sign * (1 if left == right else 2)
        gram_basis[parameter, left, right] = sign; gram_basis[parameter, right, left] = sign
    support = sorted(set(coefficient_rows) | set(target))
    matrix = np.zeros((len(support), 50)); rhs = np.zeros(len(support))
    for row, key in enumerate(support):
        for column, value in coefficient_rows[key].items(): matrix[row, column] = value
        rhs[row] = float(target.get(key, 0))
    return matrix, rhs, gram_basis, target


def main() -> None:
    parser = argparse.ArgumentParser(); parser.add_argument("--output", default="tmp/shell123_sdp.json")
    parser.add_argument("--constant", default="16/3", help="coefficient C in A123^2 <= C E1 E2 E3")
    args = parser.parse_args(); constant = Fraction(args.constant); matrix, rhs, basis, target = build_system(constant)
    print("orbit summary", summary()); print("system", matrix.shape, "rank", np.linalg.matrix_rank(matrix), "target", len(target))
    variable = cp.Variable(50); gram = sum(variable[index] * basis[index] for index in range(50))
    problem = cp.Problem(cp.Minimize(cp.trace(gram)), [matrix @ variable == rhs, gram >> 0])
    problem.solve(solver="CLARABEL", max_iter=50_000)
    eigenvalues = np.linalg.eigvalsh(np.asarray(gram.value, dtype=float)) if gram.value is not None else np.array([])
    payload = {"truth_label":"numerical_sos_search_not_a_certificate", "constant":str(constant), "status":problem.status, "objective":None if problem.value is None else float(problem.value), "max_coefficient_residual":None if variable.value is None else float(np.max(np.abs(matrix @ variable.value-rhs))), "minimum_gram_eigenvalue":None if not eigenvalues.size else float(eigenvalues[0]), "orbit_values":None if variable.value is None else [float(value) for value in variable.value]}
    output=Path(args.output); output.parent.mkdir(parents=True,exist_ok=True); output.write_text(json.dumps(payload,indent=2)+"\n",encoding="utf-8"); print(json.dumps(payload,indent=2))


if __name__ == "__main__": main()
