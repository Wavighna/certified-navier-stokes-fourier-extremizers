"""Plot the two exact symmetry-branch rate formulas used in Paper A.

The plotted values are numerical evaluations of the exact reduced formulas.
The unique crossover is not inferred from this figure: it is certified
separately by ``certify_branch_crossover.py``.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
SIX_BRANCH_THRESHOLD = 1867.0 / 4.0
CROSSOVER_ETA = 27992.671985287174
ASYMPTOTIC_TWO_TERM_PREDICTOR = 28834.301203176604


def competing_rate(eta: np.ndarray) -> np.ndarray:
    """Return the two-amplitude optimized rate divided by nu cubed."""

    return (4.0 / 9.0) * ((eta + 1.0) ** 1.5 - 6.0 * eta - 1.0)


def _six_branch_multiplier(eta: float) -> float:
    """Return the unique admissible positive six-branch multiplier."""

    coefficients = (
        69.0,
        1696.0,
        14936.0 - 32.0 * eta,
        54656.0 - 512.0 * eta,
        68368.0 - 2048.0 * eta,
    )
    roots = np.roots(coefficients)
    candidates = [root.real for root in roots if abs(root.imag) < 1.0e-9 and root.real > np.sqrt(28.0)]
    if len(candidates) != 1:
        raise RuntimeError(f"expected one admissible multiplier at eta={eta}, found {roots}")
    return candidates[0]


def six_branch_rate(eta: np.ndarray) -> np.ndarray:
    """Evaluate the exact high-eta six-amplitude branch formula."""

    mu = np.asarray([_six_branch_multiplier(float(value)) for value in eta])
    return (
        23.0 * mu**5
        + 516.0 * mu**4
        + 3840.0 * mu**3
        + 8864.0 * mu**2
        - 8432.0 * mu
        - 33728.0
    ) / (16.0 * (mu + 8.0) ** 2)


def plot(output_directory: Path) -> tuple[Path, Path]:
    """Write PNG and PDF branch-comparison figures and return their paths."""

    output_directory.mkdir(parents=True, exist_ok=True)
    eta = np.geomspace(500.0, 1.0e5, 400)
    normalization = eta**1.5
    figure, axis = plt.subplots(figsize=(6.6, 4.1), constrained_layout=True)
    axis.semilogx(
        eta,
        competing_rate(eta) / normalization,
        color="#1f77b4",
        linewidth=2.2,
        label="two-amplitude branch",
    )
    axis.semilogx(
        eta,
        six_branch_rate(eta) / normalization,
        color="#d62728",
        linewidth=2.2,
        label="six-amplitude branch",
    )
    axis.axvline(CROSSOVER_ETA, color="black", linewidth=1.0, linestyle="--")
    axis.axvspan(
        CROSSOVER_ETA,
        ASYMPTOTIC_TWO_TERM_PREDICTOR,
        color="#777777",
        alpha=0.16,
        linewidth=0,
    )
    axis.annotate(
        r"certified crossover $\eta_\times\approx 27993$",
        xy=(CROSSOVER_ETA, 0.42),
        xytext=(0.97 * CROSSOVER_ETA, 0.29),
        horizontalalignment="right",
        arrowprops={"arrowstyle": "-", "color": "black", "linewidth": 0.8},
        fontsize=9,
    )
    axis.annotate(
        r"two-term predictor $\eta_{\rm 2t}=28834$",
        xy=(ASYMPTOTIC_TWO_TERM_PREDICTOR, 0.425),
        xytext=(1.09 * ASYMPTOTIC_TWO_TERM_PREDICTOR, 0.46),
        horizontalalignment="left",
        arrowprops={"arrowstyle": "-", "color": "#666666", "linewidth": 0.8},
        fontsize=8,
        color="#555555",
    )
    axis.set_xlim(500.0, 1.0e5)
    axis.set_ylim(0.0, 0.52)
    axis.set_xlabel(r"dimensionless enstrophy $\eta=E/\nu^2$")
    axis.set_ylabel(r"branch rate $\mathcal{R}/(\nu^3\eta^{3/2})$")
    axis.set_title("Exact symmetry-branch rate comparison")
    axis.grid(True, which="both", alpha=0.25)
    axis.legend(frameon=False, loc="lower right")
    png = output_directory / "symmetry_branch_rates.png"
    pdf = output_directory / "symmetry_branch_rates.pdf"
    figure.savefig(png, dpi=220)
    figure.savefig(pdf)
    plt.close(figure)
    return png, pdf


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=ROOT / "paper" / "figures")
    args = parser.parse_args()
    png, pdf = plot(args.output_dir)
    print(f"wrote {png}")
    print(f"wrote {pdf}")


if __name__ == "__main__":
    main()
