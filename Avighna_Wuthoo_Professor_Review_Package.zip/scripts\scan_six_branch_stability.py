"""Numerically map full-space Hessian stability along the high-eta six branch.

This is a reproducible diagnostic, not an interval proof.  It evaluates the
exact 64-control polynomial and its Hessian on the explicit six-amplitude KKT
branch, then records the constrained Hessian spectrum after removing the
three translation zero modes numerically.  A sign change would identify a
candidate bifurcation for a future exact certificate.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path

import numpy as np
from scipy.linalg import null_space

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.reduced_static import embed_reduced_static
from extreme_flows.reduced_static_parameterized import (
    UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD,
    dimensionless_interior_quartic,
)


def _branch_state(eta: float, target_enstrophy: float) -> tuple[float, np.ndarray, float]:
    """Return viscosity, exact-branch float controls, and multiplier."""

    if eta <= float(UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD):
        raise ValueError("eta must be strictly above the interior-branch threshold")
    if target_enstrophy <= 0:
        raise ValueError("target enstrophy must be positive")
    viscosity = np.sqrt(target_enstrophy / eta)
    coefficients = dimensionless_interior_quartic(Fraction(str(eta)))
    roots = np.roots([float(value) for value in reversed(coefficients)])
    candidates = [
        root.real
        for root in roots
        if abs(root.imag) < 1.0e-8 and root.real > np.sqrt(28.0)
    ]
    if len(candidates) != 1:
        raise ArithmeticError("failed to identify the high-eta interior multiplier")
    mu = candidates[0]
    multiplier = mu * viscosity
    a2 = viscosity**2 * 3 * (mu + 6) * (3 * mu**2 + 48 * mu + 156) / (32 * (mu + 8))
    d2 = viscosity**2 * (5 * mu**2 + 48 * mu + 100) / 64
    f2 = viscosity**2 * (mu**2 - 28) / 16
    a, d, f = np.sqrt((a2, d2, f2))
    b = -d * f / (multiplier + 8 * viscosity)
    c = 2 * a * d / (3 * (multiplier + 6 * viscosity))
    e = a * f / (3 * (multiplier + 6 * viscosity))
    return viscosity, np.asarray(embed_reduced_static((a, b, c, d, e, f)), dtype=float), multiplier


def scan(
    eta_values: list[float], *, target_enstrophy: float = 100.0, zero_tolerance: float = 1.0e-7
) -> dict[str, object]:
    """Evaluate full constrained-Hessian inertia over the requested eta values."""

    model = StaticLowModePolynomial(viscosity=Fraction(0))
    rows: list[dict[str, object]] = []
    for eta in eta_values:
        viscosity, controls, multiplier = _branch_state(float(eta), target_enstrophy)
        model.viscosity = Fraction(str(viscosity))
        evaluated = model.evaluate(controls)
        gradient_residual = np.asarray(evaluated["gradient_rate"]) - multiplier * np.asarray(
            evaluated["gradient_enstrophy"]
        )
        tangent = null_space(np.asarray(evaluated["gradient_enstrophy"])[None, :])
        hessian = np.asarray(evaluated["hessian_rate"]) - multiplier * np.asarray(
            evaluated["hessian_enstrophy"]
        )
        eigenvalues = np.linalg.eigvalsh(tangent.T @ hessian @ tangent)
        nontranslation = eigenvalues[np.abs(eigenvalues) > zero_tolerance]
        rows.append(
            {
                "eta": float(eta),
                "viscosity": viscosity,
                "multiplier_over_viscosity": multiplier / viscosity,
                "enstrophy": float(evaluated["enstrophy"]),
                "stretching": float(evaluated["stretching"]),
                "max_abs_full_kkt_residual": float(np.max(np.abs(gradient_residual))),
                "negative_nontranslation_eigenvalue_count": int(np.sum(nontranslation < 0)),
                "positive_nontranslation_eigenvalue_count": int(np.sum(nontranslation > 0)),
                "translation_zero_count_numerical": int(len(eigenvalues) - len(nontranslation)),
                "least_negative_nontranslation_eigenvalue": float(np.max(nontranslation)),
                "most_negative_nontranslation_eigenvalue": float(np.min(nontranslation)),
            }
        )
    return {
        "truth_label": "numerical_full_hessian_stability_atlas_not_uniform_certificate",
        "statement": (
            "Floating-point full-Hessian atlas of the exact six-amplitude KKT branch. "
            "It can locate candidate crossings but does not prove stability between samples."
        ),
        "model": {
            "dimension": 64,
            "independent_mode_pairs": 16,
            "target_enstrophy": target_enstrophy,
            "eta_threshold_open": str(UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD),
            "zero_tolerance": zero_tolerance,
        },
        "rows": rows,
        "summary": {
            "all_sampled_nontranslation_eigenvalues_negative": all(
                row["positive_nontranslation_eigenvalue_count"] == 0
                and row["negative_nontranslation_eigenvalue_count"] == 60
                and row["translation_zero_count_numerical"] == 3
                and row["least_negative_nontranslation_eigenvalue"] < 0
                for row in rows
            ),
            "largest_sampled_nontranslation_eigenvalue": max(
                row["least_negative_nontranslation_eigenvalue"] for row in rows
            ),
            "full_space_uniform_local_maximum_proved": False,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=25)
    parser.add_argument("--eta-max", type=float, default=1.0e10)
    parser.add_argument("--output", default="artifacts/raw/six_branch_full_hessian_atlas.json")
    args = parser.parse_args()
    if args.count < 2:
        raise ValueError("count must be at least two")
    eta_min = float(UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD) + 1.0e-3
    eta_values = np.geomspace(eta_min, float(args.eta_max), int(args.count)).tolist()
    payload = scan(eta_values)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output}")
    print(payload["summary"])


if __name__ == "__main__":
    main()
