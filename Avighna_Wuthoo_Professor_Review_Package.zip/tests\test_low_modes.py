import json

import numpy as np

from extreme_flows.low_modes import (
    CANONICAL_WAVEVECTORS,
    CONTROL_DIMENSION,
    POLARIZATIONS,
    LowModeControl,
    load_low_mode_candidate,
)
from extreme_flows.search import spectral_enstrophy
from extreme_flows.spectral import SpectralGrid, diagnostics


def test_canonical_basis_has_sixteen_transverse_orthonormal_pairs():
    assert CANONICAL_WAVEVECTORS.shape == (16, 3)
    assert CONTROL_DIMENSION == 64
    assert np.all((np.sum(CANONICAL_WAVEVECTORS**2, axis=1) > 0))
    assert np.all((np.sum(CANONICAL_WAVEVECTORS**2, axis=1) <= 4))
    assert np.allclose(
        np.einsum("pi,pai->pa", CANONICAL_WAVEVECTORS, POLARIZATIONS),
        0.0,
        atol=1e-15,
    )
    gram = np.einsum("pai,pbi->pab", POLARIZATIONS, POLARIZATIONS)
    assert np.allclose(gram, np.eye(2)[None, :, :], atol=1e-15)
    for k in CANONICAL_WAVEVECTORS:
        first_nonzero = next(component for component in k if component != 0)
        assert first_nonzero > 0


def test_sphere_control_has_resolution_independent_target_enstrophy():
    coordinates = np.linspace(-1.0, 2.0, CONTROL_DIMENSION)
    control = LowModeControl(coordinates, target_enstrophy=12.5)
    energies = []
    for n in (16, 20, 32):
        grid = SpectralGrid(n)
        state = control.lift(grid)
        assert np.isclose(
            float(spectral_enstrophy(state, grid)), 12.5, rtol=1e-13, atol=1e-13
        )
        assert float(diagnostics(state, grid, 0.01)["divergence_l2"]) < 1e-12
        energies.append(float(diagnostics(state, grid, 0.01)["energy"]))
    assert np.allclose(energies, energies[0], rtol=1e-13, atol=1e-13)


def test_legacy_candidate_and_v2_export_round_trip(tmp_path):
    source = "artifacts/candidates/depletion_v3_low_modes.json"
    control = load_low_mode_candidate(source)
    exported = tmp_path / "candidate.json"
    control.save(exported, metadata={"test": True})
    reloaded = load_low_mode_candidate(exported)

    assert np.allclose(reloaded.coordinates, control.coordinates, atol=2e-15)
    assert reloaded.target_enstrophy == control.target_enstrophy
    document = json.loads(exported.read_text())
    assert document["control_dimension"] == 64
    assert len(document["modes"]) == 32
    assert document["metadata"] == {"test": True}

