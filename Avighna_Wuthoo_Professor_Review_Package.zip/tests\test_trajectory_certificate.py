from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

import pytest

from extreme_flows.certify import load_exactified_candidate
from extreme_flows.trajectory_certificate import (
    _bilinear_norm,
    _inner_bound,
    _vector_modulus,
    build_trajectory_certificate,
    evaluate_trajectory_certificate,
)


def test_wiener_bound_helpers() -> None:
    x = [Fraction(2), Fraction(3), Fraction(5), Fraction(7)]
    y = [Fraction(11), Fraction(13), Fraction(17), Fraction(19)]
    assert _bilinear_norm(x, y, 0) == 26
    assert _bilinear_norm(x, y, 2) == 2 * 19 + 2 * 3 * 17 + 5 * 13
    assert _inner_bound(x, y) == min(2 * 17, 3 * 13, 5 * 11)


def test_zero_centered_ball_has_finite_vector_modulus() -> None:
    from flint import acb, arb

    tiny = arb("0 +/- 1e-30")
    modulus = _vector_modulus((acb(tiny, tiny), acb(tiny, tiny), acb(0)))
    assert modulus.is_finite()
    assert not modulus.is_nan()


def test_trajectory_builder_requires_256_and_512_bits() -> None:
    with pytest.raises(ValueError, match="256-bit and 512-bit"):
        build_trajectory_certificate(
            "unused-because-validation-runs-first.json",
            precisions=(256,),
        )
    with pytest.raises(ValueError, match="256-bit and 512-bit"):
        build_trajectory_certificate(
            "unused-because-validation-runs-first.json",
            precisions=(256, 384),
        )


def test_archived_trajectory_statement_uses_certified_tau() -> None:
    with open(
        "artifacts/proofs/p3_trajectory_certificate.json",
        encoding="utf-8",
    ) as stream:
        payload = json.load(stream)
    assert payload["claim"]["certified"]
    assert payload["claim"]["tau"] in payload["claim"]["statement"]
    assert "exactification_module" in payload["checker_source"]
    for record in payload["checker_source"].values():
        source = Path(record["path"])
        data = source.read_bytes()
        assert record["size_bytes"] == len(data)
        assert record["sha256"] == sha256(data).hexdigest()


def test_positive_time_certificate_at_256_and_512_bits() -> None:
    datum = load_exactified_candidate(
        "artifacts/candidates/persistent_v3_low_modes.json"
    )
    for precision in (256, 512):
        run = evaluate_trajectory_certificate(
            datum,
            precision=precision,
            trial_times=(Fraction(1, 800),),
        )
        attempt = run["attempts"][0]
        assert run["certified"]
        assert run["certified_tau"] == "1/800"
        assert attempt["qprime_tube"].lower() > attempt["certified_slope"].upper()
        assert attempt["analytic_radius_minimum"].lower() > 0
