import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pytest

from extreme_flows.low_modes import LowModeControl, load_low_mode_candidate
from extreme_flows.multires import MultiResolutionConfig
from scripts.run_multires_search import (
    build_campaign_provenance,
    build_acceptance_metadata,
    initial_q_floor_provenance,
    select_final_candidate,
    trust_solver_acceptance,
)


def validation_summary(
    n, gamma, palinstrophy_tail=0.01, dt=0.0005, hard_feasible=True
):
    return {
        "minimum_scoring_gamma": gamma,
        "dt": dt,
        "all_hard_feasible": hard_feasible,
        "grids": [
            {
                "n": n,
                "maximum_palinstrophy_tail": palinstrophy_tail,
            }
        ],
    }


def test_acceptance_metadata_serializes_all_resolution_thresholds():
    result = build_acceptance_metadata(
        joint_grid_sizes=(16, 20),
        optimized_gammas=np.asarray([[-0.04, -0.05], [-0.0402, -0.0502]]),
        validation_summaries=(
            validation_summary(16, -0.049),
            validation_summary(20, -0.052),
            validation_summary(24, -0.053),
            validation_summary(32, -0.055),
            validation_summary(48, -0.061, palinstrophy_tail=0.02),
        ),
        optimization_history=np.linspace(0.0, 5.0e-7, 20),
        gradient_checks=({"relative_error": 1.0e-5},),
        final_summary={"all_hard_feasible": True},
        best_result={
            "trust": SimpleNamespace(
                success=True,
                optimality=1.0e-6,
                constraint_violation=1.0e-8,
            )
        },
    )

    assert result["joint_n16_n20_score_spread"]["accepted"]
    assert result["dt_halving_worst_gamma"]["N16"]["accepted"]
    assert result["dt_halving_worst_gamma"]["N20"]["accepted"]
    assert result["n32_n48_degradation_from_optimized_worst"]["N32"][
        "accepted"
    ]
    assert not result["n32_n48_degradation_from_optimized_worst"]["N48"][
        "accepted"
    ]
    assert result["n32_n48_same_dt_spatial_degradation"]["N48"][
        "accepted"
    ]
    assert result["n48_palinstrophy_tail"]["accepted"]
    assert result["validation_hard_feasibility"][
        "all_validation_replays_hard_feasible"
    ]
    assert result["acceptance"]["all_available_plan_thresholds_pass"]
    json.dumps(result)


def test_acceptance_metadata_keeps_unavailable_smoke_metrics_null():
    result = build_acceptance_metadata(
        joint_grid_sizes=(8, 10),
        optimized_gammas=np.asarray([[0.1], [0.11]]),
        validation_summaries=(),
        optimization_history=(0.0,),
        gradient_checks=({"relative_error": 1.0e-6},),
        final_summary={"all_hard_feasible": False},
        best_result={},
    )

    assert result["joint_n16_n20_score_spread"]["accepted"] is None
    assert result["dt_halving_worst_gamma"]["N16"] is None
    assert result["n32_n48_degradation_from_optimized_worst"]["N48"] is None
    assert result["acceptance"]["all_available_plan_thresholds_pass"] is None
    json.dumps(result)


def test_acceptance_rejects_any_hard_infeasible_validation_replay():
    result = build_acceptance_metadata(
        joint_grid_sizes=(16, 20),
        optimized_gammas=np.asarray([[-0.04, -0.05], [-0.0402, -0.0502]]),
        validation_summaries=(
            validation_summary(16, -0.049),
            validation_summary(20, -0.052),
            validation_summary(24, -0.053),
            validation_summary(32, -0.055),
            validation_summary(48, -0.056, hard_feasible=False),
        ),
        optimization_history=np.linspace(0.0, 5.0e-7, 20),
        gradient_checks=({"relative_error": 1.0e-5},),
        final_summary={"all_hard_feasible": True},
        best_result={
            "trust": SimpleNamespace(
                success=True,
                optimality=1.0e-6,
                constraint_violation=1.0e-8,
            )
        },
    )

    assert not result["validation_hard_feasibility"]["by_grid"]["N48"]
    assert not result["acceptance"]["all_validation_replays_hard_feasible"]
    assert not result["acceptance"]["all_available_plan_thresholds_pass"]


def test_initial_q_floor_provenance_is_parameter_tuple_specific():
    certified = initial_q_floor_provenance(MultiResolutionConfig())
    custom = initial_q_floor_provenance(
        MultiResolutionConfig(viscosity=0.02)
    )

    assert certified["covered_by_bundled_P3_certificate"]
    assert certified["truth_label"] == "certified_P3_onset_lower_bound"
    assert certified["certificate_sha256"] is not None
    assert not custom["covered_by_bundled_P3_certificate"]
    assert "not_covered" in custom["truth_label"]
    json.dumps(certified)
    json.dumps(custom)


def test_trust_acceptance_requires_success_optimality_and_constraint_violation():
    accepted = trust_solver_acceptance(
        SimpleNamespace(
            success=True,
            optimality=9.0e-6,
            constraint_violation=9.0e-7,
        )
    )
    failed_status = trust_solver_acceptance(
        SimpleNamespace(
            success=False,
            optimality=1.0e-8,
            constraint_violation=1.0e-9,
        )
    )
    failed_violation = trust_solver_acceptance(
        SimpleNamespace(
            success=True,
            optimality=1.0e-8,
            constraint_violation=2.0e-6,
        )
    )

    assert accepted["accepted"]
    assert not failed_status["accepted"]
    assert not failed_violation["accepted"]


def test_final_selection_prioritizes_accepted_trust_and_labels_fallbacks():
    accepted_trust = {
        "label": "trust-accepted",
        "objective": -1.0,
        "summary": {"all_hard_feasible": True, "minimum_exact_gamma": -0.05},
        "trust": SimpleNamespace(
            success=True,
            optimality=1.0e-6,
            constraint_violation=1.0e-8,
        ),
    }
    higher_untrusted = {
        "label": "adam-higher",
        "objective": 1.0,
        "summary": {"all_hard_feasible": True, "minimum_exact_gamma": 0.02},
    }
    selected, metadata = select_final_candidate(
        (higher_untrusted, accepted_trust)
    )
    assert selected["label"] == "trust-accepted"
    assert metadata["fully_accepted_trust_result_exists"]
    assert metadata["selected_is_accepted_trust_result"]

    failed_trust = {
        **accepted_trust,
        "label": "trust-failed",
        "trust": SimpleNamespace(
            success=False,
            optimality=1.0e-6,
            constraint_violation=1.0e-8,
        ),
    }
    fallback, fallback_metadata = select_final_candidate(
        (higher_untrusted, failed_trust)
    )
    assert fallback["label"] == "adam-higher"
    assert not fallback_metadata["fully_accepted_trust_result_exists"]
    assert "unaccepted" in fallback_metadata["exported_candidate_status"]


def test_campaign_provenance_hashes_code_inputs_and_dependency_manifests():
    args = SimpleNamespace(
        d3=Path("artifacts/candidates/depletion_v3_low_modes.json"),
        d2=Path("artifacts/candidates/depletion_v2_low_mode_control.json"),
        p3=Path("artifacts/candidates/persistent_v3_low_modes.json"),
    )
    provenance = build_campaign_provenance(args)

    assert set(provenance["source_files"]) == {
        "campaign_script",
        "low_modes",
        "multires",
        "spectral",
        "mechanisms",
        "pyproject",
    }
    for record in provenance["source_files"].values():
        assert record["exists"]
        assert record["size_bytes"] > 0
        assert len(record["sha256"]) == 64
        assert not Path(record["path"]).is_absolute()
    for record in provenance["input_files"].values():
        assert record["exists"]
        assert len(record["sha256"]) == 64
        assert not Path(record["path"]).is_absolute()
    for distribution in provenance["runtime"]["distributions"].values():
        assert distribution["installed"]
        assert distribution["version"]
        assert distribution["metadata"] is not None
        assert distribution["record"] is not None
        assert len(distribution["metadata"]["sha256"]) == 64
        assert len(distribution["record"]["sha256"]) == 64
    json.dumps(provenance)


RAW_D2 = Path("artifacts/raw/depletion_v2_from_v3_n10_e100_t020.npz")


@pytest.mark.skipif(not RAW_D2.exists(), reason="historical raw D2 seed absent")
def test_tracked_d2_coordinates_exactly_match_historical_raw_seed():
    tracked = load_low_mode_candidate(
        "artifacts/candidates/depletion_v2_low_mode_control.json"
    )
    with np.load(RAW_D2) as archive:
        historical = LowModeControl.from_state(
            archive["state"], target_enstrophy=100.0
        )

    np.testing.assert_array_equal(tracked.coordinates, historical.coordinates)
