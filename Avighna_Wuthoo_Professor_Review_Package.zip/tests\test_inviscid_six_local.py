from scripts.certify_inviscid_six_local import build_certificate


def test_inviscid_six_branch_is_certified_full_space_local_maximum():
    payload = build_certificate((256, 512))
    assert payload["claims"]["exact_translated_formula_is_inside_unique_kkt_box"]
    assert payload["claims"]["strict_local_maximum_modulo_translations_at_E_100"]
    assert payload["claims"]["strict_local_maximum_modulo_translations_for_every_positive_E"]
    assert payload["claims"]["full_64d_inviscid_global_maximum"] is False
    for run in payload["runs"]:
        assert run["formula_failed_component_count"] == 0
        assert run["bordered_inertia"]["verified"]
        assert run["bordered_inertia"]["positive"] == 4
        assert run["bordered_inertia"]["negative"] == 64
        assert run["bordered_inertia"]["zero_or_unresolved"] == 0
