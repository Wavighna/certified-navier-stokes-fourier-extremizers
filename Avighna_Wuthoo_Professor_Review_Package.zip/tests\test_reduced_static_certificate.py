import json
from hashlib import sha256
from pathlib import Path

import pytest

from extreme_flows.reduced_static_certificate import (
    build_reduced_static_certificate,
    evaluate_reduced_static_certificate_arb,
)


def test_reduced_static_certificate_requires_two_declared_precisions():
    with pytest.raises(ValueError, match="256-bit and 512-bit"):
        build_reduced_static_certificate("unused.json", precisions=(256,))


def test_reduced_static_krawczyk_and_bordered_inertia():
    pytest.importorskip("flint")
    with open(
        "artifacts/proofs/static_adaptive_kkt_candidate.json", encoding="utf-8"
    ) as handle:
        candidate = json.load(handle)["candidate"]
    run = evaluate_reduced_static_certificate_arb(candidate, precision=128)

    assert run["krawczyk_verified"]
    assert run["existence_verified"]
    assert run["uniqueness_verified"]
    assert run["bordered_inertia"]["verified"]
    assert run["bordered_inertia"]["positive"] == 1
    assert run["bordered_inertia"]["negative"] == 6
    assert run["bordered_inertia"]["zero_or_unresolved"] == 0


def test_archived_reduced_certificate_has_current_checker_hashes():
    payload = json.loads(
        Path("artifacts/proofs/reduced_static_arb_certificate.json").read_text(
            encoding="utf-8"
        )
    )
    assert payload["claims"]["strict_local_maximum_within_six_amplitude_ansatz"]
    for record in payload["checker_source"].values():
        data = Path(record["path"]).read_bytes()
        assert record["size_bytes"] == len(data)
        assert record["sha256"] == sha256(data).hexdigest()
