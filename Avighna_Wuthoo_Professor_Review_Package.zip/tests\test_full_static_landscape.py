import json

import numpy as np

from extreme_flows.certify import ADAPTIVE_PHASE_WAVES, StaticLowModePolynomial
from scripts.explore_full_static_landscape import _polish_kkt, explore


def test_full_static_random_restart_smoke_matches_symmetry_branch():
    payload = explore(starts=2, seed=20260812, max_iterations=250)
    summary = payload["summary"]
    assert summary["full_global_maximum_proved"] is False
    assert summary["all_runs_within_relative_1e-8_of_parameterized_ansatz_reference"]
    assert len(payload["runs"]) == 2


def test_inviscid_cubic_random_restart_smoke_matches_six_space_reference():
    payload = explore(starts=2, seed=20260813, max_iterations=250, viscosity=0.0)
    summary = payload["summary"]
    assert payload["model"]["objective"] == "stretching A at fixed E"
    assert summary["full_global_maximum_proved"] is False
    assert summary["all_runs_within_relative_1e-8_of_parameterized_ansatz_reference"]


def test_phase_fixed_kkt_polish_reaches_the_certified_static_branch():
    payload = json.loads(
        open("artifacts/proofs/static_adaptive_kkt_candidate.json", encoding="utf-8").read()
    )
    model = StaticLowModePolynomial(phase_waves=ADAPTIVE_PHASE_WAVES)
    controls = np.asarray(payload["candidate"]["controls"], dtype=float)
    polished, success, residual = _polish_kkt(controls, model, 100.0)
    assert success
    assert residual < 1.0e-10
    assert abs(model.evaluate(polished)["rate"] - 449.7183372304457) < 1.0e-10
