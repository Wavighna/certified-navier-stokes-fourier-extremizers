from pathlib import Path

from scripts.verify_paper_a import verify


def test_paper_a_verifier_reports_the_limited_claim_set():
    payload = verify()
    claims = payload["claims"]
    assert claims["global_static_maximum_inside_six_amplitude_ansatz"]
    assert claims["strict_local_full_64d_maximum_modulo_translations"]
    assert claims["reduced_global_root_identified_with_full_local_root"]
    assert claims["unique_admissible_positive_interior_branch_for_eta_gt_1867_over_4"]
    assert claims["global_six_amplitude_ansatz_maximum_for_eta_gt_1867_over_4"]
    assert claims["higher_competing_full_64d_local_maximum_at_eta_10000"]
    assert claims["higher_branch_exact_two_amplitude_full_kkt_formula_for_all_positive_E_nu"]
    assert claims["competing_ansatz_lattice_symmetry_group_is_A4_times_C2"]
    assert claims["uniform_high_eta_competing_full_64d_local_maximum_modulo_translations"]
    assert claims["uniform_all_eta_competing_full_64d_local_maximum_modulo_translations"]
    assert claims["uniform_high_eta_six_branch_full_64d_local_maximum_modulo_translations"]
    assert claims["exact_shell112_enstrophy_production_bound"]
    assert claims["exact_shell123_enstrophy_production_bound"]
    assert claims["exact_shell224_enstrophy_production_bound"]
    assert claims["exact_shell334_enstrophy_production_bound"]
    assert claims["unique_ordered_crossover_between_the_two_high_eta_symmetry_branches"]
    assert claims["six_amplitude_branch_has_strictly_higher_high_eta_efficiency_than_competing_branch"]
    assert claims["exact_inviscid_six_amplitude_cubic_global_maximizer_inside_its_fixed_space"]
    assert claims["two_term_asymptotics_explain_the_large_scale_of_the_certified_branch_switch"]
    assert not claims["full_64d_global_maximum"]
    assert not claims["navier_stokes_regularity_or_blowup_statement"]
    for source in payload["checker_sources"].values():
        assert Path(source["path"]).is_file()
