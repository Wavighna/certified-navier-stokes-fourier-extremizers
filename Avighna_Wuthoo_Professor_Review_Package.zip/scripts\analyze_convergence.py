"""Compare saved refinement trajectories and emit strict resolution diagnostics."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import jax.numpy as jnp
import matplotlib.pyplot as plt
import numpy as np

from extreme_flows.spectral import (
    SpectralGrid,
    diagnostics,
    ifft_velocity,
    oversampled_max_vorticity,
    strain_alignment_diagnostics,
)


def _metadata(archive: np.lib.npyio.NpzFile) -> dict:
    return json.loads(str(archive["metadata"].item()))


def _time_step(metadata: dict) -> float:
    if "dt" in metadata:
        return float(metadata["dt"])
    return float(metadata["config"]["dt"])


def _viscosity(metadata: dict) -> float:
    if "viscosity" in metadata:
        return float(metadata["viscosity"])
    return float(metadata["config"]["viscosity"])


def _final_state(archive: np.lib.npyio.NpzFile) -> np.ndarray | None:
    if "final_state" in archive.files:
        return archive["final_state"]
    return None


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", type=Path, nargs="+")
    parser.add_argument("--delta", type=float, default=0.1)
    parser.add_argument("--start-time", type=float, default=0.0)
    parser.add_argument("--oversample", type=int, default=1)
    parser.add_argument("--plot", type=Path)
    args = parser.parse_args()

    runs = []
    for path in args.inputs:
        archive = np.load(path)
        metadata = _metadata(archive)
        history = archive["trajectory"]
        dt = _time_step(metadata)
        n = int(metadata.get("n", archive["state"].shape[0]))
        time = np.arange(history.shape[0]) * dt
        runs.append(
            {
                "path": str(path),
                "n": n,
                "dt": dt,
                "nu": _viscosity(metadata),
                "time": time,
                "history": history,
                "final_state": _final_state(archive),
            }
        )
    runs.sort(key=lambda run: run["n"])

    report: dict[str, dict] = {}
    finest = runs[-1]
    finest_history = finest["history"]
    finest_time = finest["time"]
    for run in runs:
        history = run["history"]
        time = run["time"]
        energy = history[:, 0]
        enstrophy = history[:, 1]
        rate = history[:, 2]
        margin = rate / enstrophy ** (2.0 + args.delta)
        start_index = int(np.searchsorted(time, args.start_time, side="left"))
        entry = {
            "path": run["path"],
            "dt": run["dt"],
            "time_final": float(time[-1]),
            "energy_final": float(energy[-1]),
            "enstrophy_final": float(enstrophy[-1]),
            "enstrophy_amplification": float(enstrophy[-1] / enstrophy[0]),
            "rate_final": float(rate[-1]),
            "persistence_margin_min": float(margin[start_index:].min()),
            "persistence_margin_final": float(margin[-1]),
            "max_vorticity_final": float(history[-1, 6]),
            "stored_velocity_tail_final": float(history[-1, 5]),
            "enstrophy_balance_relative_residual": float(
                abs(enstrophy[-1] - enstrophy[0] - np.trapezoid(rate, time))
                / max(abs(enstrophy[-1] - enstrophy[0]), 1.0e-30)
            ),
            "energy_balance_relative_residual": float(
                abs(energy[-1] - energy[0] + 2.0 * run["nu"] * np.trapezoid(enstrophy, time))
                / max(abs(energy[-1] - energy[0]), 1.0e-30)
            ),
        }

        if run is not finest:
            for column, name in ((1, "enstrophy"), (2, "rate"), (6, "max_vorticity")):
                reference = np.interp(time, finest_time, finest_history[:, column])
                entry[f"{name}_max_relative_difference_from_finest"] = float(
                    np.max(abs(history[:, column] - reference) / np.maximum(abs(reference), 1.0e-30))
                )

        final_state = run["final_state"]
        if final_state is not None:
            grid = SpectralGrid(run["n"])
            state = jnp.asarray(final_state)
            diag = diagnostics(state, grid, run["nu"])
            alignment = strain_alignment_diagnostics(state, grid)
            speed = np.sqrt(np.sum(np.asarray(ifft_velocity(state)) ** 2, axis=-1))
            entry.update(
                {
                    "final_enstrophy_tail": float(diag["spectral_enstrophy_tail_fraction"]),
                    "final_palinstrophy_tail": float(diag["spectral_palinstrophy_tail_fraction"]),
                    "final_palinstrophy": float(diag["palinstrophy"]),
                    "final_stretching_efficiency": float(diag["stretching_efficiency"]),
                    "final_max_velocity": float(speed.max()),
                    "final_advective_cfl": float(run["dt"] * speed.max() / (grid.length / grid.n)),
                    "final_oversampled_max_vorticity": float(
                        oversampled_max_vorticity(state, grid, factor=args.oversample)
                    ),
                    "stretching_contributions": np.asarray(
                        alignment["stretching_contributions"]
                    ).tolist(),
                    "vorticity_alignment_fractions": np.asarray(
                        alignment["vorticity_alignment_fractions"]
                    ).tolist(),
                    "normalized_stretching": float(alignment["normalized_stretching"]),
                    "strain_topology_factor": float(alignment["strain_topology_factor"]),
                    "normalized_strain_concentration": float(
                        alignment["normalized_strain_concentration"]
                    ),
                    "betchov_relative_residual": float(
                        alignment["betchov_relative_residual"]
                    ),
                }
            )
        report[f"N{run['n']}"] = entry

    print(json.dumps(report, indent=2))

    if args.plot is not None:
        fig, axes = plt.subplots(2, 2, figsize=(11, 8), constrained_layout=True)
        has_palinstrophy_tail = all(
            run["history"].shape[1] > 10 for run in runs
        )
        for run in runs:
            h = run["history"]
            t = run["time"]
            label = f"N={run['n']}, dt={run['dt']:g}"
            axes[0, 0].plot(t, h[:, 1] / h[0, 1], label=label)
            axes[0, 1].plot(t, h[:, 2] / h[:, 1] ** (2.0 + args.delta), label=label)
            axes[1, 0].plot(t, h[:, 6], label=label)
            tail_column = 10 if has_palinstrophy_tail else 5
            axes[1, 1].semilogy(
                t, np.maximum(h[:, tail_column], 1.0e-16), label=label
            )
        axes[0, 0].set(ylabel=r"$E(t)/E(0)$", xlabel="time")
        axes[0, 1].set(ylabel=rf"$E'/E^{{{2.0 + args.delta:g}}}$", xlabel="time")
        axes[1, 0].set(ylabel=r"$\|\omega\|_\infty$", xlabel="time")
        axes[1, 1].set(
            ylabel=(
                "palinstrophy tail"
                if has_palinstrophy_tail
                else "stored velocity-energy tail"
            ),
            xlabel="time",
        )
        for axis in axes.flat:
            axis.grid(alpha=0.25)
        axes[0, 0].legend(fontsize=8)
        args.plot.parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(args.plot, dpi=180)


if __name__ == "__main__":
    main()
