"""Lightweight source-level consistency checks for the submission draft.

The workspace has no TeX engine, so these checks deliberately validate the
parts that do not require typesetting: bibliography keys, cited proof objects,
and the explicit no-overclaim scope sentence.
"""

from __future__ import annotations

import re
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def test_latex_citations_are_backed_by_bibtex_entries() -> None:
    tex = (ROOT / "paper/main.tex").read_text(encoding="utf-8")
    bib = (ROOT / "paper/references.bib").read_text(encoding="utf-8")
    cited = {
        key.strip()
        for group in re.findall(r"\\cite\{([^}]+)\}", tex)
        for key in group.split(",")
    }
    entries = set(re.findall(r"@\w+\{([^,]+),", bib))
    assert cited <= entries
    # The two nonstandard proof transitions need primary references, not only
    # a repository artifact: symmetric criticality and Krawczyk inclusion.
    assert {"Palais1979", "Krawczyk1969"} <= cited


def test_latex_lists_existing_primary_proof_objects_and_scope() -> None:
    tex = (ROOT / "paper/main.tex").read_text(encoding="utf-8")
    plain_tex = tex.replace("\\_", "_")
    for name in (
        "reduced_static_global_arb_certificate.json",
        "reduced_static_standalone_algebra_audit.json",
        "high_branch_eta10000_arb_certificate.json",
        "reduced_competing_formula.json",
        "competing_symmetry_group.json",
        "competing_representation_sectors.json",
        "competing_high_eta_uniform.json",
        "competing_all_eta_uniform.json",
        "six_branch_high_eta_uniform.json",
        "shell112_sos_certificate.json",
        "shell123_sos_certificate.json",
        "shell224_sos_certificate.json",
        "shell334_sos_certificate.json",
        "symmetry_branch_crossover.json",
    ):
        assert name in plain_tex
        assert (ROOT / "artifacts/proofs" / name).is_file()
    assert "None of the results proves a full-space global maximum" in tex
    assert "global regularity" in tex
    assert "figures/symmetry_branch_rates.pdf" in tex
    assert (ROOT / "paper/figures/symmetry_branch_rates.pdf").is_file()
    assert (ROOT / "paper/figures/symmetry_branch_rates.png").is_file()


def test_latex_states_exact_fourier_and_competing_symmetry_conventions() -> None:
    tex = (ROOT / "paper/main.tex").read_text(encoding="utf-8")
    for fragment in (
        "All convolution, Leray projection, and inner products",
        "performed over $\\mathbb Q(\\mathrm{i})$",
        "(Q_1,m_1)",
        "$A_4\\times C_2$",
        "$(2,6,24)$",
        "\\label{thm:uniformcompeting}",
        "47/50>9049/10000",
        "\\operatorname{diag}(-1,1,1)",
        "$(3,0,48)$, $(3,0,96)$, and $(0,24,0,0)$",
        "identity of polynomials, not an interpolation",
        "K=3a^2+24b^2",
        "H=\\langle u\\cdot\\nabla\\times u\\rangle=0",
        "$|k|^2=1$ shell",
        "$|k|^2=2$ shell",
        "\\label{eq:physicalbranch}",
        "-2a\\cos y-8b\\sin y\\cos z",
        "\\label{eq:tworate}",
        "\\frac{33+15\\sqrt5}{2}",
    ):
        assert fragment in tex


def test_latex_has_formal_limited_branch_theorems_and_conclusion() -> None:
    tex = (ROOT / "paper/main.tex").read_text(encoding="utf-8")
    for label in (
        "thm:six",
        "thm:highsix",
        "thm:uniformsix",
        "thm:twoplaneglobal",
        "thm:competing",
        "thm:uniformcompeting",
        "thm:switch",
            "prop:efficiency",
            "thm:inviscidlocal",
            "thm:inviscidcoexistence",
    ):
        assert f"\\label{{{label}}}" in tex
    assert "\\section{Conclusion}" in tex
    assert "not to infer anything about arbitrary Fourier data" in tex
    assert "16/1863" in tex
    assert "analytic implicit-function theorem" in tex
    assert "1913\\sqrt{138}" in tex
    assert "inviscid_six_full64_local_certificate.json" in tex.replace("\\_", "_")
    assert "inviscid_competing_full64_local_certificate.json" in tex.replace("\\_", "_")
    assert "six_branch_high_eta_uniform.json" in tex.replace("\\_", "_")
    assert "shell112_sos_certificate.json" in tex.replace("\\_", "_")
    assert "shell123_sos_certificate.json" in tex.replace("\\_", "_")
    assert "shell224_sos_certificate.json" in tex.replace("\\_", "_")
    assert "shell334_sos_certificate.json" in tex.replace("\\_", "_")
    assert "prop:shell112" in tex


def test_latex_has_submission_metadata_and_formula_light_abstract() -> None:
    tex = (ROOT / "paper/main.tex").read_text(encoding="utf-8")
    abstract = tex.split(r"\begin{abstract}", 1)[1].split(r"\end{abstract}", 1)[0]
    assert r"\paragraph{Key words.}" in tex
    assert r"\paragraph{MSC codes.} 76D05, 65G40." in tex
    assert r"\[" not in abstract
    assert len(abstract.split()) < 250
