"""Generate the exact P3 onset-derivative certificate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from extreme_flows.certify import build_onset_certificate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "candidate",
        nargs="?",
        default="artifacts/candidates/persistent_v3_low_modes.json",
    )
    parser.add_argument(
        "--output",
        default="artifacts/proofs/p3_onset_certificate.json",
    )
    parser.add_argument("--precisions", nargs="+", type=int, default=(256, 512))
    args = parser.parse_args()

    payload = build_onset_certificate(args.candidate, precisions=args.precisions)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    final = payload["arb"]["runs"][-1]
    print(f"wrote {output}")
    print(f"q(0)    = {final['q0_ball']}")
    print(f"q'(0)   = {final['qprime0_ball']}")
    certified = bool(
        payload["claims"]["qprime_at_zero_strictly_positive"]
        and payload["claims"]["strict_one_sided_local_bottleneck"]
    )
    print(
        "strict one-sided local bottleneck: "
        + ("CERTIFIED" if certified else "NOT CERTIFIED")
    )
    print(
        "positive-time interval: outside this onset-only artifact; "
        "see artifacts/proofs/p3_trajectory_certificate.json"
    )
    if not certified:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
