"""Checkpointed continuation of a selected full 64-coordinate static branch.

This is a numerical bifurcation diagnostic, not a certificate.  It follows a
specified terminal state from a random-restart archive as the target
enstrophy, equivalently eta=E0/nu**2, changes.  Every step is written before
the next is attempted so an interrupted run preserves the branch history.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path

import numpy as np
from scipy.optimize import minimize

from extreme_flows.certify import ADAPTIVE_PHASE_WAVES, StaticLowModePolynomial
from extreme_flows.reduced_static_parameterized import dimensionless_interior_quartic
from extreme_flows.reduced_static_parameterized_global import interior_dimensionless_rate


def _ansatz_rate(eta: float, viscosity: float) -> float:
    coefficients = dimensionless_interior_quartic(Fraction(str(eta)))
    roots = np.roots([float(value) for value in reversed(coefficients)])
    mu = next(
        root.real
        for root in roots
        if abs(root.imag) < 1.0e-8 and root.real > np.sqrt(28.0)
    )
    return viscosity**3 * float(interior_dimensionless_rate(Fraction(str(mu))))


def _step(eta: float, direction: np.ndarray, viscosity: float) -> tuple[np.ndarray, dict[str, object]]:
    target = eta * viscosity * viscosity
    model = StaticLowModePolynomial(
        viscosity=Fraction(str(viscosity)), phase_waves=ADAPTIVE_PHASE_WAVES
    )
    weights = model.enstrophy_diagonal

    def lift(vector: np.ndarray) -> tuple[np.ndarray, float]:
        quadratic = float(np.dot(weights * vector, vector))
        scale = np.sqrt(2.0 * target / quadratic)
        return scale * vector, quadratic

    def objective(vector: np.ndarray) -> float:
        return -float(model.evaluate(lift(vector)[0])["rate"])

    def gradient(vector: np.ndarray) -> np.ndarray:
        controls, quadratic = lift(vector)
        ambient = np.asarray(model.evaluate(controls)["gradient_rate"], dtype=float)
        scale = np.sqrt(2.0 * target / quadratic)
        return -scale * (
            ambient - weights * vector * float(np.dot(ambient, vector)) / quadratic
        )

    result = minimize(
        objective,
        direction,
        jac=gradient,
        method="L-BFGS-B",
        options={"maxiter": 500, "ftol": 1.0e-14, "gtol": 1.0e-9, "maxls": 50},
    )
    controls, _ = lift(result.x)
    rate = -float(result.fun)
    return result.x, {
        "eta": eta,
        "target_enstrophy": target,
        "rate": rate,
        "ansatz_rate": _ansatz_rate(eta, viscosity),
        "rate_ratio_to_ansatz": rate / _ansatz_rate(eta, viscosity),
        "success": bool(result.success),
        "message": str(result.message),
        "iterations": int(result.nit),
        "pullback_gradient_inf_norm": float(np.linalg.norm(gradient(result.x), ord=np.inf)),
        "terminal_controls": [float(value) for value in controls],
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("seed_archive", nargs="?")
    parser.add_argument("--start-index", type=int)
    parser.add_argument("--random-seed", type=int)
    parser.add_argument("--random-restart-index", type=int)
    parser.add_argument("--eta-start", type=float, required=True)
    parser.add_argument("--eta-stop", type=float, required=True)
    parser.add_argument("--eta-step", type=float, default=5.0)
    parser.add_argument("--viscosity", type=float, default=0.01)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    archive_mode = args.seed_archive is not None
    random_mode = args.random_seed is not None or args.random_restart_index is not None
    if archive_mode == random_mode:
        raise ValueError("provide either seed_archive/start-index or random-seed/random-restart-index")
    if archive_mode:
        if args.start_index is None:
            raise ValueError("archive mode requires --start-index")
        seed = json.loads(Path(args.seed_archive).read_text(encoding="utf-8"))
        records = seed.get("runs", seed.get("steps"))
        if records is None:
            raise ValueError("seed archive has neither random-restart runs nor continuation steps")
        initial = np.asarray(records[args.start_index]["terminal_controls"], dtype=float)
        seed_description: object = {"archive": args.seed_archive, "index": args.start_index}
    else:
        if args.random_seed is None or args.random_restart_index is None:
            raise ValueError("random mode requires --random-seed and --random-restart-index")
        generator = np.random.default_rng(args.random_seed)
        for _ in range(args.random_restart_index + 1):
            initial = generator.normal(size=64)
        seed_description = {
            "random_seed": args.random_seed,
            "random_restart_index": args.random_restart_index,
        }
    path = Path(args.output)
    payload = {
        "truth_label": "numerical_static_branch_continuation_only",
        "statement": "Floating-point continuation only; no bifurcation or globality theorem.",
        "seed": seed_description,
        "viscosity": args.viscosity,
        "steps": [],
    }
    direction = initial
    eta = args.eta_start
    while eta <= args.eta_stop + 1.0e-12:
        direction, record = _step(eta, direction, args.viscosity)
        payload["steps"].append(record)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
        print(
            f"eta={eta:.6g} rate={record['rate']:.15g} "
            f"ratio={record['rate_ratio_to_ansatz']:.12g} success={record['success']}",
            flush=True,
        )
        eta += args.eta_step


if __name__ == "__main__":
    main()
