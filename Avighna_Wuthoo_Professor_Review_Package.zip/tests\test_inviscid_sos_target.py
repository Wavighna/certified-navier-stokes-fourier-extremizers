from fractions import Fraction

import numpy as np

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.inviscid_sos_target import (
    INVISCID_CUBIC_CONSTANT_SQUARED,
    diagonal_cauchy_stretching_bound,
    evaluate_sparse_polynomial,
    exact_inviscid_target_terms,
    inviscid_target_metadata,
    translation_sos_basis_structure,
)


def test_exact_sparse_target_matches_direct_invariants_on_random_controls():
    model = StaticLowModePolynomial()
    target = exact_inviscid_target_terms(model)
    controls = np.random.default_rng(20260814).normal(size=model.dimension)
    direct = (
        float(INVISCID_CUBIC_CONSTANT_SQUARED)
        * float(model.evaluate(controls)["enstrophy"]) ** 3
        - float(model.evaluate(controls)["stretching"]) ** 2
    )
    assert abs(evaluate_sparse_polynomial(target, controls) - direct) < 1.0e-14 * max(1.0, abs(direct))


def test_target_metadata_is_explicitly_not_a_globality_certificate():
    payload = inviscid_target_metadata()
    assert payload["constant_squared"] == "8832/42849"
    assert payload["stretching_cubic_monomial_count"] > 0
    assert payload["degree_six_target_monomial_count"] > 0
    assert payload["claims"]["target_nonnegative_proved"] is False
    assert payload["claims"]["full_64d_inviscid_globality_proved"] is False


def test_diagonal_cauchy_bound_is_exactly_too_loose_for_the_sharp_target():
    bound = diagonal_cauchy_stretching_bound()
    assert bound["diagonal_cauchy_constant"] == Fraction(1888, 27)
    assert bound["sharp_target_constant"] == Fraction(128, 621)
    assert bound["ratio_diagonal_over_sharp"] == Fraction(1357, 4)


def test_sparse_cubic_basis_has_exact_quarter_translation_orbits():
    structure = translation_sos_basis_structure()
    assert structure["basis_size"] == 4608
    assert structure["translation_group_size"] == 64
    assert structure["basis_closed_under_all_quarter_translations"]
    assert structure["translation_orbit_count"] == 1732
    assert structure["translation_orbit_size_histogram"] == {
        "1": 144,
        "2": 944,
        "4": 644,
    }
    assert structure["claims"]["sharp_global_sos_certificate_constructed"] is False
