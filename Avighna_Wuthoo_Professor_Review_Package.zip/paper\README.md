# Paper A build and verification

`main.tex` is a journal-neutral manuscript source. It is intentionally
restricted to finite-dimensional Fourier variational statements.

## Mathematical verification

From the repository root, run:

```powershell
.venv\Scripts\python.exe scripts\verify_paper_a.py
```

This recomputes the current 256/512-bit Arb certificates and writes
`artifacts/proofs/paper_a_verification.json`. The manifest must retain both
negative scope flags:

```text
full_64d_global_maximum=False
navier_stokes_regularity_or_blowup_statement=False
```

## Typesetting

In an environment with a TeX distribution installed:

```text
cd paper
latexmk -pdf main.tex
```

The reproducibility release was also rendered on 2026-08-12 with Tectonic
0.17.0, using its portable Windows executable and an explicit workspace-local
cache:

```powershell
$env:TECTONIC_CACHE_DIR = (Resolve-Path '..\tmp\tectonic-cache').Path
..\tmp\tectonic-0.17.0\tectonic.exe -X compile --outdir ..\output\pdf main.tex
```

The released PDF is `output/pdf/paper_a_static_extremizers.pdf`. It was
rendered to PNG pages and visually reviewed after the final source update.
Any submission must still use the journal's requested review format or line
numbering.

## Submission gate

Before any submission, retain the theorem scope above; obtain an independent
review of the exact Fourier algebra and interval checker; complete the
literature-priority audit; compile and visually inspect the PDF; and archive
the exact repository revision plus the proof artifacts.

## Release manifest

After verification, create a content-addressed record of the manuscript,
checker sources, candidates, and proof artifacts:

```powershell
.venv\Scripts\python.exe scripts\build_paper_a_manifest.py
```

The resulting `artifacts/proofs/paper_a_release_manifest.json` is not an
independent audit and does not widen the theorem scope. It is the file list and
hash record to include with an external reproducibility package.

For an external mathematical reviewer, start with paper/REVIEWER_GUIDE.md,
which maps every claim to its source and proof artifact.

## Clean-tree packaging audit

Before releasing the bundle, run:

```powershell
.venv\Scripts\python.exe scripts\audit_paper_a_clean_tree.py
```

This copies the source, scripts, manuscript, and proof inputs into a fresh
temporary tree and reruns the verifier there. It detects undeclared local-file
dependencies, but it is explicitly **not** an independent mathematical or
software audit because it uses the same environment and implementation.
