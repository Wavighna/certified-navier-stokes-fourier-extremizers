"""Exact real isotypic decomposition of the six-branch symmetry action.

The finite group defining the six-amplitude fixed space has order 16. This
script constructs all eight real linear characters by propagation from the
three generators, forms their rational Reynolds projectors, and describes the
remaining 24-dimensional real isotypic component through a central order-four
action. It is structural input for a future uniform Hessian proof, not itself
a stability certificate.
"""

from __future__ import annotations

import argparse
from collections import Counter, deque
from fractions import Fraction
from hashlib import sha256
from itertools import product
import json
from pathlib import Path

import sympy as sp

from extreme_flows.static_symmetry import (
    IDENTITY_GENERATOR,
    STATIC_ANSATZ_GENERATORS,
    compose_lattice_symmetries,
    lattice_symmetry_group,
    lattice_symmetry_order,
    static_symmetry_matrix,
)


ROOT = Path(__file__).resolve().parents[1]


def _record(relative: str) -> dict[str, object]:
    path = ROOT / relative
    data = path.read_bytes()
    return {
        "path": relative.replace("\\", "/"),
        "size_bytes": len(data),
        "sha256": sha256(data).hexdigest(),
    }


def _inverse(group, element):
    return next(
        candidate
        for candidate in group
        if compose_lattice_symmetries(element, candidate) == IDENTITY_GENERATOR
        and compose_lattice_symmetries(candidate, element) == IDENTITY_GENERATOR
    )


def _linear_character(generator_signs: tuple[int, int, int], group):
    """Propagate a proposed +-1 character and reject inconsistent relations."""

    values = {IDENTITY_GENERATOR: 1}
    queue = deque([IDENTITY_GENERATOR])
    while queue:
        current = queue.popleft()
        for generator, sign in zip(STATIC_ANSATZ_GENERATORS, generator_signs, strict=True):
            next_element = compose_lattice_symmetries(current, generator)
            next_value = values[current] * sign
            if next_element in values:
                if values[next_element] != next_value:
                    return None
            else:
                values[next_element] = next_value
                queue.append(next_element)
    return values if len(values) == len(group) else None


def _exact_rank(rows: list[list[Fraction]]) -> int:
    matrix = [row[:] for row in rows if any(row)]
    rank = 0
    column = 0
    while rank < len(matrix) and column < len(matrix[0]):
        pivot = next(
            (row for row in range(rank, len(matrix)) if matrix[row][column]), None
        )
        if pivot is None:
            column += 1
            continue
        matrix[rank], matrix[pivot] = matrix[pivot], matrix[rank]
        scale = matrix[rank][column]
        matrix[rank] = [value / scale for value in matrix[rank]]
        for row in range(len(matrix)):
            if row != rank and matrix[row][column]:
                factor = matrix[row][column]
                matrix[row] = [
                    matrix[row][entry] - factor * matrix[rank][entry]
                    for entry in range(len(matrix[row]))
                ]
        rank += 1
        column += 1
    return rank


def build_payload() -> dict[str, object]:
    """Build the exact real isotypic structure record."""

    group = lattice_symmetry_group(STATIC_ANSATZ_GENERATORS)
    if len(group) != 16:
        raise ArithmeticError("six-branch symmetry group order changed")
    characters = []
    linear_projector_sum = sp.zeros(64)
    for signs in product((-1, 1), repeat=3):
        values = _linear_character(signs, group)
        if values is None:
            continue
        projector = [[Fraction(0) for _ in range(64)] for _ in range(64)]
        for element, value in values.items():
            action = static_symmetry_matrix(element)
            for row in range(64):
                for column in range(64):
                    projector[row][column] += Fraction(value, 16) * action[row][column]
        rank = _exact_rank(projector)
        characters.append({"generator_signs": list(signs), "projector_rank": rank})
        linear_projector_sum += sp.Matrix(projector)
    if len(characters) != 8:
        raise ArithmeticError("expected eight real linear characters")
    linear_dimension = sum(int(row["projector_rank"]) for row in characters)
    residual_projector = sp.eye(64) - linear_projector_sum
    residual_basis = sp.Matrix.hstack(*residual_projector.columnspace())
    if residual_basis.shape[1] != 24:
        raise ArithmeticError("unexpected nonlinear-isotypic residual dimension")

    center = [
        element
        for element in group
        if all(
            compose_lattice_symmetries(element, other)
            == compose_lattice_symmetries(other, element)
            for other in group
        )
    ]
    if len(center) != 4:
        raise ArithmeticError("unexpected center size")
    central_order_four = next(
        element for element in center if lattice_symmetry_order(element) == 4
    )
    central_action = sp.Matrix(static_symmetry_matrix(central_order_four))
    restricted = (residual_basis.T * residual_basis).inv() * residual_basis.T * central_action * residual_basis
    characteristic = sp.factor(restricted.charpoly().as_expr())
    if characteristic != (sp.Symbol("lambda") ** 2 + 1) ** 12:
        raise ArithmeticError("central residual characteristic polynomial changed")

    commutators = {
        compose_lattice_symmetries(
            compose_lattice_symmetries(
                compose_lattice_symmetries(left, right), _inverse(group, left)
            ),
            _inverse(group, right),
        )
        for left in group
        for right in group
    }
    derived = {IDENTITY_GENERATOR}
    changed = True
    while changed:
        changed = False
        for left in tuple(derived):
            for right in tuple(derived | commutators):
                for product_element in (
                    compose_lattice_symmetries(left, right),
                    compose_lattice_symmetries(right, left),
                ):
                    if product_element not in derived:
                        derived.add(product_element)
                        changed = True
    if len(derived) != 2:
        raise ArithmeticError("unexpected derived subgroup order")
    class_sizes = []
    unseen = set(group)
    while unseen:
        representative = unseen.pop()
        conjugacy_class = {
            compose_lattice_symmetries(
                compose_lattice_symmetries(conjugator, representative),
                _inverse(group, conjugator),
            )
            for conjugator in group
        }
        class_sizes.append(len(conjugacy_class))
        unseen -= conjugacy_class
    return {
        "schema_version": 1,
        "truth_label": "exact_six_branch_symmetry_representation_structure_not_hessian_stability_certificate",
        "group": {
            "order": len(group),
            "order_histogram": {
                str(order): count
                for order, count in sorted(
                    Counter(lattice_symmetry_order(element) for element in group).items()
                )
            },
            "center_order": len(center),
            "derived_subgroup_order": len(derived),
            "abelianization_order": len(group) // len(derived),
            "conjugacy_class_sizes": sorted(class_sizes),
        },
        "linear_character_sectors": characters,
        "linear_isotypic_total_dimension": linear_dimension,
        "nonlinear_real_isotypic_component": {
            "dimension": residual_basis.shape[1],
            "central_order_four_characteristic_polynomial": "(lambda^2+1)^12",
            "interpretation": (
                "The residual is a 24-dimensional real component carrying a "
                "complex-type two-dimensional action with multiplicity 12. A "
                "commuting symmetric Hessian reduces to a multiplicity-space "
                "Hermitian block of size 12."
            ),
        },
        "next_required_step": (
            "Derive the generalized Hessian on these exact isotypic sectors "
            "along the six-amplitude branch and apply Sturm/interval continuation."
        ),
        "checker_source": _record("scripts/certify_six_symmetry_representation.py"),
        "symmetry_source": _record("src/extreme_flows/static_symmetry.py"),
        "claims": {
            "exact_real_isotypic_structure_verified": True,
            "uniform_six_branch_hessian_signs_proved": False,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        default="artifacts/proofs/six_branch_symmetry_representation.json",
    )
    args = parser.parse_args()
    payload = build_payload()
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(payload["truth_label"])
    print(f"wrote {output.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
