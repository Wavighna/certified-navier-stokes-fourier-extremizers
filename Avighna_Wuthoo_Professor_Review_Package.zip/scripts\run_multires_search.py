"""Run the fixed-bandwidth N16/N20 critical-depletion search.

The default command implements the targeted eight-start campaign.  ``--smoke``
reduces it to two starts, tiny grids, and one iteration so installation and
archive/checkpoint plumbing can be verified without launching the full run.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import importlib.metadata
import json
import platform
from pathlib import Path
import sys
from time import perf_counter
from typing import Sequence

import jax
import jax.numpy as jnp
import numpy as np

from extreme_flows.low_modes import LowModeControl, load_low_mode_candidate
from extreme_flows.multires import (
    AdamStepTelemetry,
    CERTIFIED_P3_INITIAL_Q_FLOOR,
    MULTIRES_OBJECTIVE_VERSION,
    MultiResolutionConfig,
    deterministic_tangent_perturbations,
    make_raw_evaluator,
    multistage_riemannian_adam,
    summarize_multiresolution,
    tangent_gradient_check,
    trust_constr_epigraph_refine,
)


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
TRUST_OPTIMALITY_TOLERANCE = 1.0e-5
TRUST_CONSTRAINT_VIOLATION_TOLERANCE = 1.0e-6


def _safe_relative_path(path: Path) -> str:
    """Return a reproducible path label without leaking an external directory."""

    resolved = path.resolve()
    try:
        return resolved.relative_to(REPOSITORY_ROOT).as_posix()
    except ValueError:
        return f"external/{resolved.name}"


def _file_record(path: Path) -> dict[str, object]:
    resolved = path.resolve()
    record: dict[str, object] = {
        "path": _safe_relative_path(resolved),
        "exists": resolved.is_file(),
    }
    if resolved.is_file():
        data = resolved.read_bytes()
        record.update(
            {
                "size_bytes": len(data),
                "sha256": hashlib.sha256(data).hexdigest(),
            }
        )
    else:
        record.update({"size_bytes": None, "sha256": None})
    return record


def _distribution_provenance(name: str) -> dict[str, object]:
    """Record an installed distribution and hash its wheel manifests."""

    try:
        distribution = importlib.metadata.distribution(name)
    except importlib.metadata.PackageNotFoundError:
        return {
            "distribution": name,
            "installed": False,
            "version": None,
            "metadata": None,
            "record": None,
        }

    files = distribution.files or ()

    def manifest_record(filename: str) -> dict[str, object] | None:
        relative = next(
            (str(entry) for entry in files if Path(str(entry)).name == filename),
            None,
        )
        if relative is None:
            return None
        path = Path(distribution.locate_file(relative))
        if not path.is_file():
            return None
        data = path.read_bytes()
        return {
            "path": relative.replace("\\", "/"),
            "size_bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        }

    return {
        "distribution": name,
        "installed": True,
        "version": distribution.version,
        "metadata": manifest_record("METADATA"),
        "record": manifest_record("RECORD"),
    }


def build_campaign_provenance(args: argparse.Namespace) -> dict[str, object]:
    """Bind a campaign archive to code, inputs, proofs, and runtime packages."""

    source_paths = {
        "campaign_script": Path(__file__),
        "low_modes": REPOSITORY_ROOT / "src/extreme_flows/low_modes.py",
        "multires": REPOSITORY_ROOT / "src/extreme_flows/multires.py",
        "spectral": REPOSITORY_ROOT / "src/extreme_flows/spectral.py",
        "mechanisms": REPOSITORY_ROOT / "src/extreme_flows/mechanisms.py",
        "pyproject": REPOSITORY_ROOT / "pyproject.toml",
    }
    input_paths = {
        "D3": Path(args.d3),
        "D2": Path(args.d2),
        "P3": Path(args.p3),
    }
    if getattr(args, "resume", None) is not None:
        input_paths["resume_checkpoint"] = Path(args.resume)
    proof_paths = {
        "P3_onset": REPOSITORY_ROOT
        / "artifacts/proofs/p3_onset_certificate.json",
        "P3_trajectory": REPOSITORY_ROOT
        / "artifacts/proofs/p3_trajectory_certificate.json",
        "static_adaptive": REPOSITORY_ROOT
        / "artifacts/proofs/static_adaptive_arb_certificate.json",
    }
    return {
        "schema_version": 1,
        "source_files": {
            name: _file_record(path) for name, path in source_paths.items()
        },
        "input_files": {
            name: _file_record(path) for name, path in input_paths.items()
        },
        "proof_artifacts_present": {
            name: _file_record(path)
            for name, path in proof_paths.items()
            if path.is_file()
        },
        "runtime": {
            "python": sys.version,
            "python_implementation": platform.python_implementation(),
            "platform": platform.platform(),
            "distributions": {
                name: _distribution_provenance(name)
                for name in ("jax", "jaxlib", "numpy", "scipy")
            },
        },
    }


def parse_stages(value: str) -> tuple[tuple[int, float], ...]:
    """Parse ``iterations:temperature`` pairs separated by commas."""

    stages: list[tuple[int, float]] = []
    try:
        for item in value.split(","):
            iterations, temperature = item.split(":", maxsplit=1)
            stages.append((int(iterations), float(temperature)))
    except ValueError as error:
        raise argparse.ArgumentTypeError(
            "stages must look like 100:0.002,75:0.0005"
        ) from error
    if not stages or any(count < 1 or temperature <= 0.0 for count, temperature in stages):
        raise argparse.ArgumentTypeError("stage counts and temperatures must be positive")
    return tuple(stages)


def parse_grid_list(value: str) -> tuple[int, ...]:
    try:
        result = tuple(int(item) for item in value.split(",") if item)
    except ValueError as error:
        raise argparse.ArgumentTypeError("grids must be comma-separated integers") from error
    if any(n < 8 or n % 2 for n in result):
        raise argparse.ArgumentTypeError("grids must be even integers >= 8")
    return result


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--d3",
        type=Path,
        default=Path("artifacts/candidates/depletion_v3_low_modes.json"),
    )
    parser.add_argument(
        "--d2",
        type=Path,
        default=Path("artifacts/candidates/depletion_v2_low_mode_control.json"),
        help="tracked grid-independent D2 low-mode control",
    )
    parser.add_argument(
        "--p3",
        type=Path,
        default=Path("artifacts/candidates/persistent_v3_low_modes.json"),
    )
    parser.add_argument("--resume", type=Path, help="resume coordinates from a checkpoint NPZ")
    parser.add_argument("--viscosity", type=float, default=0.01)
    parser.add_argument("--enstrophy", type=float, default=100.0)
    parser.add_argument("--dt", type=float, default=0.001)
    parser.add_argument("--steps", type=int, default=208)
    parser.add_argument("--block-size", type=int, default=8)
    parser.add_argument("--delta", type=float, default=0.1)
    parser.add_argument(
        "--initial-q-floor",
        type=float,
        default=CERTIFIED_P3_INITIAL_Q_FLOOR,
    )
    parser.add_argument("--initial-q-penalty", type=float, default=50.0)
    parser.add_argument(
        "--endpoint-penalty",
        type=float,
        default=100.0,
        help="quadratic Adam warm-start penalty for endpoint log-amplification",
    )
    parser.add_argument("--screen-iterations", type=int, default=50)
    parser.add_argument(
        "--joint-stages",
        type=parse_stages,
        default=parse_stages("100:0.002,75:0.0005,75:0.0002"),
    )
    parser.add_argument("--screen-learning-rate", type=float, default=0.005)
    parser.add_argument("--joint-learning-rate", type=float, default=0.005)
    parser.add_argument("--backtrack-factor", type=float, default=0.5)
    parser.add_argument(
        "--max-backtracks",
        type=int,
        default=9,
        help=(
            "maximum Adam line-search halvings; the measured campaign cap "
            "drops only sub-1e-5 steps with negligible objective contribution"
        ),
    )
    parser.add_argument(
        "--stage-rejection-patience",
        type=int,
        default=20,
        help=(
            "stop a fixed-temperature Adam stage after this many consecutive "
            "rejected full line searches; zero disables this numerical "
            "plateau control"
        ),
    )
    parser.add_argument("--feasibility-tolerance", type=float, default=1.0e-9)
    parser.add_argument("--q-active-tolerance", type=float, default=2.0e-2)
    parser.add_argument("--q-restoration-cosine", type=float, default=0.1)
    parser.add_argument("--q-boundary-cosine", type=float, default=1.0e-3)
    parser.add_argument("--q-boundary-buffer", type=float, default=1.0e-6)
    parser.add_argument(
        "--trust-iterations",
        type=int,
        default=25,
        help="bounded trust-constr iterations per promoted finalist; zero disables",
    )
    parser.add_argument("--trust-candidates", type=int, default=2)
    parser.add_argument("--trust-gtol", type=float, default=1.0e-5)
    parser.add_argument("--perturbation-scale", type=float, default=0.05)
    parser.add_argument(
        "--validation-grids",
        type=parse_grid_list,
        default=(16, 20, 24, 32, 48),
    )
    parser.add_argument("--validation-dt", type=float, default=0.0005)
    parser.add_argument("--gradient-check-directions", type=int, default=5)
    parser.add_argument("--report-every", type=int, default=10)
    parser.add_argument("--checkpoint-every", type=int, default=10)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("artifacts/candidates/depletion_multires_low_modes.json"),
    )
    parser.add_argument(
        "--archive",
        type=Path,
        default=Path("artifacts/raw/depletion_multires_search.npz"),
    )
    parser.add_argument(
        "--checkpoint",
        type=Path,
        default=Path("artifacts/raw/depletion_multires_checkpoint.npz"),
    )
    parser.add_argument(
        "--summary",
        type=Path,
        default=Path("artifacts/raw/depletion_multires_summary.json"),
    )
    parser.add_argument(
        "--smoke",
        action="store_true",
        help="run a two-grid/two-start one-step plumbing check",
    )
    return parser.parse_args()


def _limits_for_grids(
    grids: Sequence[int], *, smoke: bool = False
) -> tuple[tuple[float, ...], tuple[float, ...], tuple[float, ...]]:
    prescribed = {
        16: (0.01, 0.05, 0.15),
        20: (0.005, 0.025, 0.08),
        # Only the palinstrophy threshold is prescribed for the N48 replay.
        48: (1.0, 1.0, 0.025),
    }
    triples = [prescribed.get(n, (1.0, 1.0, 1.0)) for n in grids]
    if smoke:
        triples = [(1.0, 1.0, 1.0) for _ in grids]
    return tuple(zip(*triples, strict=True))  # type: ignore[return-value]


def make_config(
    args: argparse.Namespace,
    grids: tuple[int, ...],
    *,
    smoke: bool = False,
    dt: float | None = None,
    steps: int | None = None,
) -> MultiResolutionConfig:
    velocity, enstrophy, palinstrophy = _limits_for_grids(grids, smoke=smoke)
    return MultiResolutionConfig(
        grid_sizes=grids,
        viscosity=args.viscosity,
        target_enstrophy=args.enstrophy,
        dt=args.dt if dt is None else dt,
        steps=args.steps if steps is None else steps,
        block_size=min(args.block_size, args.steps if steps is None else steps),
        delta=args.delta,
        initial_q_floor=args.initial_q_floor,
        initial_q_penalty=args.initial_q_penalty,
        endpoint_penalty=args.endpoint_penalty,
        velocity_tail_limits=velocity,
        enstrophy_tail_limits=enstrophy,
        palinstrophy_tail_limits=palinstrophy,
    )


def initial_q_floor_provenance(config: MultiResolutionConfig) -> dict[str, object]:
    """Truth-label whether the configured floor is covered by the P3 proof."""

    certified_parameters = {
        "viscosity": 0.01,
        "target_enstrophy": 100.0,
        "delta": 0.1,
        "q_floor": CERTIFIED_P3_INITIAL_Q_FLOOR,
    }
    configured_parameters = {
        "viscosity": config.viscosity,
        "target_enstrophy": config.target_enstrophy,
        "delta": config.delta,
        "q_floor": config.initial_q_floor,
    }
    matches = all(
        configured_parameters[name] == certified_parameters[name]
        for name in certified_parameters
    )
    certificate_path = Path("artifacts/proofs/p3_onset_certificate.json")
    certificate_file = Path(__file__).resolve().parents[1] / certificate_path
    certificate_hash = (
        hashlib.sha256(certificate_file.read_bytes()).hexdigest()
        if certificate_file.is_file()
        else None
    )
    return {
        "truth_label": (
            "certified_P3_onset_lower_bound"
            if matches
            else "user_configured_constraint_not_covered_by_P3_certificate"
        ),
        "covered_by_bundled_P3_certificate": matches,
        "configured_parameters": configured_parameters,
        "certified_parameter_tuple": certified_parameters,
        "certificate_path": str(certificate_path),
        "certificate_sha256": certificate_hash,
    }


def optimizer_safeguard_metadata(args: argparse.Namespace) -> dict[str, object]:
    """Serialize every line-search safeguard that affects campaign semantics."""

    return {
        "screen_learning_rate": args.screen_learning_rate,
        "joint_learning_rate": args.joint_learning_rate,
        "backtrack_factor": args.backtrack_factor,
        "max_backtracks": args.max_backtracks,
        "stage_rejection_patience": (
            None
            if args.stage_rejection_patience == 0
            else args.stage_rejection_patience
        ),
        "stage_rejection_patience_interpretation": (
            "numerical plateau control, not a stationarity or KKT certificate"
        ),
        "feasibility_tolerance": args.feasibility_tolerance,
        "q_active_tolerance": args.q_active_tolerance,
        "q_restoration_cosine": args.q_restoration_cosine,
        "q_boundary_cosine": args.q_boundary_cosine,
        "q_boundary_buffer": args.q_boundary_buffer,
        "checkpoint_values_are_post_update": True,
    }


def trust_solver_acceptance(trust: object | None) -> dict[str, object]:
    """Evaluate the declared trust-constr solver/KKT acceptance gate."""

    if trust is None:
        return {
            "available": False,
            "success": None,
            "optimality": None,
            "optimality_threshold": TRUST_OPTIMALITY_TOLERANCE,
            "optimality_accepted": None,
            "constraint_violation": None,
            "constraint_violation_threshold": (
                TRUST_CONSTRAINT_VIOLATION_TOLERANCE
            ),
            "constraint_violation_accepted": None,
            "accepted": None,
        }
    success = bool(getattr(trust, "success", False))
    optimality = float(getattr(trust, "optimality", np.inf))
    violation = float(getattr(trust, "constraint_violation", np.inf))
    optimality_accepted = bool(
        np.isfinite(optimality) and optimality < TRUST_OPTIMALITY_TOLERANCE
    )
    violation_accepted = bool(
        np.isfinite(violation)
        and violation <= TRUST_CONSTRAINT_VIOLATION_TOLERANCE
    )
    return {
        "available": True,
        "success": success,
        "optimality": optimality,
        "optimality_threshold": TRUST_OPTIMALITY_TOLERANCE,
        "optimality_accepted": optimality_accepted,
        "constraint_violation": violation,
        "constraint_violation_threshold": TRUST_CONSTRAINT_VIOLATION_TOLERANCE,
        "constraint_violation_accepted": violation_accepted,
        "accepted": success and optimality_accepted and violation_accepted,
    }


def build_acceptance_metadata(
    *,
    joint_grid_sizes: Sequence[int],
    optimized_gammas: np.ndarray,
    validation_summaries: Sequence[dict[str, object]],
    optimization_history: Sequence[float],
    gradient_checks: Sequence[dict[str, float]],
    final_summary: dict[str, object],
    best_result: dict[str, object],
) -> dict[str, object]:
    """Assemble plan-threshold metrics without re-running any trajectory."""

    gamma_array = np.asarray(optimized_gammas, dtype=np.float64)
    optimized_worst = {
        int(n): float(np.min(gamma_array[index]))
        for index, n in enumerate(joint_grid_sizes)
    }
    optimized_global_worst = float(np.min(gamma_array))
    validation_by_grid: dict[int, dict[str, object]] = {}
    validation_hard_feasibility: dict[str, bool] = {}
    for summary in validation_summaries:
        grid_reports = summary.get("grids", [])
        if grid_reports:
            n = int(grid_reports[0]["n"])
            validation_by_grid[n] = summary
            validation_hard_feasibility[f"N{n}"] = bool(
                summary.get("all_hard_feasible", False)
            )
    validation_hard_feasible_all = (
        all(validation_hard_feasibility.values())
        if len(validation_hard_feasibility) == len(validation_summaries)
        and len(validation_summaries) > 0
        else None
    )

    joint_values = [optimized_worst.get(n) for n in (16, 20)]
    if all(value is not None for value in joint_values):
        n16_worst, n20_worst = (float(value) for value in joint_values)
        spread_absolute = abs(n16_worst - n20_worst)
        spread_relative = spread_absolute / max(
            1.0e-12, abs(n16_worst), abs(n20_worst)
        )
        spread_accepted: bool | None = spread_relative <= 0.01
    else:
        spread_absolute = None
        spread_relative = None
        spread_accepted = None

    dt_halving: dict[str, object] = {}
    dt_halving_acceptance: list[bool] = []
    for n in (16, 20):
        validation = validation_by_grid.get(n)
        optimized = optimized_worst.get(n)
        if validation is None or optimized is None:
            dt_halving[f"N{n}"] = None
            continue
        refined = float(validation["minimum_scoring_gamma"])
        delta = refined - optimized
        accepted = abs(delta) <= 0.005
        dt_halving_acceptance.append(accepted)
        dt_halving[f"N{n}"] = {
            "optimized_worst_gamma": optimized,
            "halved_dt_worst_gamma": refined,
            "delta_halved_minus_optimized": delta,
            "absolute_change": abs(delta),
            "threshold": 0.005,
            "accepted": accepted,
        }
    dt_halving_all = (
        all(dt_halving_acceptance) if len(dt_halving_acceptance) == 2 else None
    )

    # Retain the original comparison against the optimized dt=0.001 score.
    # It mixes temporal and spatial refinement and is therefore diagnostic,
    # not the spatial acceptance gate below.
    degradation: dict[str, object] = {}
    degradation_acceptance: list[bool] = []
    for n in (32, 48):
        validation = validation_by_grid.get(n)
        if validation is None:
            degradation[f"N{n}"] = None
            continue
        refined = float(validation["minimum_scoring_gamma"])
        delta = refined - optimized_global_worst
        loss = max(optimized_global_worst - refined, 0.0)
        accepted = loss <= 0.01
        degradation_acceptance.append(accepted)
        degradation[f"N{n}"] = {
            "optimized_joint_worst_gamma": optimized_global_worst,
            "validation_worst_gamma": refined,
            "delta_validation_minus_optimized": delta,
            "degradation": loss,
            "threshold": 0.01,
            "accepted": accepted,
        }
    degradation_all = (
        all(degradation_acceptance) if len(degradation_acceptance) == 2 else None
    )

    # Isolate spatial degradation at the common validation dt.  The reference
    # is the worse of the dt-halved N16/N20 values, exactly as required by the
    # fixed campaign acceptance rule.
    same_dt_spatial: dict[str, object] = {"N32": None, "N48": None}
    same_dt_acceptance: list[bool] = []
    reference_summaries = [validation_by_grid.get(n) for n in (16, 20)]
    reference_dts = [
        summary.get("dt") if summary is not None else None
        for summary in reference_summaries
    ]
    same_reference_dt = (
        reference_dts[0] is not None
        and reference_dts[1] is not None
        and np.isclose(float(reference_dts[0]), float(reference_dts[1]))
    )
    if all(summary is not None for summary in reference_summaries) and same_reference_dt:
        validation_dt = float(reference_dts[0])
        same_dt_reference = min(
            float(summary["minimum_scoring_gamma"])  # type: ignore[index]
            for summary in reference_summaries
        )
        for n in (32, 48):
            validation = validation_by_grid.get(n)
            if validation is None or validation.get("dt") is None:
                continue
            if not np.isclose(float(validation["dt"]), validation_dt):
                continue
            refined = float(validation["minimum_scoring_gamma"])
            delta = refined - same_dt_reference
            loss = max(same_dt_reference - refined, 0.0)
            accepted = loss <= 0.01
            same_dt_acceptance.append(accepted)
            same_dt_spatial[f"N{n}"] = {
                "validation_dt": validation_dt,
                "worst_dt_halved_n16_n20_gamma": same_dt_reference,
                "validation_worst_gamma": refined,
                "delta_validation_minus_same_dt_reference": delta,
                "spatial_degradation": loss,
                "threshold": 0.01,
                "accepted": accepted,
            }
    same_dt_degradation_all = (
        all(same_dt_acceptance) if len(same_dt_acceptance) == 2 else None
    )

    history = [float(value) for value in optimization_history]
    last_20_gain = history[-1] - history[-20] if len(history) >= 20 else None
    last_20_accepted = (
        abs(last_20_gain) < 1.0e-6 if last_20_gain is not None else None
    )
    maximum_gradient_error = (
        max(float(check["relative_error"]) for check in gradient_checks)
        if gradient_checks
        else None
    )
    gradient_accepted = (
        maximum_gradient_error < 1.0e-4
        if maximum_gradient_error is not None
        else None
    )

    trust_gate = trust_solver_acceptance(best_result.get("trust"))
    kkt_accepted = trust_gate["accepted"]
    constraints_accepted = bool(final_summary["all_hard_feasible"])

    n48_validation = validation_by_grid.get(48)
    if n48_validation is None:
        n48_tail_value = None
        n48_tail_accepted = None
        n48_worst_gamma = None
    else:
        n48_report = n48_validation["grids"][0]
        n48_tail_value = float(n48_report["maximum_palinstrophy_tail"])
        n48_tail_accepted = n48_tail_value <= 0.025
        n48_worst_gamma = float(n48_validation["minimum_scoring_gamma"])

    acceptance = {
        "tangent_gradient_relative_error_below_1e-4": gradient_accepted,
        "trust_constr_success_optimality_and_violation_pass": kkt_accepted,
        "last_20_absolute_gain_below_1e-6": last_20_accepted,
        "all_hard_constraints_satisfied": constraints_accepted,
        "all_validation_replays_hard_feasible": validation_hard_feasible_all,
        "joint_n16_n20_relative_spread_within_1_percent": spread_accepted,
        "dt_halving_absolute_gamma_change_within_0p005": dt_halving_all,
        "n32_n48_gamma_degradation_within_0p01": same_dt_degradation_all,
        "n32_n48_same_dt_spatial_degradation_within_0p01": (
            same_dt_degradation_all
        ),
        "n48_palinstrophy_tail_below_0p025": n48_tail_accepted,
        "n48_worst_gamma_positive": (
            n48_worst_gamma > 0.0 if n48_worst_gamma is not None else None
        ),
        # A positive computed gamma is not itself a rigorous numerical error
        # margin, so the anti-depletion claim remains conservatively disabled.
        "anti_depletion_claim_has_certified_positive_error_margin": False,
    }


    required = [
        acceptance[key]
        for key in (
            "tangent_gradient_relative_error_below_1e-4",
            "trust_constr_success_optimality_and_violation_pass",
            "last_20_absolute_gain_below_1e-6",
            "all_hard_constraints_satisfied",
            "all_validation_replays_hard_feasible",
            "joint_n16_n20_relative_spread_within_1_percent",
            "dt_halving_absolute_gamma_change_within_0p005",
            "n32_n48_same_dt_spatial_degradation_within_0p01",
            "n48_palinstrophy_tail_below_0p025",
        )
    ]
    acceptance["all_available_plan_thresholds_pass"] = (
        all(required) if all(value is not None for value in required) else None
    )

    return {
        "optimized_worst_gamma_by_grid": {
            f"N{n}": value for n, value in optimized_worst.items()
        },
        "optimized_joint_worst_gamma": optimized_global_worst,
        "joint_n16_n20_score_spread": {
            "absolute": spread_absolute,
            "relative": spread_relative,
            "relative_threshold": 0.01,
            "accepted": spread_accepted,
        },
        "dt_halving_worst_gamma": dt_halving,
        "n32_n48_degradation_from_optimized_worst": degradation,
        "n32_n48_same_dt_spatial_degradation": same_dt_spatial,
        "combined_time_and_space_degradation_all_pass": degradation_all,
        "last_20_objective_gain": last_20_gain,
        "maximum_tangent_gradient_relative_error": maximum_gradient_error,
        "trust_constr_gate": trust_gate,
        "n48_palinstrophy_tail": {
            "value": n48_tail_value,
            "threshold": 0.025,
            "accepted": n48_tail_accepted,
        },
        "validation_hard_feasibility": {
            "by_grid": validation_hard_feasibility,
            "all_validation_replays_hard_feasible": (
                validation_hard_feasible_all
            ),
        },
        "acceptance": acceptance,
    }


def select_final_candidate(
    candidate_results: Sequence[dict[str, object]],
) -> tuple[dict[str, object], dict[str, object]]:
    """Select conservatively and truth-label the status of the exported point."""

    if not candidate_results:
        raise ValueError("at least one candidate result is required")

    def hard_feasible(result: dict[str, object]) -> bool:
        summary = result.get("summary", {})
        return bool(summary.get("all_hard_feasible", False))  # type: ignore[union-attr]

    def exact_score(result: dict[str, object]) -> float:
        summary = result.get("summary", {})
        value = summary.get("minimum_exact_gamma")  # type: ignore[union-attr]
        return float(value) if value is not None else -np.inf

    def accepted_trust(result: dict[str, object]) -> bool:
        gate = trust_solver_acceptance(result.get("trust"))
        return hard_feasible(result) and bool(gate["accepted"])

    accepted_trust_results = [
        result for result in candidate_results if accepted_trust(result)
    ]
    feasible_results = [result for result in candidate_results if hard_feasible(result)]
    if accepted_trust_results:
        best = max(accepted_trust_results, key=exact_score)
        selection_label = "accepted_trust_result_selected"
        exported_status = "solver_accepted_feasible_trust_candidate"
    elif feasible_results:
        best = max(feasible_results, key=exact_score)
        selection_label = (
            "no_accepted_trust_result_best_feasible_numerical_candidate_exported"
        )
        exported_status = "unaccepted_feasible_numerical_candidate"
    else:
        best = max(candidate_results, key=lambda result: float(result["objective"]))
        selection_label = (
            "no_accepted_trust_result_best_available_infeasible_candidate_exported"
        )
        exported_status = "unaccepted_infeasible_numerical_candidate"

    metadata = {
        "truth_label": selection_label,
        "fully_accepted_trust_result_exists": bool(accepted_trust_results),
        "accepted_trust_labels": [
            str(result["label"]) for result in accepted_trust_results
        ],
        "selected_label": str(best["label"]),
        "selected_is_accepted_trust_result": accepted_trust(best),
        "selected_trust_gate": trust_solver_acceptance(best.get("trust")),
        "selected_hard_feasible": hard_feasible(best),
        "exported_candidate_status": exported_status,
        "acceptance_definition": (
            "trust.success is true, trust optimality < 1e-5, trust constraint "
            "violation <= 1e-6, and all sampled hard constraints are feasible"
        ),
        "selection_policy": (
            "best exact gamma among accepted feasible trust results; otherwise "
            "best exact gamma among feasible numerical results; otherwise best "
            "penalized objective, always with an explicit unaccepted label"
        ),
    }
    return best, metadata


def write_checkpoint(
    path: Path,
    *,
    coordinates: jax.Array,
    phase: str,
    label: str,
    iteration: int,
    objective: float,
    temperature: float,
    config: MultiResolutionConfig,
    telemetry: AdamStepTelemetry | None = None,
    optimizer_safeguards: dict[str, object] | None = None,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        path,
        coordinates=np.asarray(coordinates),
        metadata=np.asarray(
            json.dumps(
                {
                    "phase": phase,
                    "label": label,
                    "iteration": iteration,
                    "objective": objective,
                    "temperature": temperature,
                    "objective_version": MULTIRES_OBJECTIVE_VERSION,
                    "config": asdict(config),
                    "jax_version": jax.__version__,
                    "post_update_consistent": True,
                    "optimizer_safeguards": optimizer_safeguards,
                    "optimizer_telemetry": (
                        telemetry._asdict() if telemetry is not None else None
                    ),
                }
            )
        ),
    )


def optimize_one(
    label: str,
    coordinates: np.ndarray | jax.Array,
    config: MultiResolutionConfig,
    stages: tuple[tuple[int, float], ...],
    learning_rate: float,
    args: argparse.Namespace,
    *,
    phase: str,
) -> dict[str, object]:
    initial_coordinates = np.asarray(coordinates, dtype=np.float64).copy()
    initial_coordinates /= np.linalg.norm(initial_coordinates)

    def callback(
        iteration: int,
        value: float,
        temperature: float,
        current: jax.Array,
        telemetry: AdamStepTelemetry,
    ) -> None:
        if iteration == 1 or iteration % args.report_every == 0:
            print(
                f"phase={phase} start={label} iteration={iteration} "
                f"temperature={temperature:.3e} objective={value:.9e} "
                f"step={telemetry.accepted_step:.3e} "
                f"backtracks={telemetry.backtracks} "
                f"q_margin={telemetry.minimum_initial_q_margin:.3e} "
                f"hard_infeasibility={telemetry.hard_infeasibility:.3e}",
                flush=True,
            )
        if iteration % args.checkpoint_every == 0:
            write_checkpoint(
                args.checkpoint,
                coordinates=current,
                phase=phase,
                label=label,
                iteration=iteration,
                objective=value,
                temperature=temperature,
                config=config,
                telemetry=telemetry,
                optimizer_safeguards=optimizer_safeguard_metadata(args),
            )

    result = multistage_riemannian_adam(
        coordinates,
        config,
        stages=stages,
        learning_rate=learning_rate,
        backtrack_factor=args.backtrack_factor,
        max_backtracks=args.max_backtracks,
        stage_rejection_patience=(
            None
            if args.stage_rejection_patience == 0
            else args.stage_rejection_patience
        ),
        feasibility_tolerance=args.feasibility_tolerance,
        q_active_tolerance=args.q_active_tolerance,
        q_restoration_cosine=args.q_restoration_cosine,
        q_boundary_cosine=args.q_boundary_cosine,
        q_boundary_buffer=args.q_boundary_buffer,
        callback=callback,
    )
    final_temperature = stages[-1][1]
    final_summary = summarize_multiresolution(
        result.coordinates,
        config,
        softmin_temperature=final_temperature,
    )
    final_objective = float(final_summary["objective"])
    print(
        f"phase={phase} start={label} final={final_objective:.9e} "
        f"min_gamma={float(final_summary['minimum_scoring_gamma']):.9e} "
        f"q_margin={float(final_summary['minimum_initial_q_margin']):.3e}",
        flush=True,
    )
    write_checkpoint(
        args.checkpoint,
        coordinates=result.coordinates,
        phase=phase,
        label=label,
        iteration=len(result.objective_history),
        objective=final_objective,
        temperature=final_temperature,
        config=config,
        telemetry=result.telemetry_history[-1],
        optimizer_safeguards=optimizer_safeguard_metadata(args),
    )
    return {
        "label": label,
        "phase": phase,
        "initial_coordinates": initial_coordinates,
        "coordinates": result.coordinates,
        "objective": final_objective,
        "optimization_history": result.objective_history,
        "temperature_history": result.temperature_history,
        "telemetry_history": result.telemetry_history,
        "stage_terminations": result.stage_terminations,
        "summary": final_summary,
    }


def targeted_starts(args: argparse.Namespace) -> list[tuple[str, np.ndarray]]:
    d3 = load_low_mode_candidate(args.d3)
    p3 = load_low_mode_candidate(args.p3)
    if args.smoke:
        return [("D3", d3.coordinates), ("P3", p3.coordinates)]
    d2 = load_low_mode_candidate(args.d2)
    starts: list[tuple[str, np.ndarray]] = [
        ("D3", d3.coordinates),
        ("D2", d2.coordinates),
        ("P3", p3.coordinates),
    ]
    starts.extend(
        (f"D3-perturb-{index + 1}", coordinates)
        for index, coordinates in enumerate(
            deterministic_tangent_perturbations(
                d3.coordinates,
                count=5,
                scale=args.perturbation_scale,
            )
        )
    )
    return starts


def main() -> None:
    args = parse_args()
    if args.report_every < 1 or args.checkpoint_every < 1:
        raise ValueError("report/checkpoint intervals must be positive")
    if args.smoke:
        args.dt = 0.001
        args.steps = 2
        args.block_size = 2
        args.screen_iterations = 1
        args.joint_stages = ((1, 2.0e-3),)
        args.validation_grids = ()
        args.gradient_check_directions = 1
        args.trust_iterations = 0
    campaign_provenance = build_campaign_provenance(args)
    started = perf_counter()

    if args.resume is not None:
        with np.load(args.resume) as checkpoint:
            promoted = [("resume", np.asarray(checkpoint["coordinates"]))]
        screening_results: list[dict[str, object]] = []
    else:
        starts = targeted_starts(args)
        screening_grids = (8,) if args.smoke else (16,)
        screen_config = make_config(args, screening_grids, smoke=args.smoke)
        screen_stage = ((args.screen_iterations, 2.0e-3),)
        screening_results = [
            optimize_one(
                label,
                coordinates,
                screen_config,
                screen_stage,
                args.screen_learning_rate,
                args,
                phase="screen",
            )
            for label, coordinates in starts
        ]
        ranked = sorted(
            screening_results,
            key=lambda result: float(result["objective"]),
            reverse=True,
        )
        promotion_count = 1 if args.smoke else 4
        selected = ranked[:promotion_count]
        if not args.smoke and all(result["label"] != "D3" for result in selected):
            selected[-1] = next(
                result for result in screening_results if result["label"] == "D3"
            )
        promoted = [
            (str(result["label"]), np.asarray(result["coordinates"]))
            for result in selected
        ]

    joint_grids = (8, 10) if args.smoke else (16, 20)
    joint_config = make_config(args, joint_grids, smoke=args.smoke)
    joint_results = [
        optimize_one(
            label,
            coordinates,
            joint_config,
            args.joint_stages,
            args.joint_learning_rate,
            args,
            phase="joint",
        )
        for label, coordinates in promoted
    ]
    trust_results: list[dict[str, object]] = []
    if args.trust_iterations > 0:
        if args.trust_candidates < 1:
            raise ValueError("trust-candidates must be positive when refinement is enabled")
        finalists = sorted(
            joint_results,
            key=lambda result: float(result["objective"]),
            reverse=True,
        )[: args.trust_candidates]
        for finalist in finalists:
            label = str(finalist["label"])

            def trust_callback(
                iteration: int,
                coordinates: np.ndarray,
                epigraph: float,
                state: object,
            ) -> None:
                optimality = float(getattr(state, "optimality", np.nan))
                violation = float(getattr(state, "constr_violation", np.nan))
                print(
                    f"phase=trust start={label} iteration={iteration} "
                    f"epigraph={epigraph:.9e} optimality={optimality:.3e} "
                    f"violation={violation:.3e}",
                    flush=True,
                )
                if iteration % args.checkpoint_every == 0:
                    write_checkpoint(
                        args.checkpoint,
                        coordinates=jnp.asarray(coordinates),
                        phase="trust",
                        label=label,
                        iteration=iteration,
                        objective=epigraph,
                        temperature=0.0,
                        config=joint_config,
                        optimizer_safeguards=optimizer_safeguard_metadata(args),
                    )

            trust = trust_constr_epigraph_refine(
                finalist["coordinates"],
                joint_config,
                max_iterations=args.trust_iterations,
                gtol=args.trust_gtol,
                callback=trust_callback,
            )
            trust_summary = summarize_multiresolution(
                trust.coordinates,
                joint_config,
                softmin_temperature=args.joint_stages[-1][1],
            )
            trust_results.append(
                {
                    "label": f"{label}-trust",
                    "phase": "trust",
                    "initial_coordinates": np.asarray(finalist["coordinates"]),
                    "coordinates": trust.coordinates,
                    "objective": trust_summary["objective"],
                    "optimization_history": finalist["optimization_history"],
                    "temperature_history": finalist["temperature_history"],
                    "telemetry_history": finalist["telemetry_history"],
                    "summary": trust_summary,
                    "trust": trust,
                }
            )
            print(
                f"phase=trust start={label} success={trust.success} "
                f"iterations={trust.iterations} optimality={trust.optimality:.3e} "
                f"violation={trust.constraint_violation:.3e}",
                flush=True,
            )

    candidate_results = joint_results + trust_results
    best, final_selection = select_final_candidate(candidate_results)
    best_coordinates = jnp.asarray(best["coordinates"])
    final_temperature = args.joint_stages[-1][1]
    raw = make_raw_evaluator(joint_config, final_temperature)(best_coordinates)
    final_summary = summarize_multiresolution(
        best_coordinates,
        joint_config,
        softmin_temperature=final_temperature,
    )
    gradient_checks = tangent_gradient_check(
        best_coordinates,
        joint_config,
        directions=args.gradient_check_directions,
        softmin_temperature=final_temperature,
    )

    validation_summaries: list[dict[str, object]] = []
    validation_trajectories: dict[str, np.ndarray] = {}
    validation_final_states: dict[str, np.ndarray] = {}
    duration = args.dt * args.steps
    for n in args.validation_grids:
        validation_steps = int(round(duration / args.validation_dt))
        if not np.isclose(validation_steps * args.validation_dt, duration):
            raise ValueError("validation-dt must divide the optimized time horizon")
        validation_config = make_config(
            args,
            (n,),
            dt=args.validation_dt,
            steps=validation_steps,
        )
        validation_raw = make_raw_evaluator(validation_config)(best_coordinates)
        validation_summary = summarize_multiresolution(
            best_coordinates, validation_config
        )
        validation_summary["dt"] = args.validation_dt
        validation_summary["steps"] = validation_steps
        if n == 48:
            maximum_tail = float(
                validation_summary["grids"][0]["maximum_palinstrophy_tail"]  # type: ignore[index]
            )
            validation_summary["n48_palinstrophy_tail_limit"] = 0.025
            validation_summary["n48_palinstrophy_tail_pass"] = maximum_tail <= 0.025
        validation_summaries.append(validation_summary)
        validation_trajectories[f"validation_trajectory_n{n}"] = np.asarray(
            validation_raw["trajectories"]
        )[0]
        validation_final_states[f"validation_final_state_n{n}"] = np.asarray(
            validation_raw["final_states"][0]
        )

    elapsed = perf_counter() - started

    def optimizer_metadata(result: dict[str, object]) -> dict[str, object]:
        telemetry = result["telemetry_history"]
        serialized: dict[str, object] = {
            "label": result["label"],
            "phase": result.get("phase"),
            "objective": result["objective"],
            "initial_coordinates": np.asarray(
                result.get("initial_coordinates", result["coordinates"])
            ).tolist(),
            "final_coordinates": np.asarray(result["coordinates"]).tolist(),
            "objective_history": [
                float(value) for value in result["optimization_history"]
            ],
            "temperature_history": [
                float(value) for value in result["temperature_history"]
            ],
            "telemetry_history": [item._asdict() for item in telemetry],  # type: ignore[union-attr]
            "stage_terminations": [
                item._asdict()
                for item in result.get("stage_terminations", [])  # type: ignore[union-attr]
            ],
            "final_summary": result["summary"],
            "minimum_initial_q_margin": result["summary"][  # type: ignore[index]
                "minimum_initial_q_margin"
            ],
            "rejected_steps": sum(not item.accepted for item in telemetry),  # type: ignore[union-attr]
            "minimum_accepted_step": min(
                (item.accepted_step for item in telemetry if item.accepted),  # type: ignore[union-attr]
                default=0.0,
            ),
            "maximum_backtracks": max(
                (item.backtracks for item in telemetry), default=0  # type: ignore[union-attr]
            ),
            "final_hard_infeasibility": (
                telemetry[-1].hard_infeasibility if telemetry else None  # type: ignore[union-attr]
            ),
        }
        trust = result.get("trust")
        if trust is not None:
            serialized["trust"] = {
                key: (
                    np.asarray(value).tolist()
                    if isinstance(value, (np.ndarray, jax.Array))
                    else value.item()
                    if isinstance(value, np.generic)
                    else value
                )
                for key, value in trust._asdict().items()  # type: ignore[union-attr]
            }
            serialized["trust_gate"] = trust_solver_acceptance(trust)
        return serialized

    acceptance_metadata = build_acceptance_metadata(
        joint_grid_sizes=joint_config.grid_sizes,
        optimized_gammas=np.asarray(raw["gammas"]),
        validation_summaries=validation_summaries,
        optimization_history=best["optimization_history"],
        gradient_checks=gradient_checks,
        final_summary=final_summary,
        best_result=best,
    )
    all_thresholds_pass = bool(
        acceptance_metadata["acceptance"][  # type: ignore[index]
            "all_available_plan_thresholds_pass"
        ]
        is True
    )
    selected_accepted = bool(
        final_selection["selected_is_accepted_trust_result"]
        and all_thresholds_pass
    )
    final_selection["all_declared_plan_thresholds_pass"] = all_thresholds_pass
    final_selection["export_implies_campaign_acceptance"] = selected_accepted
    final_selection["campaign_truth_label"] = (
        "accepted_numerical_campaign_candidate"
        if selected_accepted
        else "numerical_candidate_exported_without_full_campaign_acceptance"
    )
    metadata = {
        "objective_version": MULTIRES_OBJECTIVE_VERSION,
        "campaign_truth_label": final_selection["campaign_truth_label"],
        "best_start": best["label"],
        "elapsed_seconds": elapsed,
        "provenance": campaign_provenance,
        "final_selection": final_selection,
        "joint_config": asdict(joint_config),
        "joint_stages": args.joint_stages,
        "initial_bottleneck_constraint": {
            "delta": joint_config.delta,
            "q_floor": joint_config.initial_q_floor,
            "normalized_penalty_weight": joint_config.initial_q_penalty,
            "implied_zeta_floor": final_summary["initial_zeta_floor"],
            "formula": "q_delta(0)=E'(0)/E(0)^(2+delta) >= q_floor",
            "provenance": initial_q_floor_provenance(joint_config),
        },
        "optimizer_safeguards": optimizer_safeguard_metadata(args),
        "jax_version": jax.__version__,
        "final_summary": final_summary,
        "gradient_checks": gradient_checks,
        "acceptance_metrics": acceptance_metadata,
        "validation": validation_summaries,
        "screening": [optimizer_metadata(result) for result in screening_results],
        "joint_starts": [optimizer_metadata(result) for result in joint_results],
        "trust_refinements": [
            optimizer_metadata(result) for result in trust_results
        ],
    }

    control = LowModeControl(np.asarray(best_coordinates), args.enstrophy)
    control.save(args.output, metadata=metadata)
    args.archive.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        args.archive,
        coordinates=np.asarray(best_coordinates),
        trajectories=np.asarray(raw["trajectories"]),
        gammas=np.asarray(raw["gammas"]),
        unfloored_gammas=np.asarray(raw["unfloored_gammas"]),
        crossing_times=np.asarray(raw["crossing_times"]),
        initial_q_values=np.asarray(raw["initial_q_values"]),
        initial_q_margins=np.asarray(raw["initial_q_margins"]),
        endpoint_equalities=np.asarray(raw["endpoint_equalities"]),
        inequality_constraints=np.asarray(raw["inequality_constraints"]),
        optimization_history=np.asarray(best["optimization_history"]),
        temperature_history=np.asarray(best["temperature_history"]),
        accepted_step_history=np.asarray(
            [item.accepted_step for item in best["telemetry_history"]]
        ),
        hard_infeasibility_history=np.asarray(
            [item.hard_infeasibility for item in best["telemetry_history"]]
        ),
        initial_q_margin_history=np.asarray(
            [item.minimum_initial_q_margin for item in best["telemetry_history"]]
        ),
        metadata=np.asarray(json.dumps(metadata)),
        **{
            f"final_state_n{n}": np.asarray(state)
            for n, state in zip(
                joint_config.grid_sizes, raw["final_states"], strict=True
            )
        },
        **validation_trajectories,
        **validation_final_states,
    )
    args.summary.parent.mkdir(parents=True, exist_ok=True)
    args.summary.write_text(json.dumps(metadata, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(metadata, indent=2), flush=True)


if __name__ == "__main__":
    main()
