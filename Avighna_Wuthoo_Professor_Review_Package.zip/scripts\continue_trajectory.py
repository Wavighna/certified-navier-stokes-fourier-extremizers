"""Continue a saved refinement trajectory without replaying its prefix."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import jax.numpy as jnp
import numpy as np

from extreme_flows.search import DIAGNOSTIC_NAMES, SearchConfig, trajectory_diagnostics
from extreme_flows.spectral import SpectralGrid


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--steps", type=int, required=True)
    args = parser.parse_args()

    archive = np.load(args.input)
    metadata = json.loads(str(archive["metadata"].item()))
    if "final_state" not in archive.files:
        raise ValueError("input archive must contain final_state")
    state = jnp.asarray(archive["final_state"])
    n = int(state.shape[0])
    dt = float(metadata["dt"])
    viscosity = float(metadata["viscosity"])
    grid = SpectralGrid(n)
    config = SearchConfig(
        viscosity=viscosity,
        dt=dt,
        steps=args.steps,
        initial_max_mode=None,
    )
    final_state, extension = trajectory_diagnostics(state, grid, config)
    old_history = archive["trajectory"]
    history = np.concatenate((old_history, np.asarray(extension)[1:]), axis=0)
    continued_metadata = {
        **metadata,
        "continued_from": str(args.input),
        "prefix_steps": int(old_history.shape[0] - 1),
        "additional_steps": args.steps,
        "steps": int(old_history.shape[0] - 1 + args.steps),
        "diagnostic_names": DIAGNOSTIC_NAMES,
        "artifact_schema_version": 2,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        args.output,
        state=archive["state"],
        final_state=np.asarray(final_state),
        trajectory=history,
        metadata=np.asarray(json.dumps(continued_metadata)),
    )

    enstrophy = history[:, 1]
    rate = history[:, 2]
    q = rate / enstrophy**2.1
    target_indices = np.flatnonzero(enstrophy >= 2.0 * enstrophy[0])
    print(
        json.dumps(
            {
                "output": str(args.output),
                "time_final": float((history.shape[0] - 1) * dt),
                "enstrophy_final": float(enstrophy[-1]),
                "persistence_margin_min": float(q.min()),
                "palinstrophy_tail_max": float(history[:, 10].max()),
                "first_double_time_grid": (
                    None
                    if target_indices.size == 0
                    else float(target_indices[0] * dt)
                ),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
