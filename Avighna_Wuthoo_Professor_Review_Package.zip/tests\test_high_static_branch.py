"""Regression guards for the certified competing full-space static branch."""

from __future__ import annotations

import json
from pathlib import Path

from extreme_flows.certify import StaticLowModePolynomial


ROOT = Path(__file__).resolve().parents[1]


def test_high_branch_artifact_has_two_separate_interval_precision_runs() -> None:
    payload = json.loads(
        (ROOT / "artifacts/proofs/high_branch_eta10000_arb_certificate.json").read_text(
            encoding="utf-8"
        )
    )
    assert payload["truth_label"] == (
        "proved_strict_local_static_maximum_high_branch_modulo_translations"
    )
    assert payload["claims"]["strict_local_maximum_modulo_translations"]
    assert payload["claims"]["exact_two_amplitude_formula_is_the_certified_full_kkt_root"]
    assert payload["claims"]["strictly_beats_six_amplitude_ansatz"]
    assert not payload["claims"]["global_maximum"]
    assert [run["precision_bits"] for run in payload["arb"]["runs"]] == [256, 512]
    for run in payload["arb"]["runs"]:
        assert run["krawczyk_verified"]
        assert run["phase_chart_regular"]
        assert run["exact_two_amplitude_formula_inside_unique_krawczyk_box"]
        assert run["bordered_inertia"] == {
            **run["bordered_inertia"],
            "verified": True,
            "positive": 4,
            "negative": 64,
            "zero_or_unresolved": 0,
        }


def test_alternative_phase_polarizations_select_the_expected_imaginary_modes() -> None:
    model = StaticLowModePolynomial(phase_polarizations=(0, 1, 0))
    # Control layout per wave is Re(p1), Re(p2), Im(p1), Im(p2).
    assert model.phase_indices == (42, 15, 2)
