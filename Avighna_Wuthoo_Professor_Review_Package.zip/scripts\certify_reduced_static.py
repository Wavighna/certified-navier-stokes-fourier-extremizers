"""Certify the six-amplitude static local maximum with Arb."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from extreme_flows.reduced_static_certificate import build_reduced_static_certificate


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "candidate",
        nargs="?",
        default="artifacts/proofs/static_adaptive_kkt_candidate.json",
    )
    parser.add_argument(
        "--output",
        default="artifacts/proofs/reduced_static_arb_certificate.json",
    )
    parser.add_argument("--precisions", nargs="+", type=int, default=(256, 512))
    args = parser.parse_args()
    payload = build_reduced_static_certificate(
        args.candidate, precisions=args.precisions
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output}")
    print(f"truth label: {payload['truth_label']}")
    if not payload["claims"]["strict_local_maximum_within_six_amplitude_ansatz"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
