"""Re-execute the Paper A verifier from a clean temporary source tree.

This is a packaging and hidden-dependency audit.  It deliberately does not
claim independent software or mathematical review: it uses the same Python
environment and checker code, copied into a fresh temporary directory.
"""

from __future__ import annotations

import argparse
from hashlib import sha256
import json
from pathlib import Path
import os
import shutil
import subprocess
import sys
import tempfile


ROOT = Path(__file__).resolve().parents[1]
COPY_ITEMS = ("pyproject.toml", "paper", "src", "scripts", "artifacts/proofs")


def _record(path: Path) -> dict[str, object]:
    data = path.read_bytes()
    return {
        "path": path.relative_to(ROOT).as_posix(),
        "size_bytes": len(data),
        "sha256": sha256(data).hexdigest(),
    }


def _copy_release_tree(destination: Path) -> None:
    for relative in COPY_ITEMS:
        source = ROOT / relative
        target = destination / relative
        if source.is_dir():
            shutil.copytree(
                source,
                target,
                ignore=shutil.ignore_patterns("__pycache__", "*.pyc", ".git"),
            )
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)


def audit() -> dict[str, object]:
    """Copy the declared tree and rerun verifier plus release-manifest builder."""

    with tempfile.TemporaryDirectory(prefix="paper-a-clean-") as temporary:
        clean_root = Path(temporary) / "release"
        _copy_release_tree(clean_root)
        environment = os.environ.copy()
        environment["PYTHONPATH"] = str(clean_root / "src")
        verifier = subprocess.run(
            [sys.executable, "scripts/verify_paper_a.py"],
            cwd=clean_root,
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )
        manifest = subprocess.run(
            [sys.executable, "scripts/build_paper_a_manifest.py"],
            cwd=clean_root,
            env=environment,
            text=True,
            capture_output=True,
            check=False,
        )
        record_path = clean_root / "artifacts/proofs/paper_a_verification.json"
        claims: dict[str, object] | None = None
        if record_path.is_file():
            claims = json.loads(record_path.read_text(encoding="utf-8"))["claims"]
        positive = (
            claims is not None
            and all(
                bool(value)
                for key, value in claims.items()
                if key
                not in {
                    "full_64d_global_maximum",
                    "navier_stokes_regularity_or_blowup_statement",
                }
            )
        )
        negative = (
            claims is not None
            and not claims["full_64d_global_maximum"]
            and not claims["navier_stokes_regularity_or_blowup_statement"]
        )
        passed = verifier.returncode == 0 and manifest.returncode == 0 and positive and negative
        return {
            "schema_version": 1,
            "truth_label": (
                "clean_tree_same_environment_paper_a_verification_passed"
                if passed
                else "clean_tree_same_environment_paper_a_verification_failed"
            ),
            "scope": (
                "Copies source, paper, scripts, and proof inputs into a fresh temporary "
                "directory and reruns the verifier in the same Python environment."
            ),
            "limitations": {
                "independent_human_audit_completed": False,
                "independent_software_implementation_audit_completed": False,
                "same_python_environment_used": True,
            },
            "copied_items": list(COPY_ITEMS),
            "verifier_returncode": verifier.returncode,
            "manifest_returncode": manifest.returncode,
            "verification_claims": claims,
            "verifier_stdout_tail": verifier.stdout[-4000:],
            "verifier_stderr_tail": verifier.stderr[-4000:],
            "manifest_stdout_tail": manifest.stdout[-1000:],
            "manifest_stderr_tail": manifest.stderr[-1000:],
            "checker_source": _record(Path(__file__).resolve()),
        }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="artifacts/proofs/paper_a_clean_tree_audit.json")
    args = parser.parse_args()
    payload = audit()
    output = ROOT / args.output
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(payload["truth_label"])
    if payload["truth_label"] != "clean_tree_same_environment_paper_a_verification_passed":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
