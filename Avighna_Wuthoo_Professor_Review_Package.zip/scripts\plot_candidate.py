"""Render orthogonal slices and spectra of a saved extreme-flow candidate."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import jax.numpy as jnp
import matplotlib.pyplot as plt
import numpy as np

from extreme_flows.spectral import (
    SpectralGrid,
    curl_hat,
    diagnostics,
    gradient_physical,
    ifft_velocity,
    strain_alignment_diagnostics,
)


def _slice(field: np.ndarray, axis: int, index: int) -> np.ndarray:
    return np.take(field, index, axis=axis).T


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--initial", action="store_true")
    parser.add_argument("--viscosity", type=float, default=0.01)
    args = parser.parse_args()

    archive = np.load(args.input)
    key = "state" if args.initial or "final_state" not in archive.files else "final_state"
    state = jnp.asarray(archive[key])
    grid = SpectralGrid(int(state.shape[0]))
    omega_hat = curl_hat(state, grid)
    omega = np.asarray(ifft_velocity(omega_hat))
    omega_magnitude = np.sqrt(np.sum(omega * omega, axis=-1))
    grad_u = np.asarray(gradient_physical(state, grid))
    strain = 0.5 * (grad_u + np.swapaxes(grad_u, -1, -2))
    stretching = np.einsum("...i,...ij,...j->...", omega, strain, omega)
    peak = np.unravel_index(np.argmax(omega_magnitude), omega_magnitude.shape)

    extent = (0.0, grid.length, 0.0, grid.length)
    fig, axes = plt.subplots(2, 3, figsize=(13, 8.4), constrained_layout=True)
    plane_names = ("yz", "xz", "xy")
    for axis, plane in enumerate(plane_names):
        magnitude_slice = _slice(omega_magnitude, axis, peak[axis])
        stretch_slice = _slice(stretching, axis, peak[axis])
        image = axes[0, axis].imshow(
            magnitude_slice,
            origin="lower",
            extent=extent,
            cmap="magma",
            interpolation="nearest",
        )
        fig.colorbar(image, ax=axes[0, axis], shrink=0.82)
        axes[0, axis].set_title(
            rf"$|\omega|$, {plane} at index {peak[axis]}"
        )
        limit = np.percentile(abs(stretch_slice), 99.5)
        image = axes[1, axis].imshow(
            stretch_slice,
            origin="lower",
            extent=extent,
            cmap="coolwarm",
            vmin=-limit,
            vmax=limit,
            interpolation="nearest",
        )
        fig.colorbar(image, ax=axes[1, axis], shrink=0.82)
        axes[1, axis].set_title(rf"$\omega\cdot S\omega$, {plane}")
        for row in range(2):
            axes[row, axis].set_xlabel("coordinate")
            axes[row, axis].set_ylabel("coordinate")
    fig.suptitle(f"{args.input.name}: {key}, N={grid.n}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(args.output, dpi=180)

    diag = diagnostics(state, grid, args.viscosity)
    alignment = strain_alignment_diagnostics(state, grid)
    summary = {
        "input": str(args.input),
        "state_key": key,
        "n": grid.n,
        "peak_index": tuple(int(i) for i in peak),
        "peak_coordinate": tuple(float(i * grid.length / grid.n) for i in peak),
        "peak_vorticity": float(omega_magnitude[peak]),
        "diagnostics": {name: float(value) for name, value in diag.items()},
        "stretching_contributions": np.asarray(
            alignment["stretching_contributions"]
        ).tolist(),
        "vorticity_alignment_fractions": np.asarray(
            alignment["vorticity_alignment_fractions"]
        ).tolist(),
    }
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
