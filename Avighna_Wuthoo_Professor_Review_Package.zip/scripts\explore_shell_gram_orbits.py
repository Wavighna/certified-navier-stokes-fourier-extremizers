"""Report exact symmetry-orbit sizes for shellwise quartic Gram searches.

This is reconnaissance only.  It makes no positivity claim and writes no
certificate.  The purpose is to determine whether a symmetry-adapted exact
SOS search is tractable before allocating a dense SDP.
"""

from __future__ import annotations

from itertools import combinations_with_replacement

from extreme_flows.certify import StaticLowModePolynomial
from extreme_flows.shellwise_bounds import _shell_indices
from extreme_flows.static_symmetry import (
    IDENTITY_GENERATOR,
    signed_coordinate_matrices,
    static_symmetry_matrix,
)


def signed_gram_orbit_summary(shell: int) -> dict[str, int]:
    """Count signed invariant Gram-entry orbits for a shell's quadratic basis."""

    model = StaticLowModePolynomial()
    coordinates = _shell_indices(model, shell)
    coordinate_position = {coordinate: index for index, coordinate in enumerate(coordinates)}
    monomials = tuple(combinations_with_replacement(range(len(coordinates)), 2))
    monomial_position = {monomial: index for index, monomial in enumerate(monomials)}

    def induced_action(generator):
        destination = []
        signs = []
        for column in coordinates:
            rows = [row for row in coordinates if generator[row][column]]
            if len(rows) != 1:
                raise ArithmeticError("shell action is not signed-permutational")
            destination.append(coordinate_position[rows[0]])
            signs.append(int(generator[rows[0]][column]))
        inverse = [0] * len(coordinates)
        output_sign = [0] * len(coordinates)
        for source, target in enumerate(destination):
            inverse[target] = source
            output_sign[target] = signs[source]
        return (
            tuple(
                monomial_position[tuple(sorted((inverse[first], inverse[second])))]
                for first, second in monomials
            ),
            tuple(output_sign[first] * output_sign[second] for first, second in monomials),
        )

    actions = [
        induced_action(static_symmetry_matrix((IDENTITY_GENERATOR[0], shift)))
        for shift in ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    ]
    actions.extend(
        induced_action(static_symmetry_matrix((matrix, (0, 0, 0))))
        for matrix in signed_coordinate_matrices()
    )
    size = len(monomials)
    entries = tuple((first, second) for first in range(size) for second in range(first, size))
    entry_position = {entry: index for index, entry in enumerate(entries)}
    parent = list(range(len(entries)))
    sign_to_parent = [1] * len(entries)
    forced_zero = [False] * len(entries)

    def find(index: int):
        if parent[index] == index:
            return index, 1
        direct = parent[index]
        root, inherited = find(direct)
        sign_to_parent[index] *= inherited
        parent[index] = root
        return root, sign_to_parent[index]

    def union(left: int, right: int, relation: int) -> None:
        left_root, left_sign = find(left)
        right_root, right_sign = find(right)
        if left_root == right_root:
            if left_sign != relation * right_sign:
                forced_zero[left_root] = True
            return
        parent[left_root] = right_root
        sign_to_parent[left_root] = relation * right_sign * left_sign
        forced_zero[right_root] = forced_zero[right_root] or forced_zero[left_root]

    for destination, signs in actions:
        for item, (first, second) in enumerate(entries):
            target = entry_position[tuple(sorted((destination[first], destination[second])))]
            union(target, item, signs[first] * signs[second])
    roots = [find(item)[0] for item in range(len(entries))]
    root_set = set(roots)
    return {
        "shell_dimension": len(coordinates),
        "degree_two_basis": size,
        "symmetric_gram_entries": len(entries),
        "all_orbits": len(root_set),
        "forced_zero_orbits": sum(forced_zero[root] for root in root_set),
        "free_signed_orbits": sum(not forced_zero[root] for root in root_set),
    }


def main() -> None:
    # Shells one and two are signed-permutational in the chosen canonical
    # polarization coordinates.  Shell three is invariant geometrically but
    # its two polarizations mix under some cube rotations, so it needs a
    # representation-basis reduction rather than this signed-orbit shortcut.
    for shell in (1, 2):
        print(shell, signed_gram_orbit_summary(shell))


if __name__ == "__main__":
    main()
