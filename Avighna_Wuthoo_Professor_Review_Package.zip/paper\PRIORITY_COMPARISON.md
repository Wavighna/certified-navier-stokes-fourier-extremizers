# Claim-level priority comparison

Updated: 2026-08-12. This is a submission-preparation aid, not a claim of
exclusive priority. It records what has been checked from public abstracts and
what still requires full-text/database review.

## Present paper's limited contribution

The paper concerns a **static**, fixed-enstrophy rate functional in one stated
finite Fourier class: 16 independent wave pairs and 64 real divergence-free
coordinates on the periodic cube. Its specific contributions are:

1. two exact common-fixed spaces for explicit lattice symmetries;
2. the exact competing-plane formulas
   \(A=24a^2b\), \(E=3a^2+48b^2\), and \(P=3a^2+96b^2\);
3. the resulting closed branch
   \(b=(\sqrt{E+\nu^2}-\nu)/12\) and its exact full-coordinate KKT
   identity;
4. a rigorous strict-local-maximality theorem modulo translations for this
   branch for every positive \(E,\nu\), proved by joined cancellation-exact
   low-parameter and direct high-parameter interval covers;
5. a crossover only between this branch and a separately characterized
   six-amplitude symmetry branch.

No full Fourier-space global maximizer, continuum variational theorem, or
Navier--Stokes regularity statement is claimed.

## Direct comparisons from public abstracts

| Work | Object stated by source | Relation to this paper | Priority-safe wording |
|---|---|---|---|
| Lu--Doering (2008) | Classical fixed-enstrophy instantaneous-production problem and its sharp growth-bound context; its Fourier-coefficient formulation is solved numerically by constrained-gradient methods. | Core prior art for both the broad optimization problem and its Fourier computational treatment. | Cite as foundational; do not claim the problem, Fourier formulation, or cubic scaling. The proposed contribution is an explicit finite branch plus a rigorous local certificate. |
| Ayala--Protas (2017), [arXiv:1605.05742](https://arxiv.org/abs/1605.05742) | Full PDE fields of prescribed enstrophy maximizing instantaneous production; analytic characterization in the vanishing-enstrophy limit, where Taylor--Green is locally maximizing; finite-enstrophy states computed numerically. | Closest published prior art in objective, but its abstract does not state an exact finite 16-pair reduction, a closed two-amplitude branch, or a computer-assisted uniform finite-parameter local theorem. | State that the present work gives a finite-Fourier, computer-assisted complement to the full-PDE numerical study. |
| Kang--Yun--Protas (2020), [arXiv:1909.00041](https://arxiv.org/abs/1909.00041) | PDE optimization of enstrophy at a prescribed terminal time, solved by a continuous adjoint method. | Different objective and time-dependent PDE setting. | Cite for terminal-enstrophy extreme flows, not as a direct antecedent of the static KKT certificate. |
| Miller (2025 version), [arXiv:2307.03434](https://arxiv.org/abs/2307.03434) | Fourier-restricted Euler and hypodissipative Navier--Stokes **model equations** with the Helmholtz projection replaced by a more restrictive dyadic constraint-space projection. | Nearby in its use of Fourier restrictions and symmetry, but it does not use the true Navier--Stokes projection or solve the present static fixed-enstrophy variational problem. | Cite to distinguish the models; do not transfer its blow-up results or terminology to the present finite true-projection calculation. |
| Kiriukhin (2026), [arXiv:2603.23293](https://arxiv.org/abs/2603.23293) and [arXiv:2604.12188](https://arxiv.org/abs/2604.12188) | Cubic Fourier--Galerkin truncation reduced by full octahedral symmetry; respectively orbit-transfer matrices, incidence/spectral/ensemble bounds, and a continuation criterion; or orbit-level transfer matrices, triad incidences, and row-sum estimates. | Closest current Fourier--symmetry vocabulary, but their stated objects are not the fixed-enstrophy static 64-variable KKT problem or a local-extremizer branch. | Cite both explicitly and say the methods/claims differ; do not assert priority beyond the stated finite result. |

## Review required before submission

The comparison with Kang--Yun--Protas remains **abstract-level**. Miller v5
was additionally screened in its arXiv HTML full text on 2026-08-12: it
defines a different equation by replacing the Helmholtz projector with a
projection onto a dyadic constraint space (and one polarization per selected
frequency), then proves model-equation blowup. It therefore does not supply a
prior true-projection finite 16-pair static KKT certificate, but it remains
important nearby Fourier/symmetry prior art. Kiriukhin's March preprint was additionally
screened in its
arXiv HTML full text on 2026-08-12: its stated results concern the
$O_h$-orbit transfer matrix, triad incidence, ensemble bounds, and an
orbit-level continuation criterion. That screen did not identify a
fixed-enstrophy static KKT optimization, the present two-amplitude formula, or
an interval-certified local-extremizer branch. The later April preprint was
screened at the abstract level and has the same documented distinction. This
is still not a claim of
non-overlap under every terminology or a substitute for expert review.

Before submission, a human author/reviewer must inspect the remaining full
texts and
the reference lists, then search MathSciNet, zbMATH Open, and Web of Science
or Scopus for:

- `instantaneous enstrophy production` + `Fourier truncation`;
- `enstrophy extremizer` + `symmetric criticality`;
- `interval arithmetic` or `computer-assisted` + `Navier--Stokes` +
  `enstrophy`;
- the exact physical field and the two-shell/nonhelical descriptors.

Each close result needs an entry stating whether it contains the same finite
class, static objective, exact branch formula, or rigorous uniform local
certificate. If it does, priority wording must be narrowed before submission.
