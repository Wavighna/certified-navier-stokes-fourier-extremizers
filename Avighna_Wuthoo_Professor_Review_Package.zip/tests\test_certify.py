from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path

import numpy as np
import pytest

from extreme_flows.certify import (
    StaticLowModePolynomial,
    ADAPTIVE_PHASE_WAVES,
    build_adaptive_static_certificate,
    build_onset_certificate,
    derive_onset_algebra,
    enstrophy,
    evaluate_onset_arb,
    exact_controls_from_datum,
    evaluate_adaptive_static_certificate_arb,
    load_exactified_candidate,
    negate_wave,
)


CANDIDATE = "artifacts/candidates/persistent_v3_low_modes.json"


@pytest.mark.parametrize(
    "builder",
    (build_onset_certificate, build_adaptive_static_certificate),
)
def test_proof_builders_require_256_and_512_bits(builder) -> None:
    with pytest.raises(ValueError, match="256-bit and 512-bit"):
        builder("unused-because-validation-runs-first.json", precisions=(256,))
    with pytest.raises(ValueError, match="256-bit and 512-bit"):
        builder(
            "unused-because-validation-runs-first.json",
            precisions=(256, 384),
        )


@pytest.mark.parametrize(
    "artifact",
    (
        "artifacts/proofs/p3_onset_certificate.json",
        "artifacts/proofs/static_adaptive_arb_certificate.json",
    ),
)
def test_archived_checker_source_hashes_are_current(artifact: str) -> None:
    payload = json.loads(Path(artifact).read_text(encoding="utf-8"))
    for record in payload["checker_source"].values():
        source = Path(record["path"])
        data = source.read_bytes()
        assert record["size_bytes"] == len(data)
        assert record["sha256"] == sha256(data).hexdigest()


def test_exactification_is_rational_divergence_free_and_conjugate():
    datum = load_exactified_candidate(CANDIDATE)

    assert len(datum.field) == 32
    for wave, coefficient in datum.field.items():
        divergence = sum(
            (wave[index] * coefficient[index] for index in range(3)),
            start=coefficient[0] * 0,
        )
        assert divergence.is_zero()
        assert datum.field[negate_wave(wave)] == tuple(
            value.conjugate() for value in coefficient
        )

    algebra = derive_onset_algebra(datum)
    assert algebra.scale_squared * enstrophy(datum.field) == Fraction(100)
    assert algebra.nonlinear_support == 164
    assert algebra.second_derivative_support == 532


def test_arb_certifies_the_p3_onset_derivative():
    pytest.importorskip("flint")
    algebra = derive_onset_algebra(load_exactified_candidate(CANDIDATE))
    run = evaluate_onset_arb(algebra, precision=256)

    assert run["qprime_strictly_positive"]
    assert np.isclose(float(run["q0"].mid()), 0.013828980388103784, rtol=0, atol=1e-16)
    assert np.isclose(float(run["qprime0"].mid()), 0.08011446806814874, rtol=0, atol=1e-16)
    assert run["q0"].rad() < run["q0"].mid() / 10**50
    assert run["qprime0"].rad() < run["qprime0"].mid() / 10**50


def test_static_integer_basis_round_trip_and_polynomial_derivatives():
    model = StaticLowModePolynomial()
    datum = load_exactified_candidate(CANDIDATE)
    exact_controls = exact_controls_from_datum(model, datum)
    exact = model.exact_invariants(exact_controls)
    numeric_controls = np.asarray([float(value) for value in exact_controls])
    numeric = model.evaluate(numeric_controls)

    assert len(model.pairs) == 16
    assert model.dimension == 64
    assert len(model.third_derivative_terms) == 512
    for name in ("enstrophy", "palinstrophy", "stretching", "rate"):
        assert np.isclose(float(exact[name]), float(numeric[name]), rtol=2e-15)

    direction = np.cos(np.arange(model.dimension, dtype=float))
    direction /= np.linalg.norm(direction)
    step = 1e-5
    plus = float(model.evaluate(numeric_controls + step * direction)["rate"])
    minus = float(model.evaluate(numeric_controls - step * direction)["rate"])
    finite_difference = (plus - minus) / (2 * step)
    directional_derivative = float(
        np.dot(np.asarray(numeric["gradient_rate"]), direction)
    )
    assert np.isclose(finite_difference, directional_derivative, rtol=2e-9, atol=2e-9)

    jacobian = model.constraint_jacobian(numeric_controls)
    multipliers = np.linalg.lstsq(
        jacobian.T, np.asarray(numeric["gradient_rate"]), rcond=None
    )[0]
    point = np.concatenate((numeric_controls, multipliers))
    assert model.kkt_system(point).shape == (68,)
    assert model.kkt_jacobian(point).shape == (68, 68)


def test_adaptive_chart_arb_krawczyk_and_bordered_inertia():
    pytest.importorskip("flint")
    with open(
        "artifacts/proofs/static_adaptive_kkt_candidate.json",
        encoding="utf-8",
    ) as stream:
        candidate = json.load(stream)

    assert tuple(tuple(wave) for wave in candidate["model"]["phase_waves"]) == (
        ADAPTIVE_PHASE_WAVES
    )
    run = evaluate_adaptive_static_certificate_arb(candidate, precision=128)

    assert run["krawczyk_verified"]
    assert run["existence_verified"]
    assert run["uniqueness_verified"]
    assert run["preconditioner_nonsingular"]
    assert run["interval_jacobian_regular"]
    assert run["adaptive_chart_regular"]
    assert run["selected_attempt"]["max_image_to_box_radius_ratio"] < 1e-4
    assert run["bordered_inertia"]["verified"]
    assert run["bordered_inertia"]["positive"] == 4
    assert run["bordered_inertia"]["negative"] == 64
    assert run["bordered_inertia"]["zero_or_unresolved"] == 0
    assert run["bordered_inertia"]["bordered_hessian_nonsingular"]
    assert run["bordered_inertia"]["constraint_jacobian_full_row_rank"]
