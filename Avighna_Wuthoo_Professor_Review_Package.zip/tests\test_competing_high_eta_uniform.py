"""Truth-label guards for the uniform high-eta interval certificate."""

from __future__ import annotations

import json
from hashlib import sha256
from pathlib import Path


def test_uniform_high_eta_certificate_has_complete_two_precision_cover() -> None:
    payload = json.loads(
        Path("artifacts/proofs/competing_high_eta_uniform.json").read_text(encoding="utf-8")
    )
    assert payload["truth_label"] == "proved_uniform_high_eta_competing_full_space_local_maximum"
    assert payload["claims"]["strict_full_space_local_maximum_modulo_translations_for_all_eta_ge_100"]
    assert not payload["claims"]["full_space_global_maximum"]
    assert not payload["claims"]["navier_stokes_regularity_or_blowup_statement"]
    assert payload["normalization_and_cover"]["interval_count"] == 238
    assert payload["normalization_and_cover"]["rational_s_cover"] == ["9049/10000", "1"]
    assert payload["normalization_and_cover"]["squared_positive_side_difference"] == "17599/100000000"
    assert [run["precision_bits"] for run in payload["arb"]["runs"]] == [256, 512]
    for run in payload["arb"]["runs"]:
        assert run["all_intervals_certified"]
        assert run["certified_intervals"] == run["total_intervals"] == 238
        assert not run["failures"]
    for record_name in ("checker_source", "formula_source", "polynomial_source"):
        record = payload[record_name]
        path = Path(record["path"])
        assert record["sha256"] == sha256(path.read_bytes()).hexdigest()
