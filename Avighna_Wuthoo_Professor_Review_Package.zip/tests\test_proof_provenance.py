"""Ensure archived Paper A proof records name the exact checker sources used."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Iterator


ROOT = Path(__file__).resolve().parents[1]
PROOF_DIR = ROOT / "artifacts" / "proofs"


def _source_records(value: object) -> Iterator[dict[str, object]]:
    """Yield nested source records that are expected to be workspace files."""

    if isinstance(value, dict):
        if (
            isinstance(value.get("path"), str)
            and isinstance(value.get("sha256"), str)
            and value["path"].replace("\\", "/").startswith(("src/", "scripts/"))
        ):
            yield value
        for child in value.values():
            yield from _source_records(child)
    elif isinstance(value, list):
        for child in value:
            yield from _source_records(child)


def test_paper_a_artifact_source_hashes_match_workspace() -> None:
    """A changed proof source requires a certificate rebuild, never relabeling."""

    artifacts = (
        "reduced_competing_formula.json",
        "competing_standalone_algebra_audit.json",
        "reduced_static_standalone_algebra_audit.json",
        "high_branch_eta10000_arb_certificate.json",
        "competing_branch_stability_sweep.json",
        "competing_high_eta_uniform.json",
        "competing_all_eta_uniform.json",
        "symmetry_branch_crossover.json",
        "competing_hessian_spectral_blocks.json",
        "competing_all_eta_symbolic_continuation.json",
        "paper_a_verification.json",
    )
    record_count = 0
    for name in artifacts:
        payload = json.loads((PROOF_DIR / name).read_text(encoding="utf-8"))
        records = list(_source_records(payload))
        assert records, f"{name} records no checker source hashes"
        for record in records:
            path = ROOT / str(record["path"])
            assert path.is_file(), f"missing recorded source {path} from {name}"
            actual = hashlib.sha256(path.read_bytes()).hexdigest()
            assert actual == record["sha256"], f"stale source hash in {name}: {path}"
            record_count += 1
    assert record_count >= 12
