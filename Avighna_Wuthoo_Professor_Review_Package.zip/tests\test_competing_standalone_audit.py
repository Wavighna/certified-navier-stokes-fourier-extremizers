from scripts.audit_competing_standalone import (
    EXPECTED,
    PHYSICAL_SPACE_FORMULA,
    audit,
    invariants,
    polynomial_coefficients,
)


def test_standalone_rational_audit_recovers_all_competing_coefficients() -> None:
    assert polynomial_coefficients() == EXPECTED
    assert invariants(1, 1)["helicity"] == 0
    payload = audit()
    assert payload["mode_count"] == 18
    assert payload["all_coefficients_match"]
    assert "does not import extreme_flows" in payload["independence_statement"]
    assert payload["physical_space_formula"] == PHYSICAL_SPACE_FORMULA
