"""Write the exact polynomial target for the full-64 inviscid SOS program."""

from __future__ import annotations

import json
from pathlib import Path

from extreme_flows.inviscid_sos_target import (
    inviscid_target_metadata,
    translation_sos_basis_structure,
)


def main() -> None:
    output = Path("artifacts/raw/inviscid_full64_sos_target.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = inviscid_target_metadata()
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output}")
    print(f"degree-six monomials={payload['degree_six_target_monomial_count']}")
    symmetry_output = Path("artifacts/raw/inviscid_full64_sos_translation_structure.json")
    symmetry_output.write_text(
        json.dumps(translation_sos_basis_structure(), indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"wrote {symmetry_output}")


if __name__ == "__main__":
    main()
