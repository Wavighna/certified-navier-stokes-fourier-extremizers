"""Truth-label guards for the finite interval-certified stability sweep."""

from __future__ import annotations

import json
from hashlib import sha256
from pathlib import Path


def test_competing_branch_stability_sweep_is_explicitly_finite() -> None:
    path = Path("artifacts/proofs/competing_branch_stability_sweep.json")
    payload = json.loads(path.read_text(encoding="utf-8"))
    assert payload["claims"]["all_listed_points_certified"]
    assert not payload["claims"]["parameter_uniform_full_space_local_maximum"]
    assert not payload["claims"]["full_space_global_maximum"]
    assert payload["dependency"]["python_flint"] == "0.9.0"
    for record in payload["checker_source"].values():
        path = Path(record["path"])
        assert record["sha256"] == sha256(path.read_bytes()).hexdigest()
    assert [entry["eta"] for entry in payload["entries"]] == [
        "100", "400", "2500", "10000", "40000"
    ]
    for entry in payload["entries"]:
        assert entry["strict_local_maximum_certified_at_both_precisions"]
        assert [run["precision_bits"] for run in entry["runs"]] == [256, 512]
        assert all(run["verified"] for run in entry["runs"])
