"""Refine a saved spectral initial state and rerun its trajectory."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import jax.numpy as jnp
import numpy as np

from extreme_flows.search import (
    DIAGNOSTIC_NAMES,
    SearchConfig,
    spectral_enstrophy,
    trajectory_diagnostics,
)
from extreme_flows.spectral import SpectralGrid, resample_state


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--n", type=int, required=True)
    parser.add_argument("--viscosity", type=float, default=0.01)
    parser.add_argument("--dt", type=float, default=0.001)
    parser.add_argument("--steps", type=int, default=200)
    parser.add_argument("--target-enstrophy", type=float)
    args = parser.parse_args()

    source = np.load(args.input)
    coarse_state = jnp.asarray(source["state"])
    coarse_n = int(coarse_state.shape[0])
    coarse_grid = SpectralGrid(coarse_n)
    fine_grid = SpectralGrid(args.n)
    state = resample_state(coarse_state, coarse_grid, fine_grid)
    if args.target_enstrophy is not None:
        current_enstrophy = spectral_enstrophy(state, fine_grid)
        state = state * jnp.sqrt(args.target_enstrophy / current_enstrophy)
    config = SearchConfig(
        viscosity=args.viscosity,
        dt=args.dt,
        steps=args.steps,
        initial_max_mode=None,
    )
    final_state, history = trajectory_diagnostics(state, fine_grid, config)
    metadata = {
        "source": str(args.input),
        "coarse_n": coarse_n,
        "n": args.n,
        "viscosity": args.viscosity,
        "dt": args.dt,
        "steps": args.steps,
        "target_enstrophy": args.target_enstrophy,
        "diagnostic_names": DIAGNOSTIC_NAMES,
        "artifact_schema_version": 2,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    np.savez_compressed(
        args.output,
        state=np.asarray(state),
        final_state=np.asarray(final_state),
        trajectory=np.asarray(history),
        metadata=np.asarray(json.dumps(metadata)),
    )

    h = np.asarray(history)
    enstrophy, rate = h[:, 1], h[:, 2]
    print(
        json.dumps(
            {
                **metadata,
                "enstrophy_initial": float(enstrophy[0]),
                "enstrophy_max": float(enstrophy.max()),
                "enstrophy_final": float(enstrophy[-1]),
                "rate_min": float(rate.min()),
                "velocity_tail_max": float(h[:, 5].max()),
                "enstrophy_tail_max": float(h[:, 9].max()),
                "palinstrophy_tail_max": float(h[:, 10].max()),
                "depletion_indicator_initial": float(h[0, 11]),
                "depletion_indicator_final": float(h[-1, 11]),
                "spectral_broadening_final": float(h[-1, 12]),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
