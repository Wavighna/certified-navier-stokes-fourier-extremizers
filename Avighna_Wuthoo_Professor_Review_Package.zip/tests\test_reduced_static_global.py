from hashlib import sha256
import json
from pathlib import Path

import pytest

from extreme_flows.reduced_static_global import (
    build_global_static_certificate,
    evaluate_global_static_certificate,
)


def test_global_static_certificate_requires_two_declared_precisions():
    with pytest.raises(ValueError, match="256-bit and 512-bit"):
        build_global_static_certificate(precisions=(256,))


def test_exact_multiplier_reduction_strictly_dominates_all_faces():
    pytest.importorskip("flint")
    run = evaluate_global_static_certificate(precision=128, bits=60)

    assert run["strict_interior_dominance"]
    assert float(run["interior"]["rate"]["lower"].split()[0].lstrip("[")) > 449.7
    assert run["interior"]["sturm"]["positive_root_count"] == 1
    for face in run["faces"].values():
        assert face["strictly_below_interior"]
        assert face["sturm"]["positive_root_count"] == 1


def test_global_reduction_matches_seed_and_current_checker_hashes():
    pytest.importorskip("flint")
    run = evaluate_global_static_certificate(precision=128, bits=60)
    value = float(run["interior"]["rate"]["ball"].split()[0].lstrip("["))
    assert abs(value - 449.7183372304457) < 1.0e-10

    payload = json.loads(
        Path("artifacts/proofs/reduced_static_global_arb_certificate.json").read_text(
            encoding="utf-8"
        )
    )
    assert payload["claims"]["global_maximum_within_six_amplitude_static_ansatz"]
    for record in payload["checker_source"].values():
        data = Path(record["path"]).read_bytes()
        assert record["size_bytes"] == len(data)
        assert record["sha256"] == sha256(data).hexdigest()
