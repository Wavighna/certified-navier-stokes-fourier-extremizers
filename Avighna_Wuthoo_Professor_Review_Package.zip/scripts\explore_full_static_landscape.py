"""Deterministic random-restart probe of the full static 64-control problem.

This script is deliberately *not* a certificate.  It supplies reproducible
numerical evidence for, or against, the conjecture that the certified
six-amplitude extremizer is also globally dominant in the complete 64-control
Fourier class.  Every run uses the exact polynomial evaluator; SciPy's
floating-point optimizer is used only to explore its landscape.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import json
from pathlib import Path

import numpy as np
import scipy
from scipy.optimize import minimize, root

from extreme_flows.certify import (
    ADAPTIVE_PHASE_WAVES,
    StaticLowModePolynomial,
    phase_fix_controls,
)
from extreme_flows.reduced_static import embed_reduced_static
from extreme_flows.static_symmetry import (
    signed_coordinate_matrices,
    static_symmetry_matrix,
)
from extreme_flows.reduced_static_parameterized import dimensionless_interior_quartic
from extreme_flows.reduced_static_parameterized_global import interior_dimensionless_rate


CERTIFIED_SYMMETRY_ANSATZ_RATE = 449.718337230445715677500657
INVISCID_SIX_CUBIC_COEFFICIENT = 8.0 * np.sqrt(138.0) / 207.0


def _parameterized_ansatz_rate(viscosity: float, target_enstrophy: float) -> float:
    """Numerically evaluate the exact high-eta ansatz branch rate.

    The branch itself is proved globally inside the ansatz for eta>1867/4.
    This routine only converts its exact rational polynomial to a floating
    reference value for exploratory full-space optimization.
    """

    eta = target_enstrophy / (viscosity * viscosity)
    coefficients = dimensionless_interior_quartic(Fraction(str(eta)))
    roots = np.roots([float(value) for value in reversed(coefficients)])
    candidates = [root.real for root in roots if abs(root.imag) < 1.0e-8 and root.real > np.sqrt(28.0)]
    if len(candidates) != 1:
        raise RuntimeError("parameterized ansatz branch did not yield one admissible root")
    mu = Fraction(str(candidates[0]))
    return viscosity**3 * float(interior_dimensionless_rate(mu))


def _inviscid_six_cubic_reference_rate(target_enstrophy: float) -> float:
    """Return the exact six-space inviscid cubic value at fixed enstrophy.

    This is a reference for a full-64-dimensional *conjecture*, not a
    full-space certificate. It follows from the exact six-amplitude limit
    ``A/E^(3/2)=8 sqrt(138)/207``.
    """

    return INVISCID_SIX_CUBIC_COEFFICIENT * target_enstrophy**1.5


def _normalized_controls(
    direction: np.ndarray, diagonal: np.ndarray, target_enstrophy: float
) -> tuple[np.ndarray, float]:
    quadratic = float(np.dot(diagonal * direction, direction))
    if not np.isfinite(quadratic) or quadratic <= 0.0:
        raise FloatingPointError("invalid weighted-sphere direction")
    scale = np.sqrt(2.0 * target_enstrophy / quadratic)
    return scale * direction, quadratic


def _cubic_control_actions() -> tuple[np.ndarray, ...]:
    """Return the 48 full-control actions of signed coordinate isometries."""

    return tuple(
        np.asarray(static_symmetry_matrix((matrix, (0, 0, 0))), dtype=float)
        for matrix in signed_coordinate_matrices()
    )


def _best_orbit_representative(
    controls: np.ndarray,
    model: StaticLowModePolynomial,
    actions: tuple[np.ndarray, ...],
) -> tuple[float, np.ndarray]:
    """Distance to the six-amplitude ansatz modulo cubic isometries/translations.

    This is a floating-point diagnostic.  Each candidate is transformed by all
    48 signed coordinate isometries, phase-fixed by translations, and compared
    to the reduced embedding recovered from its six support amplitudes.
    """

    best = float("inf")
    representative: np.ndarray | None = None
    for action in actions:
        try:
            phase_fixed = phase_fix_controls(model, action @ controls)
        except ValueError:
            # This particular cubic image may make one of the three selected
            # chart amplitudes vanish.  It is not a valid translation chart,
            # but other orbit images can still provide one.
            continue
        amplitudes = (
            phase_fixed[0],
            phase_fixed[20],
            -phase_fixed[26],
            -phase_fixed[29],
            -phase_fixed[48],
            -phase_fixed[54],
        )
        embedded = np.asarray(embed_reduced_static(amplitudes), dtype=float)
        residual = float(np.max(np.abs(phase_fixed - embedded)))
        if residual < best:
            best = residual
            representative = phase_fixed
    if representative is None:
        raise RuntimeError("no cubic-isometry image has a regular phase chart")
    return best, representative


def _polish_kkt(
    controls: np.ndarray, model: StaticLowModePolynomial, target: float
) -> tuple[np.ndarray, bool, float]:
    """Floating-point KKT polish in the already phase-fixed chart."""

    evaluated = model.evaluate(controls)
    constraints = model.constraint_jacobian(controls)
    multipliers = np.linalg.lstsq(
        constraints.T, evaluated["gradient_rate"], rcond=None
    )[0]
    solved = root(
        lambda point: model.kkt_system(point, target),
        np.concatenate((controls, multipliers)),
        jac=model.kkt_jacobian,
        method="hybr",
        options={"xtol": 1.0e-11, "maxfev": 5000},
    )
    residual = float(np.max(np.abs(model.kkt_system(solved.x, target))))
    return solved.x[: model.dimension], bool(solved.success), residual


def explore(
    *,
    starts: int = 24,
    seed: int = 20260812,
    max_iterations: int = 500,
    classify_symmetry_orbits: bool = False,
    polish_kkt: bool = False,
    viscosity: float = 0.01,
    target_enstrophy: float = 100.0,
    include_controls: bool = False,
) -> dict[str, object]:
    """Run deterministic full-sphere L-BFGS restarts and serialize all runs."""

    if viscosity < 0.0 or target_enstrophy <= 0.0:
        raise ValueError("viscosity must be nonnegative and enstrophy positive")
    model = StaticLowModePolynomial(
        viscosity=Fraction(str(viscosity)), phase_waves=ADAPTIVE_PHASE_WAVES
    )
    target = float(target_enstrophy)
    diagonal = np.asarray(model.enstrophy_diagonal, dtype=float)
    reference_rate = (
        _inviscid_six_cubic_reference_rate(target)
        if viscosity == 0.0
        else _parameterized_ansatz_rate(viscosity, target)
    )
    if polish_kkt and not classify_symmetry_orbits:
        raise ValueError("KKT polishing requires symmetry-orbit classification")
    actions = _cubic_control_actions() if classify_symmetry_orbits else ()

    def objective(direction: np.ndarray) -> float:
        controls, _ = _normalized_controls(direction, diagonal, target)
        return -float(model.evaluate(controls)["rate"])

    def gradient(direction: np.ndarray) -> np.ndarray:
        controls, quadratic = _normalized_controls(direction, diagonal, target)
        ambient = np.asarray(model.evaluate(controls)["gradient_rate"], dtype=float)
        scale = np.sqrt(2.0 * target / quadratic)
        pullback = scale * (
            ambient
            - diagonal
            * direction
            * float(np.dot(ambient, direction))
            / quadratic
        )
        return -pullback

    generator = np.random.default_rng(seed)
    runs: list[dict[str, object]] = []
    for restart in range(int(starts)):
        initial = generator.normal(size=model.dimension)
        solved = minimize(
            objective,
            initial,
            jac=gradient,
            method="L-BFGS-B",
            options={
                "maxiter": int(max_iterations),
                "ftol": 1.0e-14,
                "gtol": 1.0e-9,
                "maxls": 50,
            },
        )
        controls, _ = _normalized_controls(solved.x, diagonal, target)
        rate = -float(solved.fun)
        record: dict[str, object] = {
            "restart": restart,
            "rate": rate,
                "rate_gap_below_parameterized_ansatz_reference": (
                    reference_rate - rate
            ),
            "iterations": int(solved.nit),
            "success": bool(solved.success),
            "message": str(solved.message),
            "weighted_sphere_enstrophy": float(
                model.evaluate(controls)["enstrophy"]
            ),
            "pullback_gradient_inf_norm": float(
                np.linalg.norm(gradient(solved.x), ord=np.inf)
            ),
        }
        if classify_symmetry_orbits:
            orbit_residual, representative = _best_orbit_representative(
                controls, model, actions
            )
            record["minimum_reduced_ansatz_residual_modulo_cubic_isometry_and_translation"] = orbit_residual
            if polish_kkt:
                polished, root_success, root_residual = _polish_kkt(
                    representative, model, target
                )
                polished_residual, _ = _best_orbit_representative(
                    polished, model, actions
                )
                record["phase_fixed_kkt_polish_success"] = root_success
                record["phase_fixed_kkt_polish_max_abs_residual"] = root_residual
                record["polished_reduced_ansatz_residual_modulo_cubic_isometry_and_translation"] = polished_residual
                record["polished_rate"] = float(model.evaluate(polished)["rate"])
        if include_controls:
            record["terminal_controls"] = [float(value) for value in controls]
        runs.append(record)
    rates = np.asarray([run["rate"] for run in runs], dtype=float)
    return {
        "truth_label": "numerical_full_64d_random_restart_exploration_only",
        "statement": (
            "Deterministic floating-point optimization evidence only; this does not "
            "certify a full 64-dimensional global maximum."
        ),
        "model": {
            "dimension": model.dimension,
            "independent_mode_pairs": len(model.pairs),
            "mode_cutoff_squared": 4,
            "viscosity": viscosity,
            "objective": "stretching A at fixed E" if viscosity == 0.0 else "rate A-2 nu P at fixed E",
            "target_enstrophy": target,
        },
        "optimizer": {
            "method": "L-BFGS-B on a normalized weighted-sphere direction",
            "seed": int(seed),
            "starts": int(starts),
            "max_iterations": int(max_iterations),
            "symmetry_orbit_classification": bool(classify_symmetry_orbits),
            "phase_fixed_kkt_polishing": bool(polish_kkt),
            "terminal_controls_archived": bool(include_controls),
            "numpy_version": np.__version__,
            "scipy_version": scipy.__version__,
        },
        "parameterized_ansatz_reference_rate": reference_rate,
        "reference_description": (
            "exact inviscid six-amplitude cubic value; full-64d equality is conjectural"
            if viscosity == 0.0
            else "parameterized six-amplitude rate; full-64d equality is conjectural"
        ),
        "summary": {
            "best_rate": float(np.max(rates)),
            "worst_rate": float(np.min(rates)),
            "maximum_gap_below_parameterized_ansatz_reference": float(
                reference_rate - np.min(rates)
            ),
            "all_runs_within_relative_1e-8_of_parameterized_ansatz_reference": bool(
                np.all(np.abs(rates - reference_rate) < 1.0e-8 * max(1.0, abs(reference_rate)))
            ),
            "full_global_maximum_proved": False,
            "maximum_reduced_ansatz_residual_modulo_cubic_isometry_and_translation": (
                float(
                    max(
                        run[
                            "minimum_reduced_ansatz_residual_modulo_cubic_isometry_and_translation"
                        ]
                        for run in runs
                    )
                )
                if classify_symmetry_orbits
                else None
            ),
            "maximum_polished_reduced_ansatz_residual": (
                float(
                    max(
                        run[
                            "polished_reduced_ansatz_residual_modulo_cubic_isometry_and_translation"
                        ]
                        for run in runs
                    )
                )
                if polish_kkt
                else None
            ),
            "maximum_phase_fixed_kkt_polish_residual": (
                float(
                    max(
                        run["phase_fixed_kkt_polish_max_abs_residual"] for run in runs
                    )
                )
                if polish_kkt
                else None
            ),
        },
        "runs": runs,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--starts", type=int, default=24)
    parser.add_argument("--seed", type=int, default=20260812)
    parser.add_argument("--max-iterations", type=int, default=500)
    parser.add_argument("--viscosity", type=float, default=0.01)
    parser.add_argument("--target-enstrophy", type=float, default=100.0)
    parser.add_argument(
        "--include-controls",
        action="store_true",
        help="archive each terminal 64-coordinate state for continuation diagnostics",
    )
    parser.add_argument(
        "--classify-symmetry-orbits",
        action="store_true",
        help="measure distance to the reduced ansatz modulo cubic isometries/translations",
    )
    parser.add_argument(
        "--polish-kkt",
        action="store_true",
        help="polish the best phase-fixed symmetry representative by a floating-point KKT solve",
    )
    parser.add_argument(
        "--output", default="artifacts/raw/full_static_random_restart_exploration.json"
    )
    args = parser.parse_args()
    payload = explore(
        starts=args.starts,
        seed=args.seed,
        max_iterations=args.max_iterations,
        classify_symmetry_orbits=args.classify_symmetry_orbits,
        polish_kkt=args.polish_kkt,
        viscosity=args.viscosity,
        target_enstrophy=args.target_enstrophy,
        include_controls=args.include_controls,
    )
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(f"wrote {output}")
    print(f"best rate={payload['summary']['best_rate']:.15g}")
    print(
        "all runs within 1e-8 of symmetry value="
        f"{payload['summary']['all_runs_within_relative_1e-8_of_parameterized_ansatz_reference']}"
    )


if __name__ == "__main__":
    main()
