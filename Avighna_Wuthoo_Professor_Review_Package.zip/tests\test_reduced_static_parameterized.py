from fractions import Fraction

from extreme_flows.reduced_static_global import _INTERIOR_POLYNOMIAL
from extreme_flows.reduced_static_parameterized import (
    UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD,
    dimensionless_interior_quartic,
    high_eta_interior_branch_theorem,
    interior_multiplier_quartic,
    interior_squared_amplitudes,
)


def test_current_quartic_is_the_parameterized_formula_at_nu_point01_e100():
    coefficients = interior_multiplier_quartic(Fraction(1, 100), Fraction(100))
    scale = Fraction(6_250_000)
    assert tuple(scale * value for value in coefficients) == _INTERIOR_POLYNOMIAL


def test_high_eta_branch_theorem_has_exact_sign_and_admissibility_logic():
    payload = high_eta_interior_branch_theorem(Fraction(1_000_000))
    assert payload["threshold_met"]
    assert payload["descending_sign_pattern"] == [1, 1, -1, -1, -1]
    assert payload["descartes_positive_root_count"] == 1
    assert payload["root_exceeds_sqrt_28"]
    assert payload["positive_a2_d2_f2"]
    assert not payload["global_maximum_statement"]


def test_threshold_is_sharp_for_the_quadratic_coefficient_sign_argument():
    at_threshold = dimensionless_interior_quartic(UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD)
    below = high_eta_interior_branch_theorem(UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD)
    above = high_eta_interior_branch_theorem(
        UNIQUE_ADMISSIBLE_BRANCH_ETA_THRESHOLD + Fraction(1, 1000)
    )
    assert at_threshold[2] == 0
    assert not below["threshold_met"]
    assert above["threshold_met"]


def test_interior_square_formulas_are_positive_above_the_admissibility_threshold():
    # mu=7 is already above sqrt(28), so every displayed square is positive.
    squares = interior_squared_amplitudes(Fraction(7), Fraction(1, 100))
    assert all(value > 0 for value in squares.values())
