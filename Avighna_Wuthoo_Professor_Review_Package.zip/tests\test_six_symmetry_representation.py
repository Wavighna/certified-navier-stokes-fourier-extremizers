from scripts.certify_six_symmetry_representation import build_payload


def test_six_branch_real_isotypic_decomposition_is_exact():
    payload = build_payload()
    assert payload["group"]["order"] == 16
    assert payload["group"]["abelianization_order"] == 8
    assert payload["linear_isotypic_total_dimension"] == 40
    assert [row["projector_rank"] for row in payload["linear_character_sectors"]] == [
        5,
        5,
        5,
        5,
        6,
        4,
        4,
        6,
    ]
    assert payload["nonlinear_real_isotypic_component"]["dimension"] == 24
    assert payload["nonlinear_real_isotypic_component"][
        "central_order_four_characteristic_polynomial"
    ] == "(lambda^2+1)^12"
    assert payload["claims"]["uniform_six_branch_hessian_signs_proved"] is False
