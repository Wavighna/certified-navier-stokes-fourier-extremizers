from pathlib import Path

from scripts.build_paper_a_manifest import build_manifest


def test_paper_a_release_manifest_hashes_all_declared_files() -> None:
    manifest = build_manifest()
    assert manifest["truth_label"] == "paper_a_release_content_manifest"
    assert not manifest["prohibited_claims"]["full_64d_global_maximum"]
    assert not manifest["prohibited_claims"]["navier_stokes_regularity_or_blowup_statement"]
    assert not manifest["prohibited_claims"]["independent_software_audit_completed"]
    assert len(manifest["files"]) >= 30
    assert "paper/REVIEWER_GUIDE.md" in {record["path"] for record in manifest["files"]}
    assert "paper/SUBMISSION_STRATEGY.md" in {
        record["path"] for record in manifest["files"]
    }
    assert "paper/COVER_LETTER_SIADS_DRAFT.md" in {
        record["path"] for record in manifest["files"]
    }
    assert "paper/SUPPLEMENT_INDEX_SIADS_DRAFT.md" in {
        record["path"] for record in manifest["files"]
    }
    assert "paper/figures/symmetry_branch_rates.pdf" in {
        record["path"] for record in manifest["files"]
    }
    assert "scripts/plot_static_branches.py" in {
        record["path"] for record in manifest["files"]
    }
    assert "scripts/audit_competing_standalone.py" in {
        record["path"] for record in manifest["files"]
    }
    assert "scripts/audit_reduced_static_standalone.py" in {
        record["path"] for record in manifest["files"]
    }
    assert "scripts/audit_paper_a_clean_tree.py" in {
        record["path"] for record in manifest["files"]
    }
    for record in manifest["files"]:
        assert Path(record["path"]).is_file()
        assert len(record["sha256"]) == 64
