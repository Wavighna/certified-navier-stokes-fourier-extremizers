---
title: "A certified symmetry-reduced extremizer for initial enstrophy production in periodic 3D Navier--Stokes"
status: "ARCHIVED non-authoritative working draft"
---

> **Archived draft — do not submit or cite.** The sole current manuscript
> source is [`paper/main.tex`](main.tex). This Markdown file predates the
> all-parameter competing-branch theorem and contains legacy encoding; it is
> retained only as historical working material and is intentionally excluded
> from the release manifest.

# A certified symmetry-reduced extremizer for initial enstrophy production in periodic 3D Navier--Stokes

## Abstract

We study instantaneous enstrophy production for three-dimensional
incompressible Navier--Stokes flow on the periodic torus. The classical
fixed-enstrophy variational problem is restricted to 16 independent Fourier
pairs with $0<|k|^2≤4$, giving 64 real divergence-free coordinates. Within an
exactly characterized six-dimensional fixed space of lattice symmetries, the
stretching and quadratic invariants reduce to

$$
A=64acd+32aef-64bdf,
$$

$$
E=2a^2+32b^2+48c^2+8d^2+48e^2+4f^2,
\qquad
P=2a^2+128b^2+144c^2+16d^2+144e^2+8f^2.
$$

For $ν=10^{-2}$ and $E=100$, exact Sturm reduction and interval arithmetic
certify the global maximum of $A-2νP$ inside this symmetry class, with value
$449.7183372304457156…$. Finite-group symmetric criticality and a separate
68-variable Krawczyk certificate identify the same point as a strict local
maximum, modulo translations, in the full 64-coordinate Fourier class. These
are finite-dimensional results: they neither establish a full-class global
maximum nor address Navier--Stokes regularity.

At the separate scaled parameter point $\nu=10^{-1}$, $E=100$
($\eta=10^4$), a second 256/512-bit interval certificate proves a distinct
strict local maximum in the full class. Its rate
$417.844001666\ldots$ is larger than the six-amplitude ansatz rate
$411.566601975\ldots$ at the same $\eta$. Thus symmetry-reduced globality
cannot be promoted to full-class globality.

## 1. Introduction

The instantaneous enstrophy-production variational problem has been used to
construct extreme vortex states and test sharp cubic enstrophy-growth bounds.
Lu and Doering formulated the fixed-enstrophy problem in Fourier variables and
computed maximizers numerically. Ayala and Protas continued numerical branches
and analyzed their dynamical depletion. Those works motivate, but do not give,
an exact finite-enstrophy characterization of a constrained three-dimensional
Fourier extremizer.

Our contribution is deliberately narrow. We fix a specified low-mode class,
identify a six-dimensional symmetry-fixed subspace exactly, solve its static
maximization problem by algebra and interval certification, and identify the
result with an independently certified strict local extremizer in the complete
64-coordinate class. The companion persistence project is not used in the
theorems below.

## 2. Setting and results

On $[0,2π)^3$, let $u$ solve

$$
∂_t u+(u·∇)u+∇p=νΔu,
\qquad ∇·u=0.
$$

With $ω=∇×u$ and $S=(∇u+∇u^T)/2$, define

$$
E=\tfrac12⟨|ω|^2⟩,
\quad P=\tfrac12⟨|∇ω|^2⟩,
\quad A=⟨ω·Sω⟩,
\quad R=A-2νP.
$$

We use a canonical divergence-free polarization basis on the 16 independent
pairs $0<|k|^2≤4$, with coefficient vector $x∈ℝ^{64}$.

**Theorem 2.1 (symmetry-reduced global static extremizer).** For $ν=10^{-2}$
and $E=100$, let $V⊂ℝ^{64}$ be the common fixed space of the three combined
signed-coordinate/quarter-period symmetries in Appendix A. Then $dim V=6$.
In coordinates $(a,b,c,d,e,f)$, the three invariants are the polynomials in
the abstract. The constrained problem

$$
\max\{A-2νP:(a,b,c,d,e,f)∈ℝ^6,\ E=100\}
$$

has a unique global maximizer after the finite sign gauge, and its value is

$$
449.718337230445715677500657… .
$$

**Theorem 2.2 (full-space local identification).** The maximizer in Theorem
2.1 is a constrained critical point in the full 64-coordinate class. In a
regular translation phase chart it is a strict local maximum modulo
translations. The certified bordered-Hessian inertia is $(4,64,0)$, where the
four positive directions belong to the constraint/gauge block.

**Theorem 2.3 (a higher competing local branch).** At $\nu=10^{-1}$ and
$E=100$, there is a second constrained critical point in the full
64-coordinate class that is a strict local maximum modulo translations. Its
rate is $417.844001666\ldots$, strictly larger than the six-amplitude
ansatz-global rate $411.566601975\ldots$ at the same
$\eta=E/\nu^2=10^4$. No full-class global maximum is asserted.

**Proposition 2.4 (competing symmetry reduction).** The higher branch lies in
the exact two-dimensional common fixed space of two explicit lattice
symmetries. In its coordinates $(a,b)$, its global static maximizer within
that fixed space is given by
$b=(\sqrt{E+\nu^2}-\nu)/12$. For every positive $(E,\nu)$ this formula is a
full 64-coordinate KKT branch. At $(\nu,E)=(1/10,100)$ it is the strict
full-space local maximum certified in Theorem 2.3.

**Theorem 2.5 (symmetry-branch switch).** On the high-$\eta$ six-amplitude
branch, the competing two-amplitude and six-amplitude rates meet exactly once,
at

$$
\eta_\times=27992.671985287174015090\ldots.
$$

The two-amplitude branch has the larger rate for
$1867/4<\eta<\eta_\times$; the six-amplitude branch has the larger rate for
$\eta>\eta_\times$. This is an ordering only between these two
symmetry-reduced KKT branches, not a full 64-coordinate global-ordering
theorem.

As a robustness result distinct from a uniform theorem, interval calculations
also certify strict full-space local maximality at the five points
$\eta=100,400,2500,10^4,4\times10^4$, each independently at 256 and 512
bits. This finite sweep is reported as validation evidence only.

## 3. Exact six-amplitude reduction

The three generators act exactly on the rational Fourier-polarization
coordinates. Their fixed-point equations are rational linear equations in 64
variables. Exact row reduction gives a common fixed space of dimension six;
the columns of the explicit map

$$
(a,b,c,d,e,f) \longmapsto x(a,b,c,d,e,f)
$$

are a basis. Direct rational Fourier convolution gives the displayed formulas
for $A$, $E$, and $P$. The implementation checks both the formulas and the
reduced gradient on rational test vectors against the full 64-variable exact
polynomial.

A finite sign action preserves $E$ and $P$ and makes all three cubic monomials
in $A$ nonnegative. At a positive maximizer, either all three monomials are
active or exactly one is active. A two-active face admits a strictly improving
missing-coordinate perturbation; a zero-monomial face has nonpositive rate.
On the fully interior branch, the KKT equations reduce to the multiplier
quartic

$$
431250000λ^4+106000000λ^3-19990665000λ^2
-3199658400λ-127995727=0.
$$

Exact Sturm bisection isolates its unique positive root. Each one-monomial
face gives one quadratic. Arb interval evaluations at 256 and 512 bits
strictly order the interior rate above all three face rates, proving Theorem
2.1.

The reduction has a useful parameterized form. Let $eta=E/nu^2$ and
$mu=lambda/nu$. The interior enstrophy constraint is exactly

$$
F_eta(mu)=69mu^4+1696mu^3+(14936-32eta)mu^2
+(54656-512eta)mu+(68368-2048eta)=0.
$$

**Proposition 3.1 (unique high-eta interior branch).** If $eta>1867/4$, then
$F_eta$ has exactly one positive root, that root exceeds $sqrt(28)$, and it
produces positive values of $a^2$, $d^2$, and $f^2$ in the interior KKT
formulas.

Indeed, its coefficient signs in descending powers are $(+,+,-,-,-)$, so
Descartes' rule gives at most one positive root; its negative constant term
and positive leading coefficient give existence. Finally,
$F_eta(sqrt(28))<=-833440-273664sqrt(7)<0$ throughout this range, so the root
is larger than $sqrt(28)$. This proposition describes an interior stationary
branch only; it does not assert a global maximum for every parameter value.

**Theorem 3.2 (high-eta ansatz-globality).** For every $eta>1867/4$, this
interior branch is the global maximizer of the static rate inside the complete
six-amplitude symmetry ansatz. The result is still not a full 64-coordinate
global theorem.

For each of the three one-monomial face branches, eliminating the face
multiplier from simultaneous equality of $eta$ and rate with the interior
branch gives a degree-eight resultant in $mu$. Its coefficients are strictly
positive in all three cases, hence it cannot vanish for $mu>0$. The branches
cannot cross. The existing independent Arb certificate at $eta=10^6$ fixes the
strict interior-greater-than-face ordering on the connected interval
$eta>1867/4$. Together with the face-exhaustion argument, this proves the
theorem.

## 4. Full-space certificate

For the full low-mode class, we impose the enstrophy constraint and three
regular phase conditions, producing 68 KKT equations. Arb Newton refinement
and a Krawczyk contraction enclose a unique root. Exact-dyadic congruence and
signed Gershgorin bounds certify bordered inertia $(4,64,0)$.

The interval point built from the reduced multiplier root lies strictly inside
this independent full Krawczyk box at both 256 and 512 bits. The symmetry group
preserves the objective and enstrophy. Averaging an arbitrary variation over
the finite group turns it into a fixed-space variation, so restricted
stationarity implies full-space stationarity. Krawczyk uniqueness then
identifies the two certificates and proves Theorem 2.2.

## 5. A certified competing full-space local branch

Naive multi-start is not a safe guide to full-space globality here. At
$\eta=10^4$, continuation from a numerical branch outside the six-amplitude
ansatz yields a
second KKT point with $\nu=1/10$, $E=100$ and

$$
R=417.844001666\ldots,
$$

whereas the six-amplitude ansatz-global value at the same $\eta$ is
$411.566601975\ldots$. Thus the symmetry-ansatz optimizer is not globally
maximal in the complete 64-coordinate class at this parameter point.

This is not merely a floating-point observation. In a regular phase chart
using the three waves $e_1,e_2,e_3$ and polarizations $(1,2,1)$, independent
256- and 512-bit Arb Krawczyk calculations enclose a unique root and certify
bordered inertia $(4,64,0)$. Hence this higher point is a strict local maximum
modulo translations in the full low-mode class. It is still not asserted to be
a global maximum. The failure of 100 restarts to find it at a different
parameter value is retained only as a warning about the basin structure, not
as evidence for globality.

The branch has an exact representation. In the canonical 64-coordinate basis,
three entries equal $a$, six entries equal signed copies of $b$, and the rest
vanish. It is exactly the common two-dimensional fixed space of a reflection
combined with a quarter-period shift and a signed cyclic coordinate isometry;
this is verified by rational row reduction. Direct rational convolution gives

$$
A=24a^2b,\qquad E=3a^2+48b^2,\qquad P=3a^2+96b^2.
$$

After eliminating $a$ the rate is

$$
R(b)=8Eb-384b^3-2\nu E-96\nu b^2,
$$

whose unique sign-gauged maximizer is

$$
b_*=\frac{\sqrt{E+\nu^2}-\nu}{12}.
$$

At $(\nu,E)=(1/10,100)$, symbolic reduction verifies all 64 KKT equations
for arbitrary positive $(E,\nu)$ modulo the two branch equations. At the
displayed parameter point, its Arb enclosure lies in the unique full Krawczyk
box at both 256 and 512 bits. Thus the formula identifies the
interval-certified full-space local branch, while its globality remains only
two-dimensional.

For the branch comparison, eliminate the competing coordinate $b$ from equal
rate and equal $\eta$. Apart from a nonzero factor, the resultant is

$$
\begin{aligned}
P(\mu)={}&14283\mu^{12}-616032\mu^{11}-75884328\mu^{10}
-2607893632\mu^9-48929993328\mu^8\\
&-584799255552\mu^7-4735225442048\mu^6-26610597679104\mu^5
-103880151184128\mu^4\\
&-275978473299968\mu^3-474888508827648\mu^2
-475951787311104\mu-210195161092096.
\end{aligned}
$$

Descartes' rule gives one positive root. Since $\eta(\mu)$ for the
six-amplitude branch is strictly increasing, a two-variable Krawczyk proof
locates the only crossing. Interval sign checks at $\eta=10^4$ and
$4\times10^4$ establish the stated ordering.

## 6. Scope and reproducibility

All proof inputs, source hashes, dependency manifests, literal rational data,
and 256/512-bit logs are archived under `artifacts/proofs/`. The checker pins
`python-flint==0.9.0`. The claim set is deliberately limited:

- globality is proved only inside the six-amplitude symmetry-fixed class;
- full-space strict local maximality is proved only in the specified
  64-coordinate low-mode class;
- no conclusion concerns the time-evolved PDE, arbitrary Fourier bandwidth,
  finite-time singularity, or global regularity.

## Appendix A. Symmetry definition

For a signed-coordinate orthogonal matrix $Q$ and an integer vector $m$, set
$τ=πm/2$ and define

$$
(g_{Q,m}u)(x)=Q u(Q^T(x-τ)).
$$

The fixed space of Theorem 2.1 is the common fixed space of

$$
\begin{array}{c|c}
Q&m\\ \hline
diag(-1,-1,1)&(0,0,2)\\
diag(1,1,-1)&(1,3,0)\\
\begin{pmatrix}0&-1&0\\-1&0&0\\0&0&1\end{pmatrix}&(1,1,2).
\end{array}
$$

They preserve periodicity, incompressibility, $E$, $P$, and $A$. Exact action
matrices and rational row reduction are in
`src/extreme_flows/static_symmetry.py`; the six-amplitude embedding is in
`src/extreme_flows/reduced_static.py`.

The competing two-amplitude fixed space in Proposition 2.4 is the common fixed
space of

$$
\begin{array}{c|c}
Q&m\\ \hline
\operatorname{diag}(-1,1,1)&(0,2,0)\\
\begin{pmatrix}0&-1&0\\0&0&1\\-1&0&0\end{pmatrix}&(0,0,0).
\end{array}
$$

Exact row reduction gives dimension two; its embedding and exact polynomial
identities are in `src/extreme_flows/reduced_competing.py`.

One sign representative of the certified root is

$$
(a,b,c,d,e,f)=(3.62591054043819,
-0.470645017355496,
0.674458755555059,
1.90489373007887,
0.299494557798457,
1.69174260292171).
$$

Each displayed coordinate is enclosed by a 256-bit Arb ball of radius below
$9×10^{-29}$; the serialized interval payload is the proof object.

## Appendix B. Verification artifacts

- `artifacts/proofs/reduced_static_global_arb_certificate.json`
- `artifacts/proofs/static_adaptive_arb_certificate.json`
- `artifacts/proofs/static_symmetry_connection_certificate.json`
- `artifacts/proofs/parameterized_static_branch.json`
- `artifacts/proofs/parameterized_static_global.json`
- `artifacts/proofs/high_branch_eta10000_candidate.json`
- `artifacts/proofs/high_branch_eta10000_arb_certificate.json`
- `artifacts/proofs/reduced_competing_formula.json`
- `artifacts/proofs/competing_branch_stability_sweep.json`
- `artifacts/proofs/symmetry_branch_crossover.json`
- `artifacts/raw/full_static_high_branch_3000_10000.json` (numerical
  continuation seed only)

The scripts `certify_reduced_static_global.py`, `certify_static_adaptive.py`,
`certify_static_symmetry_connection.py`, and `certify_high_static_branch.py`
regenerate the interval proof artifacts. The script
`certify_reduced_competing.py` regenerates the exact two-amplitude algebra.
The single command `python scripts/verify_paper_a.py` recomputes all three
256/512-bit proof claims and writes a current-source manifest.

## References to complete before submission

1. Lu Lu and Charles R. Doering, *Limits on enstrophy growth for solutions of
   the three-dimensional Navier--Stokes equations*, Indiana University
   Mathematics Journal 57 (2008), 2693--2728,
   doi:10.1512/iumj.2008.57.3716.
2. Diego Ayala and Bartosz Protas, *Extreme vortex states and the growth of
   enstrophy in three-dimensional incompressible flows*, Journal of Fluid
   Mechanics 818 (2017), 772--806, doi:10.1017/jfm.2017.136.
3. Evan Miller, *Finite-time blowup for the Fourier-restricted Euler and
   hypodissipative Navier--Stokes model equations*, arXiv:2307.03434.
4. Oleg Kiriukhin, *Orbit-Level Stretching in Cubic Fourier-Galerkin
   Navier--Stokes*, arXiv:2603.23293 (2026 preprint; detailed comparison is
   required before submission).

The bibliography and priority audit remain required pre-submission work.
