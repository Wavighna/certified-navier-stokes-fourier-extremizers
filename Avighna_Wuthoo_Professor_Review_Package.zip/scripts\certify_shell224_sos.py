"""Write the exact SOS certificate for the (2,2,4) shellwise bound."""

from __future__ import annotations

import json
from pathlib import Path

from extreme_flows.shellwise_bounds import shell224_sos_certificate


def main() -> None:
    output = Path("artifacts/proofs/shell224_sos_certificate.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = shell224_sos_certificate()
    output.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    print(payload["truth_label"])
    print(f"wrote {output}")


if __name__ == "__main__":
    main()
